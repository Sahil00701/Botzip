require('dotenv').config()
require('module-alias/register')
const path = require('path')
const Spyder = require(`./qwerzip/structures/Spyder.js`)
const client = new Spyder()
this.config = require(`${process.cwd()}/config.json`);

// Clear console and print ASCII banner before startup
console.clear();
console.log(`████████ ██ ████████  █████  ███    ██     ██   ██     ██████  ███████ ██    ██ \n   ██    ██    ██    ██   ██ ████   ██      ██ ██      ██   ██ ██      ██    ██ \n   ██    ██    ██    ███████ ██ ██  ██       ███       ██   ██ █████   ██    ██ \n   ██    ██    ██    ██   ██ ██  ██ ██      ██ ██      ██   ██ ██       ██  ██  \n   ██    ██    ██    ██   ██ ██   ████     ██   ██     ██████  ███████   ████   \n                                                                                \n                                                                                `);

(async () => {
    const startTime = Date.now();
    await client.initializeMongoose()
    await client.initializedata()
    await Promise.all([
        client.loadEvents(),
        client.loadlogs(),
        client.SQL()
    ]);
    await client.loadMain();
    console.log('[STARTUP] Initialized components in', Date.now() - startTime, 'ms');
    console.log('[LOGIN] Attempting to connect to Discord...');
    try {
        console.log('[LOGIN] Using Token:', client.config.TOKEN ? 'Found' : 'Missing');
        if (client.config.TOKEN) {
            console.log('[LOGIN] Token prefix:', client.config.TOKEN.split('.')[0]);
        }
        client.on('shardReady', (shardId) => console.log(`[SHARD] Shard ${shardId} ready`));
        client.on('shardDisconnect', (event, shardId) => console.log(`[SHARD] Shard ${shardId} disconnected:`, event));
        client.on('shardError', (error, shardId) => console.error(`[SHARD] Shard ${shardId} error:`, error));
        client.on('debug', (info) => console.log('[DEBUG]', info));
        
        await client.login(client.config.TOKEN);
        console.log('[LOGIN] Successfully logged in!');
        console.log(`[STARTUP] Bot ready in ${Date.now() - startTime}ms`);
    } catch (err) {
        console.error('[LOGIN ERROR]', err);
        process.exit(1);
    }
})()
