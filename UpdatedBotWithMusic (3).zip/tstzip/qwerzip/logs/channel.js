const { 
    AuditLogEvent, 
    ChannelType, 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags 
} = require('discord.js');
const wait = require('wait');

module.exports = async (client) => {

    async function logPermissionChanges(action, oldChannel, newChannel, target, overwrite) {
        try {
            const check = await client.util.BlacklistCheck(oldChannel.guild);
            if (check) return;

            const data = await client.db.get(`logs_${oldChannel.guild.id}`);
            if (!data || !data?.channel) return;
            const cchannel = data?.channel;
            const channellog = await oldChannel.guild.channels.cache.get(cchannel);
            if (!channellog) {
                await client.db.set(`logs_${oldChannel.guild.id}`, {
                    voice: data ? data.voice : null,
                    channel: null,
                    rolelog: data ? data.rolelog : null,
                    modlog: data ? data.modlog : null,
                    message: data ? data.message : null,
                    memberlog: data ? data.memberlog : null
                });
                return;
            }
            const auditLogs = await newChannel.guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.ChannelOverwriteUpdate });
            const auditEntry = auditLogs.entries.first();
            const responsibleUser = auditEntry ? auditEntry.executor : null;

            const targetType = target.user ? 'User' : 'Role';
            const targetName = target.user ? target.user.tag : target.name;
            const targetId = target.id;

            let changesText = '';
            if (overwrite) {
                const allow = overwrite.allow.toArray().join(", ") || 'None';
                const deny = overwrite.deny.toArray().join(", ") || 'None';
                changesText = `**${action}**\n**Allow:** ${allow}\n**Deny:** ${deny}\n**Type:** ${targetType}\n**Name:** ${targetName}\n**Id:** ${targetId}`;
            } else {
                changesText = `**${action}**\n**Type:** ${targetType}\n**Name:** ${targetName}\n**Id:** ${targetId}`;
            }

            const responsible = responsibleUser ? `<@${responsibleUser.id}>` : 'Unknown';
            const channelMention = `<#${newChannel.id}>`;

            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## Channel Permission Update`),
                new TextDisplayBuilder().setContent(`**Responsible:** ${responsible}`)
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**Channel:** ${channelMention}\n` +
                    `**Timestamp:** <t:${Math.floor(Date.now() / 1000)}:F>\n\n` +
                    changesText
                )
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`*Permission Change Log*`)
            );

            await channellog.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            }).catch((err) => {});
        } catch (error) {
            return;
        }
    }

    client.on('channelUpdate', async (oldChannel, newChannel) => {
        try {
            const oldPermissions = oldChannel.permissionOverwrites.cache;
            const newPermissions = newChannel.permissionOverwrites.cache;

            newPermissions.forEach(async (overwrite, id) => {
                const oldOverwrite = oldPermissions.get(id);
                const target = newChannel.guild.roles.cache.get(id) || newChannel.guild.members.cache.get(id);

                if (!oldOverwrite) {
                    await logPermissionChanges('Granted', oldChannel, newChannel, target, overwrite);
                    return;
                }

                const oldAllow = oldOverwrite.allow.toArray();
                const newAllow = overwrite.allow.toArray();

                const grantedPermissions = newAllow.filter(perm => !oldAllow.includes(perm));
                const deniedPermissions = oldAllow.filter(perm => !newAllow.includes(perm));

                if (grantedPermissions.length > 0) {
                    await logPermissionChanges('Granted', oldChannel, newChannel, target, overwrite);
                }

                if (deniedPermissions.length > 0) {
                    await logPermissionChanges('Denied', oldChannel, newChannel, target, overwrite);
                }
            });

            oldPermissions.forEach(async (overwrite, id) => {
                if (!newPermissions.get(id)) {
                    const target = newChannel.guild.roles.cache.get(id) || newChannel.guild.members.cache.get(id);
                    await logPermissionChanges('Denied', oldChannel, newChannel, target, null);
                }
            });
        } catch (error) {
            return;
        }
    });

    client.on("channelCreate", async (channel) => {
        let check = await client.util.BlacklistCheck(channel.guild);
        if (check) return;
        let data = await client.db.get(`logs_${channel.guild.id}`);
        if (!data || !data?.channel) return;
        const cchannel = data?.channel;
        const channellog = await channel.guild.channels.cache.get(cchannel);
        if (!channellog) {
            await client.db.set(`logs_${channel.guild.id}`, {
                voice: data ? data.voice : null,
                channel: null,
                rolelog: data ? data.rolelog : null,
                modlog: data ? data.modlog : null,
                message: data ? data.message : null,
                memberlog: data ? data.memberlog : null
            });
            return;
        }
        const auditLogs = await channel.guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.ChannelCreate });
        const logs = auditLogs.entries.first();
        const { executor, target, createdTimestamp } = logs;
        let difference = Date.now() - createdTimestamp;
        if (difference > 5000) return;
        if (executor.id === client.user.id) return;
        if (data) {
            const channelType = channel.type === ChannelType.GuildText ? 'TEXT CHANNEL' :
                channel.type === ChannelType.GuildVoice ? 'VOICE CHANNEL' :
                channel.type === ChannelType.GuildCategory ? 'CATEGORY CHANNEL' :
                channel.type === ChannelType.GuildAnnouncement ? 'NEWS CHANNEL' :
                channel.type === ChannelType.GuildDirectory ? 'STORE CHANNEL' :
                'UNKNOWN CHANNEL TYPE';

            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## Channel Created`),
                new TextDisplayBuilder().setContent(`**Created by:** ${executor.tag}`)
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**Channel Name:** ${channel.name}\n` +
                    `**Channel Mention:** <#${channel.id}>\n` +
                    `**Channel Id:** ${channel.id}\n` +
                    `**Channel Category:** ${channel.parent ? channel.parent.name : "No Category"}\n` +
                    `**Created By:** ${executor}\n` +
                    `**User Id:** ${executor.id}\n` +
                    `**Time:** <t:${Math.round(channel.createdTimestamp / 1000)}:R>\n` +
                    `**Channel Type:** \`${channelType}\``
                )
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`*${channel.guild.name}*`)
            );

            await wait(2000);
            await channellog.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            }).catch((_) => {});
        }
    });

    client.on("channelDelete", async (channel) => {
        let check = await client.util.BlacklistCheck(channel.guild);
        if (check) return;
        let data = await client.db.get(`logs_${channel.guild.id}`);
        if (!data || !data?.channel || !data?.channel?.webhook) return;
        const cchannel = data.channel.channelID;
        const channellog = await channel.guild.channels.cache.get(cchannel);
        if (!channellog) {
            await client.db.set(`logs_${channel.guild.id}`, {
                voice: data ? data.voice : null,
                channel: null,
                rolelog: data ? data.rolelog : null,
                modlog: data ? data.modlog : null,
                message: data ? data.message : null,
                memberlog: data ? data.memberlog : null
            });
            return;
        }
        const auditLogs = await channel.guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.ChannelDelete });
        const logs = auditLogs.entries.first();
        const { executor, target, createdTimestamp } = logs;
        let difference = Date.now() - createdTimestamp;
        if (difference > 5000) return;

        if (executor.id === client.user.id) return;
        if (data) {
            const channelType = channel.type === ChannelType.GuildText ? 'TEXT CHANNEL' :
                channel.type === ChannelType.GuildVoice ? 'VOICE CHANNEL' :
                channel.type === ChannelType.GuildCategory ? 'CATEGORY CHANNEL' :
                channel.type === ChannelType.GuildAnnouncement ? 'NEWS CHANNEL' :
                channel.type === ChannelType.GuildDirectory ? 'STORE CHANNEL' :
                'UNKNOWN CHANNEL TYPE';

            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## Channel Deleted`),
                new TextDisplayBuilder().setContent(`**Deleted by:** ${executor.tag}`)
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**Channel Name:** ${channel.name}\n` +
                    `**Channel Mention:** <#${channel.id}>\n` +
                    `**Channel Id:** ${channel.id}\n` +
                    `**Removed By:** ${executor}\n` +
                    `**User Id:** ${executor.id}\n` +
                    `**Time:** <t:${Math.round(logs.createdTimestamp / 1000)}:R>\n` +
                    `**Channel Type:** \`${channelType}\``
                )
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`*${channel.guild.name}*`)
            );

            await wait(2000);
            await channellog.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            }).catch((_) => {});
        }
    });

    client.on("channelUpdate", async (o, n) => {
        let check = await client.util.BlacklistCheck(o.guild);
        if (check) return;
        let data = await client.db.get(`logs_${o.guild.id}`);
        if (!data || !data?.channel) return;
        const cchannel = data?.channel;
        const channellog = await o.guild.channels.cache.get(cchannel);
        if (!channellog) {
            await client.db.set(`logs_${o.guild.id}`, {
                voice: data ? data.voice : null,
                channel: null,
                rolelog: data ? data.rolelog : null,
                modlog: data ? data.modlog : null,
                message: data ? data.message : null,
                memberlog: data ? data.memberlog : null
            });
            return;
        }
        const auditLogs = await n.guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.ChannelUpdate });
        const logs = auditLogs.entries.first();
        const { executor, target, createdTimestamp } = logs;
        let difference = Date.now() - createdTimestamp;
        if (difference > 5000) return;
        if (executor.id === client.user.id) return;

        const oldName = o.name;
        const newName = n.name;
        const oldNsfw = o.nsfw;
        const newNsfw = n.nsfw;
        const oldTopic = o.topic;
        const newTopic = n.topic;
        const oldrtcRegion = o.rtcRegion;
        const newrtcRegion = n.rtcRegion;
        const oldbitrate = o.bitrate;
        const newbitrate = n.bitrate;
        const olduserLimit = o.userLimit;
        const newuserLimit = n.userLimit;
        const oldvideoQualityMode = o.videoQualityMode;
        const newvideoQualityMode = n.videoQualityMode;
        const oldcooldown = o.rateLimitPerUser;
        const newcooldown = n.rateLimitPerUser;

        const newbitratevalue = n.bitrate / 1000;
        const oldbitratevalue = o.bitrate / 1000;

        if (data) {
            let changes = [];

            if (oldName !== newName) {
                changes.push(`**Channel Renamed:** \`${o.name}\` -> \`${n.name}\``);
            }
            if (oldNsfw !== newNsfw) {
                changes.push(`**Channel NSFW State Updated:** \`${o.nsfw}\` -> \`${n.nsfw}\``);
            }
            if (oldcooldown !== newcooldown) {
                changes.push(`**Channel Slowmode Updated:** \`${o.rateLimitPerUser} seconds\` -> \`${n.rateLimitPerUser} seconds\``);
            }
            if (oldTopic !== newTopic) {
                changes.push(`**Channel Topic Updated:** \`${o.topic}\` -> \`${n.topic}\``);
            }
            if (oldrtcRegion !== newrtcRegion) {
                changes.push(`**Channel Voice Region Updated:** \`${o.rtcRegion}\` -> \`${n.rtcRegion}\``);
            }
            if (oldbitrate !== newbitrate) {
                changes.push(`**Channel Voice Bitrate Updated:** \`${oldbitratevalue} Kbps\` -> \`${newbitratevalue} Kbps\``);
            }
            if (olduserLimit !== newuserLimit) {
                changes.push(`**Channel Voice UserLimit Updated:** \`${o.userLimit} users\` -> \`${n.userLimit} users\``);
            }

            if (changes.length === 0 && o.type === ChannelType.GuildVoice) {
                changes.push(`**Channel Voice Updated:** Channel Video Quality Mode Updated`);
            }

            changes.push(`**Updated At:** <t:${Math.round(logs.createdTimestamp / 1000)}:R>`);

            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## Channel Updated`),
                new TextDisplayBuilder().setContent(`**Updated by:** ${executor.tag}`)
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${o.type === ChannelType.GuildText ? 'Text' : 'Voice'} Channel <#${n.id}> updated by ${executor}\n\n` +
                    changes.join('\n')
                )
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`*${n.guild.name}*`)
            );

            await wait(2000);
            await channellog.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            }).catch((_) => {});
        }
    });
};
