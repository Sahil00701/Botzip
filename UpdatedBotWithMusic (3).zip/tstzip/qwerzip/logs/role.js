const { 
    AuditLogEvent, 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder,
    SeparatorSpacingSize,
    PermissionsBitField, 
    MessageFlags 
} = require('discord.js');
const wait = require('wait');

module.exports = async (client) => {
    client.on("roleCreate", async (role) => {
        let check = await client.util.BlacklistCheck(role.guild);
        if (check) return;

        let data = await client.db.get(`logs_${role.guild.id}`);
        if (!data || !data?.rolelog) return;

        const channel = data?.rolelog;
        const rolelog = await role.guild.channels.cache.get(channel);
        if (!rolelog) {
            await client.db.set(`logs_${role.guild.id}`, {
                voice: data ? data.voice : null,
                channel: data ? data.channel : null,
                rolelog: null,
                modlog: data ? data.modlog : null,
                message: data ? data.message : null,
                memberlog: data ? data.memberlog : null
            });
            return;
        }

        const auditLogs = await role.guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.RoleCreate });
        const logs = auditLogs.entries.first();
        const { executor, target, createdTimestamp } = logs;
        let difference = Date.now() - createdTimestamp;
        if (difference > 5000) return;

        if (data) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## Role Created: ${role.name}`),
                new TextDisplayBuilder().setContent(`**Created by:** ${executor.tag}`)
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**Role Information:**\n\n` +
                    `- Role Name: ${role.name}\n` +
                    `- Role ID: ${role.id}\n` +
                    `- Displayed separately: ${role.hoist ? 'Yes' : 'No'}\n` +
                    `- Mentionable: ${role.mentionable ? 'Yes' : 'No'}\n` +
                    `- Role Position: ${role.position}\n` +
                    `- Created By: ${executor.tag} (${executor.id})\n\n` +
                    `**Role Permissions:**\n\n` +
                    `${role.permissions.toArray().map(perm => `• ${perm}`).join('\n')}`
                )
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`*${role.guild.name}*`)
            );

            await wait(2000);
            await rolelog.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            }).catch((_) => {});
        }
    });

    client.on("roleDelete", async (role) => {
        let check = await client.util.BlacklistCheck(role.guild);
        if (check) return;

        let data = await client.db.get(`logs_${role.guild.id}`);
        if (!data || !data?.rolelog) return;

        const channel = data?.rolelog;
        const rolelog = await role.guild.channels.cache.get(channel);
        if (!rolelog) {
            await client.db.set(`logs_${role.guild.id}`, {
                voice: data ? data.voice : null,
                channel: data ? data.channel : null,
                rolelog: null,
                modlog: data ? data.modlog : null,
                message: data ? data.message : null,
                memberlog: data ? data.memberlog : null
            });
            return;
        }

        const auditLogs = await role.guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.RoleDelete });
        const logs = auditLogs.entries.first();
        const { executor, target, createdTimestamp } = logs;
        let difference = Date.now() - createdTimestamp;
        if (difference > 5000) return;

        if (data) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## Role Deleted: ${role.name}`),
                new TextDisplayBuilder().setContent(`**Deleted by:** ${executor.tag}`)
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**Role Information:**\n` +
                    `- Role Name: ${role.name}\n` +
                    `- Role ID: ${role.id}\n` +
                    `- Displayed Separately: ${role.hoist ? 'Yes' : 'No'}\n` +
                    `- Mentionable: ${role.mentionable ? 'Yes' : 'No'}\n` +
                    `- Deleted By: ${executor.tag} (${executor.id})\n\n` +
                    `**Role Permissions:**\n` +
                    `${role.permissions.toArray().map(perm => `- ${perm}`).join('\n')}`
                )
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`*${role.guild.name}*`)
            );

            await rolelog.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            }).catch(() => {});
        }
    });

    client.on("roleUpdate", async (oldRole, newRole) => {
        let check = await client.util.BlacklistCheck(oldRole.guild);
        if (check) return;

        let data = await client.db.get(`logs_${oldRole.guild.id}`);
        if (!data || !data?.rolelog) return;

        const channel = data?.rolelog;
        const rolelog = await oldRole.guild.channels.cache.get(channel);
        if (!rolelog) {
            await client.db.set(`logs_${oldRole.guild.id}`, {
                voice: data ? data.voice : null,
                channel: data ? data.channel : null,
                rolelog: null,
                modlog: data ? data.modlog : null,
                message: data ? data.message : null,
                memberlog: data ? data.memberlog : null
            });
            return;
        }

        const auditLogs = await newRole.guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.RoleUpdate });
        const logs = auditLogs.entries.first();
        if (!logs) return;

        const { executor, createdTimestamp } = logs;
        let difference = Date.now() - createdTimestamp;
        if (difference > 5000) return;

        let changes = [];
        if (oldRole.name !== newRole.name) {
            changes.push(`**Name:** Old: \`${oldRole.name}\` → New: \`${newRole.name}\``);
        }
        if (oldRole.color !== newRole.color) {
            changes.push(`**Color:** Old: \`${oldRole.color}\` → New: \`${newRole.color}\``);
        }
        if (oldRole.hoist !== newRole.hoist) {
            changes.push(`**Display:** Old: \`${oldRole.hoist}\` → New: \`${newRole.hoist}\``);
        }
        if (oldRole.mentionable !== newRole.mentionable) {
            changes.push(`**Mentionable:** Old: \`${oldRole.mentionable}\` → New: \`${newRole.mentionable}\``);
        }

        const formatPermissions = permissions => permissions instanceof PermissionsBitField
            ? permissions.toArray().map(permission => `\`${permission}\``).join(', ')
            : 'No Permissions';

        changes.push(`**Permissions:**\nOld: ${formatPermissions(oldRole.permissions)}\nNew: ${formatPermissions(newRole.permissions)}`);

        const container = new ContainerBuilder();
        container.setAccentColor(client.color);
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`## Role Update`),
            new TextDisplayBuilder().setContent(`**Updated by:** ${executor.tag}`)
        );
        container.addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        );
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `**Role:** ${oldRole}\n**Role ID:** ${oldRole.id}\n**Executor:** ${executor.tag}\n**Executor ID:** ${executor.id}\n\n` +
                `**Changes:**\n${changes.join('\n')}`
            )
        );
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`*${newRole.guild.name}*`)
        );

        await rolelog.send({ 
            components: [container],
            flags: MessageFlags.IsComponentsV2
        }).catch((err) => {});
    });
};
