const wait = require('wait');
const { 
    AuditLogEvent, 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags 
} = require('discord.js');

module.exports = async (client) => {

    client.on("guildBanAdd", async (guild, user) => {
        let check = await client.util.BlacklistCheck(guild.guild);
        if (check) return;
        let data = await client.db.get(`logs_${guild?.guild?.id}`);
        if (!data || !data?.modlog) return;
        const channel = data?.modlog;
        const modlog1 = await guild?.guild?.channels.cache.get(channel);
        if (!modlog1) {
            await client.db.set(`logs_${guild?.guild?.id}`, {
                voice: data ? data.voice : null,
                channel: data ? data.channel : null,
                rolelog: data ? data.rolelog : null,
                modlog: null,
                message: data ? data.message : null,
                memberlog: data ? data.memberlog : null
            });
            return;
        }
        const auditLogs = await guild?.guild?.fetchAuditLogs({ limit: 1, type: AuditLogEvent.MemberBanAdd });
        const logs = auditLogs.entries.first();
        if (!logs) return;
        const { executor, target, createdTimestamp } = logs;
        let difference = Date.now() - createdTimestamp;
        if (difference > 5000) return;
        if (data) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## ${target.username} was banned`),
                new TextDisplayBuilder().setContent(`**Banned By:** ${executor.tag}`)
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**Banned By:** ${executor.tag} (${executor.id})`
                )
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`*${guild.guild.name}*`)
            );

            await wait(2000);
            await modlog1.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            }).catch((_) => {});
        }
    });

    client.on("guildBanRemove", async (guild, user) => {
        let check = await client.util.BlacklistCheck(guild.guild);
        if (check) return;
        let data = await client.db.get(`logs_${guild?.guild?.id}`);
        if (!data || !data?.modlog) return;
        const channel = data?.modlog;
        const modlog1 = await guild?.guild?.channels.cache.get(channel);
        if (!modlog1) {
            await client.db.set(`logs_${guild?.guild?.id}`, {
                voice: data ? data.voice : null,
                channel: data ? data.channel : null,
                rolelog: data ? data.rolelog : null,
                modlog: null,
                message: data ? data.message : null,
                memberlog: data ? data.memberlog : null
            });
            return;
        }
        const auditLogs = await guild?.guild?.fetchAuditLogs({ limit: 1, type: AuditLogEvent.MemberBanRemove });
        const logs = auditLogs.entries.first();
        const { executor, target, createdTimestamp } = logs;
        let difference = Date.now() - createdTimestamp;
        if (difference > 5000) return;
        if (data) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## ${target.username} was unbanned`),
                new TextDisplayBuilder().setContent(`**Unbanned By:** ${executor.tag}`)
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**Unbanned By:** ${executor.tag} (${executor.id})`
                )
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`*${guild.guild.name}*`)
            );

            await wait(2000);
            await modlog1.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            }).catch((_) => {});
        }
    });

    client.on("guildMemberRemove", async (member) => {
        let check = await client.util.BlacklistCheck(member.guild);
        if (check) return;

        let data = await client.db.get(`logs_${member.guild.id}`);
        if (!data || !data.modlog) return;

        const channelID = data.modlog;
        const modlogChannel = member.guild.channels.cache.get(channelID);

        if (!modlogChannel) {
            await client.db.set(`logs_${member.guild.id}`, {
                voice: data ? data.voice : null,
                channel: data ? data.channel : null,
                rolelog: data ? data.rolelog : null,
                modlog: null,
                message: data ? data.message : null,
                memberlog: data ? data.memberlog : null
            });
            return;
        }
        const auditLogs = await member.guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.MemberKick });
        const logEntry = auditLogs.entries.first();

        if (!logEntry) return;

        const { executor, target, createdTimestamp } = logEntry;
        const difference = Date.now() - createdTimestamp;

        if (difference > 5000) return;

        if (data) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## ${member.user.username} was kicked`),
                new TextDisplayBuilder().setContent(`**Kicked By:** ${executor.tag}`)
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**Kicked By:** ${executor.tag} (${executor.id})`
                )
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`*${member.guild.name}*`)
            );

            await wait(2000);
            await modlogChannel.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            }).catch((_) => {});
        }
    });
};
