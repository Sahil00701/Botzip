const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags 
} = require("discord.js");
const wait = require('wait');

module.exports = async (client) => {
    client.on('voiceStateUpdate', async (oldState, newState) => {
        let check = await client.util.BlacklistCheck(oldState.guild);
        if (check) return;
        let data = await client.db.get(`logs_${oldState.guild.id}`);
        if (!data || !data?.voice) return;
        const channell = data?.voice;
        const voicelog = await oldState.guild.channels.cache.get(channell);
        if (!voicelog) {
            await client.db.set(`logs_${oldState.guild.id}`, {
                voice: null,
                channel: data ? data.channel : null,
                rolelog: data ? data.rolelog : null,
                modlog: data ? data.modlog : null,
                message: data ? data.message : null,
                memberlog: data ? data.memberlog : null,
            });
            return;
        }
        const member = newState.member;
        const channel = newState.channel;

        if (!oldState.channelId && newState.channelId) {
            const joinedChannel = newState.channel.name || 'NONE';

            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## Member Joined Voice Channel`),
                new TextDisplayBuilder().setContent(`**Member:** ${member.user.tag}`)
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${member.user.tag} joined voice channel "${joinedChannel}"\n\n` +
                    `**Channel:** ${joinedChannel}`
                )
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`*${member.user.tag} joined voice channel*`)
            );

            await wait(2000);
            await voicelog.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            }).catch((err) => null);
        }

        if (oldState.channelId && !newState.channelId) {
            const leftChannel = oldState.channel.name || 'NONE';

            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## Member Left Voice Channel`),
                new TextDisplayBuilder().setContent(`**Member:** ${member.user.tag}`)
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${member.user.tag} left voice channel "${leftChannel}"\n\n` +
                    `**Channel:** ${leftChannel}`
                )
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`*${member.user.tag} left voice channel*`)
            );

            await wait(2000);
            await voicelog.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            }).catch((err) => null);
        }

        if (
            oldState.channelId !== newState.channelId &&
            oldState.channel && newState.channel
        ) {
            let oldChannel = oldState.channel.name;
            let newChannel = newState.channel.name;

            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## Member Moved Voice Channels`),
                new TextDisplayBuilder().setContent(`**Member:** ${member.user.tag}`)
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${member.user.tag} moved from "${oldChannel}" to "${newChannel}"\n\n` +
                    `**From:** ${oldChannel}\n` +
                    `**To:** ${newChannel}`
                )
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`*${member.user.tag} was moved from voice*`)
            );

            try {
                await wait(2000);
                await voicelog.send({ 
                    components: [container],
                    flags: MessageFlags.IsComponentsV2
                });
            } catch (err) {
                return;
            }
        }

        if (oldState.channel) {
            if (oldState.streaming !== newState.streaming) {
                const container = new ContainerBuilder();
                container.setAccentColor(client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`## Screen Sharing Update`),
                    new TextDisplayBuilder().setContent(`**Member:** ${member.user.tag}`)
                );
                container.addSeparatorComponents(
                    new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
                );
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `${member.user.tag} has ${newState.streaming ? 'started' : 'stopped'} screen sharing in \`${channel ? channel.name : 'a channel'}\`\n\n` +
                        `**Channel:** ${channel ? channel.name : 'N/A'}`
                    )
                );
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`*${member.user.tag} updated screen sharing*`)
                );

                try {
                    await wait(2000);
                    await voicelog.send({ 
                        components: [container],
                        flags: MessageFlags.IsComponentsV2
                    });
                } catch (err) {
                    console.error('Failed to send screen sharing log:', err);
                }
            }

            let changes = [];

            if (oldState.serverMute !== newState.serverMute) {
                changes.push({
                    title: newState.serverMute ? 'User Server Muted' : 'User Server Unmuted',
                    description: `${member.user.tag} has been ${newState.serverMute ? 'server muted' : 'server unmuted'} in \`${channel ? channel.name : 'a channel'}\``,
                });
            }

            if (oldState.serverDeaf !== newState.serverDeaf) {
                changes.push({
                    title: newState.serverDeaf ? 'User Server Deafened' : 'User Server Undeafened',
                    description: `${member.user.tag} has been ${newState.serverDeaf ? 'server deafened' : 'server undeafened'} in \`${channel ? channel.name : 'a channel'}\``,
                });
            }

            for (const change of changes) {
                const container = new ContainerBuilder();
                container.setAccentColor(client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`## ${change.title}`),
                    new TextDisplayBuilder().setContent(`**Member:** ${member.user.tag}`)
                );
                container.addSeparatorComponents(
                    new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
                );
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(change.description)
                );
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`*${member.user.tag} updated voice state*`)
                );

                try {
                    await wait(2000);
                    await voicelog.send({ 
                        components: [container],
                        flags: MessageFlags.IsComponentsV2
                    });
                } catch (err) {
                    console.error('Failed to send voice state log:', err);
                }
            }
        }
    });
};
