const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags 
} = require('discord.js');
const wait = require('wait');

module.exports = async (client) => {

    client.on('guildMemberAdd', async (member) => {
        let check = await client.util.BlacklistCheck(member.guild);
        if (check) return;
        let data = await client.db.get(`logs_${member.guild.id}`);
        if (!data || !data.memberlog) return;
        const cchannel = data?.memberlog;
        const channellog = await member.guild.channels.cache.get(cchannel);
        if (!channellog) {
            await client.db.set(`logs_${member.guild.id}`, {
                voice: data ? data.voice : null,
                channel: data ? data.channel : null,
                rolelog: data ? data.rolelog : null,
                modlog: data ? data.modlog : null,
                message: data ? data.message : null,
                memberlog: null
            });
            return;
        }
        if (data) {
            let rolesText = '';
            if (member.roles && member.roles.cache.size > 0) {
                const addedRoles = member.roles.cache.map(role => `<@&${role.id}>`).join(', ');
                rolesText = `\n**Added Roles:** ${addedRoles}`;
            }

            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## Member Joined`),
                new TextDisplayBuilder().setContent(`**Member:** ${member.user.tag}`)
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `A new member has joined the server.\n` +
                    `**Account created at:** <t:${Math.round(member.user.createdTimestamp / 1000)}:R>\n` +
                    `**Member joined at:** <t:${Math.round(member.joinedTimestamp / 1000)}:R>\n` +
                    `**Member ID:** ${member.id}` +
                    rolesText
                )
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`*${member.guild.name}*`)
            );

            await wait(2000);
            await channellog.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            }).catch((_) => {});
        }
    });

    client.on("guildMemberUpdate", async (oldMember, newMember) => {
        let check = await client.util.BlacklistCheck(oldMember.guild);
        if (check) return;
        let data = await client.db.get(`logs_${oldMember?.guild?.id}`);
        if (!data || !data.memberlog) return;
        const cchannel = data?.memberlog;
        const channellog = await oldMember.guild.channels.cache.get(cchannel);
        if (!channellog) {
            await client.db.set(`logs_${oldMember.guild.id}`, {
                voice: data ? data.voice : null,
                channel: data ? data.channel : null,
                rolelog: data ? data.rolelog : null,
                modlog: data ? data.modlog : null,
                message: data ? data.message : null,
                memberlog: null
            });
            return;
        }
        if (data) {
            if (oldMember.nickname !== newMember.nickname) {
                const container = new ContainerBuilder();
                container.setAccentColor(client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`## Member Nickname Update`),
                    new TextDisplayBuilder().setContent(`**Member:** ${newMember.user.tag}`)
                );
                container.addSeparatorComponents(
                    new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
                );
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `**Old Nickname:** ${oldMember.nickname || 'None'}\n` +
                        `**New Nickname:** ${newMember.nickname || 'None'}\n` +
                        `**Member:** <@${newMember.id}>\n` +
                        `**Member ID:** ${newMember.id}`
                    )
                );
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`*${newMember.guild.name}*`)
                );

                await channellog.send({ 
                    components: [container],
                    flags: MessageFlags.IsComponentsV2
                }).catch((_) => {});
            }
        }
    });

    client.on("guildMemberUpdate", async (oldMember, newMember) => {
        try {
            let check = await client.util.BlacklistCheck(oldMember.guild);
            if (check) return;
            let data = await client.db.get(`logs_${oldMember.guild.id}`);
            if (!data || !data.memberlog) return;
            const cchannel = data?.memberlog;
            const channellog = await oldMember.guild.channels.cache.get(cchannel);
            if (!channellog) {
                await client.db.set(`logs_${oldMember.guild.id}`, {
                    voice: data ? data.voice : null,
                    channel: data ? data.channel : null,
                    rolelog: data ? data.rolelog : null,
                    modlog: data ? data.modlog : null,
                    message: data ? data.message : null,
                    memberlog: null
                });
                return;
            }

            if (data) {
                const addedRoles = newMember.roles.cache.filter(role => !oldMember.roles.cache.has(role.id));
                const removedRoles = oldMember.roles.cache.filter(role => !newMember.roles.cache.has(role.id));
                const oldTopRole = oldMember.roles.highest;
                const newTopRole = newMember.roles.highest;

                if (addedRoles.size > 0 || removedRoles.size > 0 || oldTopRole.id !== newTopRole.id) {
                    let changes = [];

                    if (addedRoles.size > 0) {
                        changes.push(`**Added Roles:** ${addedRoles.map(role => `<@&${role.id}>`).join(', ')}`);
                    }

                    if (removedRoles.size > 0) {
                        changes.push(`**Removed Roles:** ${removedRoles.map(role => `<@&${role.id}>`).join(', ')}`);
                    }

                    if (oldTopRole.id !== newTopRole.id) {
                        changes.push(`**Top Role Update:**\nOld Top Role: <@&${oldTopRole.id}>\nNew Top Role: <@&${newTopRole.id}>`);
                    }

                    const container = new ContainerBuilder();
                    container.setAccentColor(client.color);
                    container.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`## Member Role Update`),
                        new TextDisplayBuilder().setContent(`**Member:** ${newMember.user.tag}`)
                    );
                    container.addSeparatorComponents(
                        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
                    );
                    container.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            changes.join('\n') + `\n\n` +
                            `**Member:** <@${newMember.id}>\n` +
                            `**Member ID:** ${newMember.id}`
                        )
                    );
                    container.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`*${newMember.guild.name}*`)
                    );

                    await wait(2000);
                    await channellog.send({ 
                        components: [container],
                        flags: MessageFlags.IsComponentsV2
                    }).catch((_) => {});
                }
            }
        } catch (err) {
            return;
        }
    });

    client.on("guildMemberRemove", async (member) => {
        let check = await client.util.BlacklistCheck(member.guild);
        if (check) return;

        let data = await client.db.get(`logs_${member.guild.id}`);
        if (!data || !data.memberlog) return;
        const cchannel = data?.memberlog;
        const channellog = await member.guild.channels.cache.get(cchannel);
        if (!channellog) {
            await client.db.set(`logs_${member.guild.id}`, {
                voice: data ? data.voice : null,
                channel: data ? data.channel : null,
                rolelog: data ? data.rolelog : null,
                modlog: data ? data.modlog : null,
                message: data ? data.message : null,
                memberlog: null
            });
            return;
        }

        if (data) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## Member Left`),
                new TextDisplayBuilder().setContent(`**Member:** ${member.user.tag}`)
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${member} left the server.\n` +
                    `**Account created at:** <t:${Math.round(member.user.createdTimestamp / 1000)}:R>\n` +
                    `**Member ID:** ${member.id}`
                )
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`*${member.guild.name}*`)
            );

            await wait(2000);
            await channellog.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            }).catch((_) => {});
        }
    });
};
