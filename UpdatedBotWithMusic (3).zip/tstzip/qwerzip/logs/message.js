const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags 
} = require('discord.js');
const discordTranscripts = require('discord-html-transcripts');

module.exports = async (client) => {
    const wait = require('wait');

    client.on('messageDelete', async (message) => {
        let check = await client.db.get(`blacklistserver_${client.user.id}`) || [];
        if (check.includes(message?.guild?.id)) return;
        let data = await client.db.get(`logs_${message?.guild?.id}`);
        if (message?.author?.bot || !message?.guild || message?.system) return;
        if (!data || !data?.message) return;
        const channel = data?.message;
        const msglogs = await message.guild.channels.cache.get(channel);
        if (!msglogs) {
            await client.db.set(`logs_${message.guild.id}`, {
                voice: data ? data.voice : null,
                channel: data ? data.channel : null,
                rolelog: data ? data.rolelog : null,
                modlog: data ? data.modlog : null,
                message: null,
                memberlog: data ? data.memberlog : null
            });
            return;
        }
        if (data) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## Message Delete`),
                new TextDisplayBuilder().setContent(`**Author:** ${message.author.tag}`)
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**Message Content:** ${message.content}\n\n` +
                    `**Author:** ${message.author.tag}\n` +
                    `**Messaged Deleted In:** ${message.channel}\n` +
                    `**Channel ID:** ${message.channel.id}`
                )
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`*${message.guild.name}*`)
            );

            await wait(2000);
            await msglogs.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            }).catch((_) => {});
        }
    });

    client.on('messageUpdate', async (oldMessage, newMessage) => {
        let check = await client.db.get(`blacklistserver_${client.user.id}`) || [];
        if (check.includes(oldMessage?.guild?.id)) return;
        let data = await client.db.get(`logs_${oldMessage?.guild?.id}`);
        if (!data || !data?.message) return;
        const channel = data?.message;
        const msglogs = await oldMessage.guild.channels.cache.get(channel);
        if (!msglogs) {
            await client.db.set(`logs_${oldMessage.guild.id}`, {
                voice: data ? data.voice : null,
                channel: data ? data.channel : null,
                rolelog: data ? data.rolelog : null,
                modlog: data ? data.modlog : null,
                message: null,
                memberlog: data ? data.memberlog : null
            });
            return;
        }
        if (!oldMessage.author) return;
        if (newMessage.author.bot) return;
        if (oldMessage.author.id === client.user.id) return;
        if (data) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## Message Edit`),
                new TextDisplayBuilder().setContent(`**Author:** ${newMessage.author.tag}`)
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**Original:** \`${oldMessage}\`\n\n` +
                    `**Edited:** \`${newMessage}\`\n\n` +
                    `**Author Id:** ${newMessage.author.id}\n` +
                    `**Author:** ${newMessage.author.tag}\n` +
                    `**Channel:** ${newMessage.channel}\n` +
                    `**Channel ID:** ${newMessage.channel.id}`
                )
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`*${newMessage.guild.name}*`)
            );

            await wait(2000);
            await msglogs.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            }).catch((_) => {});
        }
    });

    const deletedMessageCache = new Map();

    client.on('messageDeleteBulk', async (messages) => {
        const guildId = messages.first().guild.id;
        let check = await client.db.get(`blacklistserver_${client.user.id}`) || [];
        if (check.includes(guildId)) return;

        let data = await client.db.get(`logs_${guildId}`);
        if (!data || !data?.message) return;

        const channelID = data.message;
        const msglogs = await messages.first().guild.channels.cache.get(channelID);

        if (!msglogs) {
            await client.db.set(`logs_${guildId}`, {
                voice: data ? data.voice : null,
                channel: data ? data.channel : null,
                rolelog: data ? data.rolelog : null,
                modlog: data ? data.modlog : null,
                message: null,
                memberlog: data ? data.memberlog : null
            });
            return;
        }

        const deletedChannel = messages.first().channel;
        
        const container = new ContainerBuilder();
        container.setAccentColor(client.color);
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`## Bulk Message Delete`)
        );
        container.addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        );
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `**${messages.size} messages** were deleted in ${deletedChannel}.`
            )
        );
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`*${messages.first().guild.name}*`)
        );

        const cachedMessages = deletedMessageCache.get(guildId) || new Map();
        const deletedMessages = Array.from(messages.values());

        const sortedMessages = deletedMessages.reverse();
        const transcript = await discordTranscripts.generateFromMessages(sortedMessages, deletedChannel, {
            limit: -1,
            returnType: 'attachment',
            filename: 'Spyder-deleted-messages.html',
            saveImages: true,
            footerText: "Spyder Message Delete Log Exported {number} message{s}",
            callbacks: {
                resolveChannel: (channelId) => client.channels.cache.get(channelId),
                resolveUser: (userId) => client.users.fetch(userId),
                resolveRole: (roleId) => deletedChannel.guild.roles.cache.get(roleId)
            },
            poweredBy: false,
            ssr: true
        });

        await msglogs.send({
            components: [container],
            flags: MessageFlags.IsComponentsV2,
            files: [transcript]
        }).catch((error) => {
            return;
        });
        deletedMessageCache.delete(guildId);
    });
};
