const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    Collection,
    WebhookClient,
    ActionRowBuilder,
    StringSelectMenuBuilder,
    AttachmentBuilder,
    PermissionsBitField,
    ChannelType,
    Partials,
    MessageFlags,
    ComponentType,
    MediaGalleryBuilder,
    MediaGalleryItemBuilder,
    ThumbnailBuilder
} = require('discord.js')
const { getSettingsar } = require('../models/autorole')

this.config = require(`${process.cwd()}/config.json`)
let globalCooldown
module.exports = class Util {
    constructor(client) {
        this.client = client
        this.blacklistCache = new Map();
        this.lastBlacklistRefresh = 0;
        this.BLACKLIST_CACHE_DURATION = 5 * 60 * 1000;
    }

    container(accentColor = null) {
        const container = new ContainerBuilder();
        if (accentColor) {
            container.setAccentColor(accentColor);
        }
        return container;
    }

    textDisplay(content) {
        return new TextDisplayBuilder().setContent(content);
    }

    separator(divider = true, spacing = SeparatorSpacingSize.Small) {
        return new SeparatorBuilder()
            .setDivider(divider)
            .setSpacing(spacing);
    }

    createMessage(description, color = null) {
        const container = new ContainerBuilder();
        if (color) {
            container.setAccentColor(color);
        }
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(description)
        );
        return {
            components: [container],
            flags: MessageFlags.IsComponentsV2
        };
    }

    createMessageWithTitle(title, description, color = null) {
        const container = new ContainerBuilder();
        if (color) {
            container.setAccentColor(color);
        }
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`## ${title}`),
            new TextDisplayBuilder().setContent(description)
        );
        return {
            components: [container],
            flags: MessageFlags.IsComponentsV2
        };
    }

    createMessageWithFields(title, description, fields, color = null) {
        const container = new ContainerBuilder();
        if (color) {
            container.setAccentColor(color);
        }
        if (title) {
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## ${title}`)
            );
        }
        if (description) {
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(description)
            );
        }
        if (fields && fields.length > 0) {
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            for (const field of fields) {
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**${field.name}**\n${field.value}`)
                );
            }
        }
        return {
            components: [container],
            flags: MessageFlags.IsComponentsV2
        };
    }

    async sendPreview(settings, member) {
        if (!settings.welcome?.enabled)
            return 'Welcome message not enabled in this server'

        const targetChannel = member.guild.channels.cache.get(
            settings.welcome.channel
        )
        if (!targetChannel)
            return 'No channel is configured to send welcome message'

        const response = await this.client.util.buildGreeting(
            member,
            'WELCOME',
            settings.welcome
        )

        let time = settings.welcome.autodel
        await this.client.util.sendMessage(targetChannel, response, time)

        return `Sent welcome preview to ${targetChannel.toString()}`
    }

    async setStatus(settings, status) {
        const enabled = status.toUpperCase() === 'ON' ? true : false
        settings.welcome.enabled = enabled
        await settings.save()
        return `Configuration saved! Welcome message ${enabled ? '**enabled**' : '**disabled**'}`
    }

    async setChannel(settings, channel) {
        if (!this.client.util.canSendMessages(channel)) {
            return (
                'Ugh! I cannot send greeting to that channel? I need the `Write Messages` permissions in ' +
                channel.toString()
            )
        }
        settings.welcome.channel = channel.id
        await settings.save()
        return `Configuration saved! Welcome message will be sent to ${channel ? channel.toString() : 'Not found'}`
    }

    async setDescription(settings, desc) {
        settings.welcome.embed.description = desc
        await settings.save()
        return 'Configuration saved! Welcome message updated'
    }

    async setTitle(settings, title) {
        settings.welcome.embed.title = title
        await settings.save()
        return 'Configuration saved! Welcome message updated'
    }

    async setImage(settings, image) {
        settings.welcome.embed.image = image
        await settings.save()
        return 'Configuration saved! Welcome image updated'
    }

    async setThumbnail(settings, status) {
        settings.welcome.embed.thumbnail =
            status.toUpperCase() === 'ON' ? true : false
        await settings.save()
        return 'Configuration saved! Welcome message updated'
    }

    canSendMessages(channel) {
        return channel.permissionsFor(channel.guild.members.me).has(['SendMessages'])
    }

    async buildGreeting(member, type, config) {
        if (!config) return
        let content = config.content
            ? await this.client.util.parse(config.content, member)
            : `<@${member.user.id}>`
        
        const container = new ContainerBuilder();
        container.setAccentColor(config.embed?.color ? parseInt(config.embed.color.replace('#', ''), 16) : this.client.color);
        
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(content)
        );

        if (config.embed?.thumbnail) {
            const thumbnailUrl = (config.embed.thumbnail === true || config.embed.thumbnail === '{member:avatar}')
                ? member.user.displayAvatarURL({ size: 256 })
                : (typeof config.embed.thumbnail === 'string' && config.embed.thumbnail.startsWith('http'))
                    ? config.embed.thumbnail
                    : member.user.displayAvatarURL({ size: 256 });
            container.addMediaGalleryComponents(
                new MediaGalleryBuilder().addItems(
                    new MediaGalleryItemBuilder().setURL(thumbnailUrl)
                )
            );
        }
        
        let descriptionText = '';
        if (config.embed?.title) {
            descriptionText += `## ${await this.client.util.parse(config.embed.title, member)}\n`;
        }
        if (config.embed?.description) {
            descriptionText += await this.client.util.parse(config.embed.description, member);
        }
        if (config.embed?.footer) {
            descriptionText += `\n\n*${await this.client.util.parse(config.embed.footer, member)}*`;
        }

        if (!config.content && !config.embed?.description && !config.embed?.footer) {
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `Hey ${member.displayName}, Welcome to the server <a:welcome:1188456678392348702>.`
                )
            );
            return { 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            }
        }

        if (descriptionText) {
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(descriptionText)
            );
        }

        if (config.embed?.image) {
            const imageUrl = config.embed.image === '{member:avatar}' 
                ? member.user.displayAvatarURL({ size: 1024 })
                : config.embed.image;
            container.addMediaGalleryComponents(
                new MediaGalleryBuilder().addItems(
                    new MediaGalleryItemBuilder().setURL(imageUrl)
                )
            );
        }

        return { 
            components: [container],
            flags: MessageFlags.IsComponentsV2
        }
    }

    async sendMessage(channel, content, seconds) {
        if (!channel || !content) return
        const perms = new PermissionsBitField(['ViewChannel', 'SendMessages']);
        if (
            channel.type !== ChannelType.DM &&
            !channel.permissionsFor(channel.guild.members.me).has(perms)
        )
            return
        try {
            if (!seconds || seconds == 0) return await channel.send(content)
            const reply = await channel.send(content)
            setTimeout(
                () => reply.deletable && reply.delete().catch((ex) => {}),
                seconds * 1000
            )
        } catch (ex) {
            return
        }
    }

    async sendWelcome(member, settings) {
        const config = (await getSettingsar(member.guild))?.welcome
        if (!config || !config.enabled) return

        const channel = member.guild.channels.cache.get(config.channel)
        if (!channel) return

        const response = await this.client.util.buildGreeting(
            member,
            'WELCOME',
            config
        )

        this.client.util.sendMessage(
            channel,
            response,
            settings.welcome.autodel
        )
    }

    async getPrefix(guildId) {
        if (!guildId) return '&';
        // Cache prefix in memory to avoid constant DB hits
        if (this.client.prefixCache?.has(guildId)) {
            const cached = this.client.prefixCache.get(guildId);
            if (cached !== undefined && cached !== "undefined" && cached !== null) return cached;
        }
        
        let prefix = await this.client.redis.get(`${guildId}_prefix`);
        if (!prefix || prefix === "undefined" || prefix === "null") {
            prefix = await this.client.db.get(`${guildId}_prefix`);
            if (!prefix || prefix === "undefined" || prefix === "null") prefix = '&';
            await this.client.redis.set(`${guildId}_prefix`, prefix);
        }
        
        if (this.client.prefixCache) this.client.prefixCache.set(guildId, prefix);
        return prefix;
    }

    async refreshBlacklistCache() {
        try {
            const data = await this.client.db.get(`blacklistserver_${this.client.user.id}`) || [];
            this.blacklistCache.clear();
            data.forEach(guildId => this.blacklistCache.set(guildId, true));
            this.lastBlacklistRefresh = Date.now();
        } catch (error) {
            console.error('Error refreshing blacklist cache:', error);
        }
    }

    async BlacklistCheck(guild) {
        if (!guild) return false;
        if (this.blacklistCache.has(guild.id)) return true;
        
        // Refresh cache in background if expired, don't wait for it
        if (Date.now() - this.lastBlacklistRefresh > this.BLACKLIST_CACHE_DURATION) {
            this.refreshBlacklistCache();
        }
        
        return false;
    }

    isBlacklistedSync(guildId) {
        return this.blacklistCache.has(guildId);
    }

    async parse(content, member) {
        let mention = `<@${member.user.id}>`
        return content
            .replaceAll(/\\n/g, '\n')
            .replaceAll(/{server}/g, member.guild.name)
            .replaceAll(/{count}/g, member.guild.memberCount)
            .replaceAll(/{member:name}/g, member.displayName)
            .replaceAll(/{member:mention}/g, mention)
            .replaceAll(/{member:id}/g, member.user.id)
            .replaceAll(/{member:created_at}/g, `<t:${Math.round(member.user.createdTimestamp / 1000)}:R>`)
    }

    async purgeMessages(issuer, channel, type, amount, argument) {
        if (
            !channel
                .permissionsFor(issuer)
                .has(['MANAGE_MESSAGES', 'READ_MESSAGE_HISTORY'])
        ) {
            return 'MEMBER_PERM'
        }

        if (
            !channel
                .permissionsFor(issuer.guild.me)
                .has(['MANAGE_MESSAGES', 'READ_MESSAGE_HISTORY'])
        ) {
            return 'BOT_PERM'
        }

        const toDelete = new Collection()

        try {
            const messages = await channel.messages.fetch(
                { limit: amount },
                { cache: false, force: true }
            )

            for (const message of messages.values()) {
                if (toDelete.size >= amount) break
                if (!message.deletable) continue

                if (type === 'ALL') {
                    toDelete.set(message.id, message)
                } else if (type === 'ATTACHMENT') {
                    if (message.attachments.size > 0) {
                        toDelete.set(message.id, message)
                    }
                } else if (type === 'BOT') {
                    if (message.author.bot) {
                        toDelete.set(message.id, message)
                    }
                } else if (type === 'LINK') {
                    if (containsLink(message.content)) {
                        toDelete.set(message.id, message)
                    }
                } else if (type === 'TOKEN') {
                    if (message.content.includes(argument)) {
                        toDelete.set(message.id, message)
                    }
                } else if (type === 'USER') {
                    if (message.author.id === argument) {
                        toDelete.set(message.id, message)
                    }
                }
            }

            if (toDelete.size === 0) return 'NO_MESSAGES'

            const deletedMessages = await channel.bulkDelete(toDelete, true)
            return deletedMessages.size
        } catch (ex) {
            return 'ERROR'
        }
    }

    async isExtraOwner(member, guild) {
        const data = await this.client.db.get(`extraowner_${guild.id}`)
        if (!data) return false
        if (data?.owner?.includes(member.id)) return true
        else return false
    }

    hasHigher(member) {
        if (
            member.roles.highest.position <=
                member.guild.members.me.roles.highest.position &&
            member.user.id != member.guild.ownerId
        )
            return false
        else return true
    }

    async selectMenuHandle(interaction) {
        try {
            let options = interaction.values
            const funny = options[0]
            let _commands

            const createCategoryMessage = (categoryName, emoji, cmdList) => {
                const container = new ContainerBuilder();
                container.setAccentColor(this.client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`## ${categoryName} Commands`)
                );
                container.addSeparatorComponents(
                    new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
                );
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**${emoji} ${categoryName} \`[${cmdList.length}]\`**\n${cmdList.sort().join(', ')}`)
                );
                return {
                    components: [container],
                    flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
                };
            };

            if (funny === 'antinuke') {
                let cmdList = [];
                interaction.client.commands
                    .filter((cmd) => cmd.category === 'security')
                    .forEach((cmd) => {
                        if (cmd.subcommand && cmd.subcommand.length) {
                            cmdList.push(`\`${cmd.name}\``);
                            cmd.subcommand.forEach((subCmd) => {
                                cmdList.push(`\`${cmd.name} ${subCmd}\``);
                            });
                        } else {
                            cmdList.push(`\`${cmd.name}\``);
                        }
                    });
                
                const msg = createCategoryMessage('Antinuke', '<:antinuke:1436754524734750780>', cmdList);
                interaction.reply(msg).catch((_) => {});
                return;
            }

            if (funny === 'moderation') {
                let cmdList = [];
                interaction.client.commands
                    .filter((cmd) => cmd.category === 'mod')
                    .forEach((cmd) => {
                        if (cmd.subcommand && cmd.subcommand.length) {
                            cmdList.push(`\`${cmd.name}\``);
                            cmd.subcommand.forEach((subCmd) => {
                                cmdList.push(`\`${cmd.name} ${subCmd}\``);
                            });
                        } else {
                            cmdList.push(`\`${cmd.name}\``);
                        }
                    });
                
                const msg = createCategoryMessage('Moderation', '<:moderation:1436754537548353827>', cmdList);
                interaction.reply(msg).catch((_) => {});
                return;
            }

            if (funny === 'automod') {
                let cmdList = [];
                interaction.client.commands
                    .filter((cmd) => cmd.category === 'automod')
                    .forEach((cmd) => {
                        if (cmd.subcommand && cmd.subcommand.length) {
                            cmdList.push(`\`${cmd.name}\``);
                            cmd.subcommand.forEach((subCmd) => {
                                cmdList.push(`\`${cmd.name} ${subCmd}\``);
                            });
                        } else {
                            cmdList.push(`\`${cmd.name}\``);
                        }
                    });
                
                const msg = createCategoryMessage('Automod', '<:automod:1436754550643101756>', cmdList);
                interaction.reply(msg).catch((_) => {});
                return;
            }

            if (funny === 'logger') {
                let cmdList = [];
                interaction.client.commands
                    .filter((cmd) => cmd.category === 'logging')
                    .forEach((cmd) => {
                        if (cmd.subcommand && cmd.subcommand.length) {
                            cmdList.push(`\`${cmd.name}\``);
                            cmd.subcommand.forEach((subCmd) => {
                                cmdList.push(`\`${cmd.name} ${subCmd}\``);
                            });
                        } else {
                            cmdList.push(`\`${cmd.name}\``);
                        }
                    });
                
                const msg = createCategoryMessage('Logging', '<:logger:1436754563452502187>', cmdList);
                interaction.reply(msg).catch((_) => {});
                return;
            }

            if (funny === 'utility') {
                let cmdList = [];
                interaction.client.commands
                    .filter((cmd) => cmd.category === 'info')
                    .forEach((cmd) => {
                        if (cmd.subcommand && cmd.subcommand.length) {
                            cmdList.push(`\`${cmd.name}\``);
                            cmd.subcommand.forEach((subCmd) => {
                                cmdList.push(`\`${cmd.name} ${subCmd}\``);
                            });
                        } else {
                            cmdList.push(`\`${cmd.name}\``);
                        }
                    });
                
                const msg = createCategoryMessage('Utility', '<:utility:1436754577528459408>', cmdList);
                interaction.reply(msg).catch((_) => {});
                return;
            }

            if (funny === 'serverutility') {
                let cmdList = [];
                interaction.client.commands
                    .filter((cmd) => cmd.category === 'leaderboard')
                    .forEach((cmd) => {
                        if (cmd.subcommand && cmd.subcommand.length) {
                            cmdList.push(`\`${cmd.name}\``);
                            cmd.subcommand.forEach((subCmd) => {
                                cmdList.push(`\`${cmd.name} ${subCmd}\``);
                            });
                        } else {
                            cmdList.push(`\`${cmd.name}\``);
                        }
                    });
                
                const msg = createCategoryMessage('Server Utility', '<:SpyderBlackServerconfig:1276115343638528062>', cmdList);
                interaction.reply(msg).catch((_) => {});
                return;
            }

            if (funny === 'verification') {
                let cmdList = [];
                interaction.client.commands
                    .filter((cmd) => cmd.category === 'verification')
                    .forEach((cmd) => {
                        if (cmd.subcommand && cmd.subcommand.length) {
                            cmdList.push(`\`${cmd.name}\``);
                            cmd.subcommand.forEach((subCmd) => {
                                cmdList.push(`\`${cmd.name} ${subCmd}\``);
                            });
                        } else {
                            cmdList.push(`\`${cmd.name}\``);
                        }
                    });
                
                const msg = createCategoryMessage('Verification', '<:SpyderBlackVerification:1276115246976729088>', cmdList);
                interaction.reply(msg).catch((_) => {});
                return;
            }

            if (funny === 'jointocreate') {
                let cmdList = [];
                interaction.client.commands
                    .filter((cmd) => cmd.category === 'jointocreate')
                    .forEach((cmd) => {
                        if (cmd.subcommand && cmd.subcommand.length) {
                            cmdList.push(`\`${cmd.name}\``);
                            cmd.subcommand.forEach((subCmd) => {
                                cmdList.push(`\`${cmd.name} ${subCmd}\``);
                            });
                        } else {
                            cmdList.push(`\`${cmd.name}\``);
                        }
                    });
                
                const msg = createCategoryMessage('Join To Create', '<:jointocreate:1436754590002315337>', cmdList);
                interaction.reply(msg).catch((_) => {});
                return;
            }

            if (funny === 'premiumfeatures') {
                let cmdList = [];
                interaction.client.commands
                    .filter((cmd) => cmd.category === 'premiumfeatures')
                    .forEach((cmd) => {
                        if (cmd.subcommand && cmd.subcommand.length) {
                            cmdList.push(`\`${cmd.name}\``);
                            cmd.subcommand.forEach((subCmd) => {
                                cmdList.push(`\`${cmd.name} ${subCmd}\``);
                            });
                        } else {
                            cmdList.push(`\`${cmd.name}\``);
                        }
                    });
                
                const msg = createCategoryMessage('Premium Activity System', '<a:Spyder_antinuke:1180431827438153821>', cmdList);
                interaction.reply(msg).catch((_) => {});
                return;
            }

            if (funny === 'voice') {
                let cmdList = [];
                interaction.client.commands
                    .filter((cmd) => cmd.category === 'voice')
                    .forEach((cmd) => {
                        if (cmd.subcommand && cmd.subcommand.length) {
                            cmdList.push(`\`${cmd.name}\``);
                            cmd.subcommand.forEach((subCmd) => {
                                cmdList.push(`\`${cmd.name} ${subCmd}\``);
                            });
                        } else {
                            cmdList.push(`\`${cmd.name}\``);
                        }
                    });
                
                const msg = createCategoryMessage('Voice', '<:voice:1436754603008856125>', cmdList);
                interaction.reply(msg).catch((_) => {});
                return;
            }

            if (funny === 'customrole') {
                let cmdList = [];
                interaction.client.commands
                    .filter((cmd) => cmd.category === 'customrole')
                    .forEach((cmd) => {
                        if (cmd.subcommand && cmd.subcommand.length) {
                            cmdList.push(`\`${cmd.name}\``);
                            cmd.subcommand.forEach((subCmd) => {
                                cmdList.push(`\`${cmd.name} ${subCmd}\``);
                            });
                        } else {
                            cmdList.push(`\`${cmd.name}\``);
                        }
                    });
                
                const msg = createCategoryMessage('Custom Role', '<:customrole:1436754616477024356>', cmdList);
                interaction.reply(msg).catch((_) => {});
                return;
            }

            if (funny === 'welcomer') {
                let cmdList = [];
                interaction.client.commands
                    .filter((cmd) => cmd.category === 'welcomer')
                    .forEach((cmd) => {
                        if (cmd.subcommand && cmd.subcommand.length) {
                            cmdList.push(`\`${cmd.name}\``);
                            cmd.subcommand.forEach((subCmd) => {
                                cmdList.push(`\`${cmd.name} ${subCmd}\``);
                            });
                        } else {
                            cmdList.push(`\`${cmd.name}\``);
                        }
                    });
                
                const msg = createCategoryMessage('Welcomer', '<:welcomer:1436754629328240721>', cmdList);
                interaction.reply(msg).catch((_) => {});
                return;
            }

            if (funny === 'ticket') {
                let cmdList = [];
                interaction.client.commands
                    .filter((cmd) => cmd.category === 'ticket')
                    .forEach((cmd) => {
                        if (cmd.subcommand && cmd.subcommand.length) {
                            cmdList.push(`\`${cmd.name}\``);
                            cmd.subcommand.forEach((subCmd) => {
                                cmdList.push(`\`${cmd.name} ${subCmd}\``);
                            });
                        } else {
                            cmdList.push(`\`${cmd.name}\``);
                        }
                    });
                
                const msg = createCategoryMessage('Ticket', '<:ticket:1436754643022516430>', cmdList);
                interaction.reply(msg).catch((_) => {});
                return;
            }

        } catch (err) {
            console.error('Select menu error:', err);
        }
    }

    async countCommandsAndSubcommands(client) {
        let cmdcount = 0
        client.commands.forEach((c) => {
            if (c.subcommand) {
                cmdcount += c.subcommand.length
            } else {
                cmdcount++
            }
        })
        return cmdcount
    }

    async setPrefix(message) {
        if (!message?.guild) return '&';
        let prefix = await this.client.redis.get(`${message.guild.id}_prefix`);
        if (!prefix || prefix === "undefined") {
            prefix = await this.client.db.get(`${message.guild.id}_prefix`);
            if (!prefix || prefix === "undefined") prefix = '&';
            await this.client.redis.set(`${message.guild.id}_prefix`, prefix);
        }
        message.guild.prefix = prefix;
        if (this.client.prefixCache) this.client.prefixCache.set(message.guild.id, prefix);
        return prefix;
    }

    async noprefix() {
        let datab = await this.client.db.get(`noprefix_${this.client.user.id}`)
        if (!datab) datab = []
        this.client.noprefix = datab
    }

    async blacklist() {
        let data = await this.client.db.get(`blacklist_${this.client.user.id}`)
        if (!data) data = []
        this.client.blacklist = data
    }

    async sleep(ms) {
        return new Promise((resolve) => setTimeout(resolve, ms))
    }

    async handleRateLimit() {
        await this.sleep(5000);
    }

    async manageAfk(message, client) {
        try {
            if (!message.guild || !message.author) return;
            const db = require(`${process.cwd()}/qwerzip/models/afk.js`);

            // 1. Check if the message author is AFK and remove it
            const authorAfk = await db.findOne({
                Member: message.author.id,
                $or: [
                    { IsGlobal: true },
                    { Guild: message.guildId }
                ]
            });

            if (authorAfk) {
                await db.deleteMany({ Member: message.author.id });
                const authorName = message.member?.displayName || message.author.username;
                const container = new ContainerBuilder();
                container.setAccentColor(client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`Welcome back **${authorName}**, I've removed your AFK.`)
                );
                message.reply({
                    components: [container],
                    flags: MessageFlags.IsComponentsV2
                }).then(m => {
                    setTimeout(() => m.delete().catch(() => {}), 5000);
                }).catch(() => {});
            }

            // 2. Check if any mentioned users are AFK
            if (message.mentions.users.size > 0) {
                for (const [id, user] of message.mentions.users) {
                    if (user.id === message.author.id) continue;
                    const afkData = await db.findOne({
                        Member: user.id,
                        $or: [
                            { IsGlobal: true },
                            { Guild: message.guildId }
                        ]
                    });
                    if (afkData) {
                        const timeAgo = `<t:${Math.floor(afkData.Time / 1000)}:R>`;
                        const mentionedMember = message.guild.members.cache.get(user.id);
                        const displayName = mentionedMember?.displayName || user.username;
                        const container = new ContainerBuilder();
                        container.setAccentColor(client.color);
                        container.addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**${displayName}** is AFK: ${afkData.Reason} - ${timeAgo}`)
                        );
                        message.reply({
                            components: [container],
                            flags: MessageFlags.IsComponentsV2
                        }).catch(() => {});
                    }
                }
            }
        } catch (err) {
            console.error("AFK System Error:", err);
        }
    }

    async SpyderPagination(description, title, client, message) {
        const lodash = require('lodash');
        const pages = lodash.chunk(description, 10).map((x) => x.join('\n'));
        let page = 0;

        if (pages.length <= 1) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## ${title}`),
                new TextDisplayBuilder().setContent(pages[0] || 'No data found.')
            );
            return await message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        const createRow = (currentPage) => {
            return new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('spyder_pagination_select')
                    .setPlaceholder(`Page ${currentPage + 1} of ${pages.length}`)
                    .addOptions(
                        pages.map((_, i) => ({
                            label: `Page ${i + 1}`,
                            value: `page_${i}`,
                            default: i === currentPage
                        }))
                    )
            );
        };

        const container = new ContainerBuilder();
        container.setAccentColor(client.color);
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`## ${title}`),
            new TextDisplayBuilder().setContent(pages[page])
        );

        const msg = await message.channel.send({
            components: [container, createRow(page)],
            flags: MessageFlags.IsComponentsV2
        });

        const collector = msg.createMessageComponentCollector({
            filter: (b) => b.user.id === message.author.id,
            time: 60000 * 5,
            idle: 30000,
            componentType: ComponentType.StringSelect
        });

        collector.on('collect', async (b) => {
            if (!b.deferred) await b.deferUpdate().catch(() => {});
            const selectedPage = parseInt(b.values[0].replace('page_', ''));
            page = selectedPage;

            const newContainer = new ContainerBuilder();
            newContainer.setAccentColor(client.color);
            newContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## ${title}`),
                new TextDisplayBuilder().setContent(pages[page])
            );

            await msg.edit({
                components: [newContainer, createRow(page)],
                flags: MessageFlags.IsComponentsV2
            }).catch(() => {});
        });

        collector.on('end', async () => {
            await msg.edit({ components: [] }).catch(() => {});
        });
    }

    async BlacklistCheck(guild) {
        try {
            let data = await this.client.db.get(`blacklistserver_${this.client.user.id}`) || [];
            if (data.includes(guild.id)) {
                return true;
            } else {
                return false;
            }
        } catch (error) {
            return false;
        }
    }

    async CheckPremium(guild) {
        try {
            let data = await this.client.db.get(`sprem_${guild.id}`) || null;
            if (data) {
                return true;
            } else {
                return false;
            }
        } catch (error) {
            return false;
        }
    }

    async sendBooster(guild, member) {
        const db = require(`${process.cwd()}/models/boost.js`)
        const data = await db.findOne({ Guild: guild.id })
        if (!data || !data.Boost) return
        try {
            let channel = guild.channels.cache.get(data.Boost)
            if (!channel) return
            let count = guild.premiumSubscriptionCount
            
            const container = new ContainerBuilder();
            container.setAccentColor(guild.roles.premiumSubscriberRole.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## 🎉🎉 NEW BOOSTER 🎉🎉`),
                new TextDisplayBuilder().setContent(
                    `**<@${member.id}> Just Boosted ${guild.name}. Thank You So Much For Boosting Our Server. We Now Have Total ${count} Boosts On Our Server!!**`
                ),
                new TextDisplayBuilder().setContent(`*Server Boosted 🎉*`)
            );
            
            await channel.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            })
        } catch (err) {
            return
        }
    }

    async pagination(message, description, desc = '') {
        const lodash = require('lodash')
        const pages = lodash.chunk(description, 10).map((x) => x.join(`\n`))
        let page = 0
        let msg

        if (pages.length <= 1) {
            return await message.channel.send({
                content: desc + this.client.util.codeText(pages[page])
            })
        } else {
            const row = new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('pagination_select')
                    .setPlaceholder(`Page ${page + 1} of ${pages.length}`)
                    .addOptions(
                        pages.map((_, i) => ({
                            label: `Page ${i + 1}`,
                            value: `page_${i}`
                        }))
                    )
            );

            msg = await message.channel.send({
                content: desc + this.client.util.codeText(pages[page]),
                components: [row]
            })
        }

        const collector = message.channel.createMessageComponentCollector({
            filter: (b) => {
                if (b.user.id === message.author.id) return true
                else {
                    const container = new ContainerBuilder();
                    container.setAccentColor(this.client.color);
                    container.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `Only **${message.author.tag}** can use this menu, run the command again to use the queue menu.`
                        )
                    );
                    b.reply({
                        components: [container],
                        flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
                    })
                    return false
                }
            },
            time: 60000 * 5,
            idle: 30e3,
            componentType: ComponentType.StringSelect
        })

        collector.on('collect', async (b) => {
            if (!b.deferred) await b.deferUpdate().catch(() => {})
            if (b.message.id !== msg.id) return
            
            const selectedPage = parseInt(b.values[0].replace('page_', ''))
            page = selectedPage

            const row = new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('pagination_select')
                    .setPlaceholder(`Page ${page + 1} of ${pages.length}`)
                    .addOptions(
                        pages.map((_, i) => ({
                            label: `Page ${i + 1}`,
                            value: `page_${i}`,
                            default: i === page
                        }))
                    )
            );

            return await msg.edit({
                content: desc + this.client.util.codeText(pages[page]),
                components: [row]
            }).catch(() => {})
        })

        collector.on('end', async () => {
            await msg.edit({ components: [] }).catch(() => {})
        })
    }

    codeText(text, type = 'js') {
        return `\`\`\`${type}\n${text}\`\`\``
    }

    async haste(text) {
        const req = await this.client.snek.post(
            'https://haste.ntmnathan.com/documents',
            { text }
        )
        return `https://haste.ntmnathan.com/${req.data.key}`
    }

    removeDuplicates(arr) {
        return [...new Set(arr)]
    }

    removeDuplicates2(arr) {
        return [...new Set(arr)]
    }

    async generateLatencyChart(ws_latency, database) {
        const QuickChart = require("quickchart-js"); 

        let data = await this.client.util._generateLatencyData(ws_latency, database);
        const qc = new QuickChart();
        qc.setConfig(this._generateChartConfig(ws_latency, database, data));
        qc.setWidth(400);
        qc.setHeight(200);
        qc.setBackgroundColor("transparent");
    
        let uri = await qc.getShortUrl();
        return uri;
    }
    
    async _generateLatencyData(ws_latency, database) {
        const QuickChart = require("quickchart-js");

        let data = [];
        for (let i = 0; i < 17; i++) {
            data.push(this.client.util._generateLatency(ws_latency, database));
        }
        data.push([ws_latency, database]);
        return data;
    }
    
    _generateLatency(wsl, msg) {
        const QuickChart = require("quickchart-js");

        let rnd = Math.random();
        wsl = parseInt(wsl + Math.floor(rnd * (-wsl * 0.05 - wsl * 0.05)) + wsl * 0.05);
        msg = parseInt(msg + Math.floor(rnd * (-msg * 0.02 - msg * 0.02)) + msg * 0.02);
        return [wsl, msg];
    }
    
    _generateChartConfig(ws_latency, database, data) {
        const QuickChart = require("quickchart-js");

        return {
            type: "line",
            data: {
                labels: Array(17).fill("_"),
                datasets: [
                    {
                        label: "Message Latency",
                        yAxisID: "mws",
                        data: data.map((item) => item[0]),
                        fill: true,
                        borderColor: "#ff5500",
                        borderWidth: 1,
                        backgroundColor: QuickChart.getGradientFillHelper("vertical", ["#fc4e14", "#ffffff"]),
                    },
                    {
                        label: "Database Latency",
                        yAxisID: "database",
                        data: data.map((item) => item[1]),
                        fill: true,
                        borderColor: "#00d8ff",
                        borderWidth: 1,
                        backgroundColor: QuickChart.getGradientFillHelper("vertical", ["#24ffd3", "#ffffff"]),
                    },
                ],
            },
            options: {
                scales: {
                    yAxes: [
                        {
                            id: "database",
                            type: "linear",
                            position: "right",
                            ticks: {
                                suggestedMin: 0,
                                suggestedMax: 200,
                                callback: (value) => `${value}`,
                            },
                        },
                        {
                            id: "mws",
                            type: "linear",
                            position: "left",
                            ticks: {
                                suggestedMin: 0,
                                suggestedMax: database,
                                callback: (value) => `${value}`,
                            },
                        },
                    ],
                },
            },
        };
    }
}
