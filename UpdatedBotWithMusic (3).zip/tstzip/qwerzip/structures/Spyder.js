const {
  Client,
  Collection,
  Partials,
  WebhookClient,
  Options,
  GatewayIntentBits,
} = require("discord.js");
const fs = require("fs");
const mongoose = require("mongoose");
const Utils = require("./util");
const { glob } = require("glob");
const { promisify } = require("util");
const { Database } = require("quickmongo");
const axios = require("axios");
const { QuickDB } = require("quick.db");
const { ClusterClient, getInfo } = require("discord-hybrid-sharding");
const Sql = require("better-sqlite3");
const redis = require("redis");
const { Destroyer } = require("destroyer-fast-cache");
const config = require(`${process.cwd()}/config.json`);
module.exports = class Spyder extends Client {
  constructor() {
    super({
      // OPTIMIZATION: Explicit intents instead of bitfield 53608191
      // Only request intents the bot actually needs - reduces memory and API overhead
      // Each intent adds data the bot receives, so fewer = better performance
      intents: [
        GatewayIntentBits.Guilds,                    // Required for guild events and cache
        GatewayIntentBits.GuildMembers,              // Required for member events (antinuke, moderation)
        GatewayIntentBits.GuildModeration,           // Required for ban/kick events (antinuke)
        GatewayIntentBits.GuildEmojisAndStickers,    // Required for emoji events
        GatewayIntentBits.GuildIntegrations,         // Required for integration events
        GatewayIntentBits.GuildWebhooks,             // Required for webhook events (antinuke)
        GatewayIntentBits.GuildInvites,              // Required for invite events
        GatewayIntentBits.GuildVoiceStates,          // Required for voice commands
        GatewayIntentBits.GuildPresences,            // Required for presence/status tracking
        GatewayIntentBits.GuildMessages,             // Required for message events
        GatewayIntentBits.GuildMessageReactions,     // Required for reaction events
        GatewayIntentBits.DirectMessages,            // Required for DM support
        GatewayIntentBits.MessageContent,            // Required to read message content (prefix commands)
        GatewayIntentBits.GuildScheduledEvents,      // Required for scheduled event tracking
        GatewayIntentBits.AutoModerationConfiguration, // Required for automod events
        GatewayIntentBits.AutoModerationExecution,   // Required for automod events
      ],
      // REMOVED: fetchAllMembers: true
      // This was deprecated and caused massive memory usage by fetching ALL members on startup
      // Members are now fetched on-demand which is much more efficient
      shards: getInfo().SHARD_LIST,
      shardCount: getInfo().TOTAL_SHARDS,
      allowedMentions: {
        parse: ["users"],
        repliedUser: true,
      },
      partials: [Partials.Message, Partials.Channel, Partials.Reaction],
      // OPTIMIZATION: Aggressive sweeper configuration
      // Sweepers periodically clean up cached data to reduce memory usage
      // Without sweepers, caches grow unbounded and cause memory leaks
      sweepers: {
        // Clean messages every 5 mins, remove those older than 10 mins (was 30 mins)
        messages: { interval: 300, lifetime: 600 },
        // Clean bot users (except self) every hour - bots rarely need to stay cached
        users: { interval: 3600, filter: () => user => user.bot && user.id !== this.user?.id },
        // Clean non-bot guild members every hour - reduces memory for large servers
        guildMembers: { interval: 3600, filter: () => member => !member.user?.bot },
        // Clean all thread members every hour - threads are temporary
        threadMembers: { interval: 3600, filter: () => () => true },
        // Clean threads older than 2 hours every hour
        threads: { interval: 3600, lifetime: 7200 },
      },
      // OPTIMIZATION: Cache size limits prevent unbounded memory growth
      // LimitedCollection automatically evicts old entries when limits are reached
      // This prevents OOM crashes in large bots serving many guilds
      makeCache: Options.cacheWithLimits({
        ...Options.DefaultMakeCacheSettings,
        // Limit message cache to 100 per channel - prevents memory bloat from busy channels
        MessageManager: 100,
        // Limit member cache to 200 per guild, always keep bot's own member
        GuildMemberManager: { maxSize: 200, keepOverLimit: member => member.id === this.user?.id },
        // Limit user cache to 200 total, always keep bot's own user
        UserManager: { maxSize: 200, keepOverLimit: user => user.id === this.user?.id },
        // Don't cache presences - very memory heavy and rarely needed after initial event
        PresenceManager: 0,
        // Don't cache reactions - can grow very large on popular messages
        ReactionManager: 0,
        // Limit guild message cache
        GuildMessageManager: 100,
      }),
    });
    // OPTIMIZATION: Changed from Infinity to 50
    // Infinity listeners can mask memory leaks and hurt debugging
    // 50 is sufficient for most use cases and warns if there's a potential leak
    this.setMaxListeners(50);
    this.cluster = new ClusterClient(this);
    this.config = require(`${process.cwd()}/config.json`);
    this.logger = require("./logger");
    this.ready = false;
    this.rateLimits = new Collection();
    this.commands = new Collection();
    this.categories = fs.readdirSync(`${process.cwd()}/qwerzip/commands/`);
    this.emoji = {
      tick: "<:tick:1436755134561521766>",
      cross: "<:cross:1436754701369737237>",
      dot: "<:dot:1436754655697699019>",
      process: "<a:red_loading:1221326019986980894>",
      disable: "<:cross:1436754701369737237><:tick:1436755134561521766>",
      enable: "<:cross:1436754701369737237><:tick:1436755134561521766>",
      protect: "<a:Spyder_antinuke:1180431827438153821>",
      hii: "<:Spyder:1438835471861026961>",
    };

    this.util = new Utils(this);
    this.prefixCache = new Map();
    this.color = 0x2b2d31;
    this.support = `https://discord.gg/snapz`;
    this.cooldowns = new Collection();
    this.snek = require("axios");
    this.ratelimit = { send: (msg) => console.log('[RATELIMIT]', msg) };
    this.error = { send: (msg) => console.error('[ERROR]', msg) };

    this.on("error", (error) => {
      if (error.code == 10008) return;
      if (error.code == 4000) return;
      if (error.code == 10001) return;
      if (error.code == 10003) return;
      if (error.code == 10004) return;
      if (error.code == 10005) return;
      if (error.code == 50001) return;
      if (error.code == 10062) return;
      if (error.code == 50013) return;
      if (error.code == 50035) return;
      console.error(error);
    });
    process.on("unhandledRejection", (error) => {
      console.error(error);
    });
    process.on("uncaughtException", (error) => {
      console.error(error);
    });
    process.on("warning", (warn) => {
      console.warn(warn);
    });
    process.on("uncaughtExceptionMonitor", (err, origin) => {
      console.error(err, origin);
    });
    // OPTIMIZATION: Removed duplicate process.on('uncaughtException') handler
    // Having multiple handlers for the same event wastes memory and can cause confusing behavior
    // The first handler (above) already sends errors to webhook - this duplicate was redundant
    process.on("triggerUncaughtException", (error) => {
      console.error(error);
    });

    // Aggressive GC hint for V8
    if (global.gc) {
      setInterval(global.gc, 300000);
    }

    this.rest.on("rateLimited", (info) => {
      this.ratelimit.send(`\`\`\`js
Timeout: ${info.retryAfter},
Limit: ${info.limit},
Method: ${info.method},
Path: ${info.hash},
Route: ${info.route},
Global: ${info.global}
URL : ${info.url}
Scope : ${info.scope}
MajorParameter : ${info.majorParameter}\`\`\``);
      const { route, retryAfter, limit, remaining, resetAfter, timeout } = info;
      this.rateLimits.set(route, {
        timeout,

        limit,

        remaining,

        resetAfter,

        lastReset: Date.now(),
      });

      // Implement adaptive backoff strategy

      const now = Date.now();

      const timeLeft =
        this.rateLimits.get(route).resetAfter -
        (now - this.rateLimits.get(route).lastReset);

      const backoffTime = Math.min(Math.max(timeLeft, 1000), 60000);
      (async () => {
        await new Promise((resolve) => setTimeout(resolve, backoffTime));
      })();
    });
  }

  async initializedata() {
    this.cache = new Destroyer();
    this.redis = new redis.createClient({
      url: config.Redis_Url,
    });

    // Add event listeners for better connection management
    this.redis.on("connect", () => {
      this.logger.log("Redis Client Connected", "ready");
    });

    this.redis.on("error", (err) => {
      this.logger.log(`Redis Client Error: ${err.message}`, "error");
    });

    this.redis.on("ready", () => {
      this.logger.log("Redis Cache Ready", "ready");
    });

    this.logger.log(`Connecting to Redis...`);
    await this.redis.connect().catch((err) => {
      this.logger.log(`Failed to connect to Redis: ${err.message}`, "error");
    });
    this.logger.log(`Connecting to Sql...`);
    this.logger.log("Sql Database Connected", "ready");
  }
  async SQL() {
    this.warn = new Sql(`${process.cwd()}/Database/warns.db`);
    this.warn.pragma("journal_mode = WAL");
    this.warn
      .prepare(
        `CREATE TABLE IF NOT EXISTS warnings (id INTEGER PRIMARY KEY AUTOINCREMENT,guildId TEXT NOT NULL,userId TEXT NOT NULL,reason TEXT,moderatorId TEXT,timestamp TEXT,warnId TEXT NOT NULL)`
      )
      .run();
    this.snipe = new Sql(`${process.cwd()}/Database/snipe.db`);
    this.snipe.pragma("journal_mode = WAL");
    this.snipe.pragma("synchronous = NORMAL");

    this.snipe.pragma("locking_mode = NORMAL");

    this.snipe.pragma("threads = 4");
    this.snipe
      .prepare(
        `CREATE TABLE IF NOT EXISTS snipes (id INTEGER PRIMARY KEY AUTOINCREMENT,guildId TEXT NOT NULL,channelId TEXT NOT NULL,content TEXT,author TEXT,timestamp INTEGER,imageUrl TEXT)`
      )
      .run();
    this.cmd = new Sql(`${process.cwd()}/Database/cmd.db`);
    this.cmd.pragma("journal_mode = WAL");
    this.cmd
      .prepare(
        `
            CREATE TABLE IF NOT EXISTS total_command_count (
                id INTEGER PRIMARY KEY CHECK (id = 1), 
                count INTEGER DEFAULT 0
            )
        `
      )
      .run();
    this.cmd
      .prepare(
        `
            INSERT OR IGNORE INTO total_command_count (id, count) VALUES (1, 0)
        `
      )
      .run();
  }

  async initializeMongoose() {
    this.db = new Database(this.config.MONGO_DB + "");
    this.db.connect();
    this.logger.log(`Connecting to MongoDb...`);
    // OPTIMIZATION: Enhanced MongoDB connection pooling options
    // These settings improve performance and reliability for high-traffic bots
    mongoose.connect(this.config.MONGO_DB, {
      // Maximum number of connections in the pool - allows parallel queries
      maxPoolSize: 500,
      // Minimum connections to maintain - reduces connection overhead for burst traffic
      minPoolSize: 10,
      // Time to wait for a connection from pool before erroring (ms)
      // Prevents hanging requests during high load
      serverSelectionTimeoutMS: 5000,
      // How long to wait for socket operations before timing out
      // Prevents queries from hanging indefinitely on network issues
      socketTimeoutMS: 45000,
      // How often to check connection health (ms)
      // Faster detection of dead connections
      heartbeatFrequencyMS: 10000,
      // Maximum time for connection attempts before failing
      connectTimeoutMS: 10000,
      // Automatically retry failed writes once - improves reliability
      retryWrites: true,
      // Write concern: acknowledge after writing to primary
      // Balance between performance and durability
      w: 'majority',
    });
    this.logger.log("Mongoose Database Connected", "ready");
  }

  async loadEvents() {
    fs.readdirSync(`${process.cwd()}/qwerzip/events/`).forEach((file) => {
      let eventName = file.split(".")[0];
      try {
        require(`${process.cwd()}/qwerzip/events/${file}`)(this);
        this.logger.log(`Updated Event ${eventName}.`, "event");
      } catch (err) {
        this.logger.log(`Failed to load event ${eventName}: ${err.message}`, "error");
      }
    });
  }

  async loadlogs() {
    fs.readdirSync(`${process.cwd()}/qwerzip/logs/`).forEach((file) => {
      let logevent = file.split(".")[0];
      try {
        require(`${process.cwd()}/qwerzip/logs/${file}`)(this);
        this.logger.log(`Updated Logs ${logevent}.`, "event");
      } catch (err) {
        this.logger.log(`Failed to load log ${logevent}: ${err.message}`, "error");
      }
    });
  }

  async loadMain() {
    const commandFiles = [];

    const commandDirectories = fs.readdirSync(`${process.cwd()}/qwerzip/commands`);

    for (const directory of commandDirectories) {
      const files = fs
        .readdirSync(`${process.cwd()}/qwerzip/commands/${directory}`)
        .filter((file) => file.endsWith(".js"));

      for (const file of files) {
        commandFiles.push(`${process.cwd()}/qwerzip/commands/${directory}/${file}`);
      }
    }
    commandFiles.map((value) => {
      const file = require(value);
      const splitted = value.split("/");
      const directory = splitted[splitted.length - 2];
      if (file.name) {
        const properties = { directory, ...file };
        this.commands.set(file.name, properties);
      }
    });
    this.logger.log(`Updated ${this.commands.size} Commands.`, "cmd");
  }
};
