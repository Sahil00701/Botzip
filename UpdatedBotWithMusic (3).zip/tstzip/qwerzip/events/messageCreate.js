const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    StringSelectMenuBuilder,
    ActionRowBuilder,
    MessageFlags,
    ComponentType,
    PermissionsBitField,
    Collection,
    WebhookClient
} = require('discord.js')
const config = require(`${process.cwd()}/config.json`)
const mediaConfigCache = new Map();
const mcooldown = new Set()

const premiumCache = new Map();
const PREMIUM_CACHE_TTL = 5 * 60 * 1000;

function getCachedPremium(key) {
    const cached = premiumCache.get(key);
    if (cached && Date.now() < cached.expires) {
        return cached.value;
    }
    premiumCache.delete(key);
    return undefined;
}

function setCachedPremium(key, value) {
    premiumCache.set(key, { value, expires: Date.now() + PREMIUM_CACHE_TTL });
}

function invalidatePremiumCache(userId, guildId) {
    premiumCache.delete(`uprem_${userId}`);
    premiumCache.delete(`upremend_${userId}`);
    premiumCache.delete(`sprem_${guildId}`);
    premiumCache.delete(`spremend_${guildId}`);
}

async function getPremiumStatus(client, userId, guildId) {
    const upremKey = `uprem_${userId}`;
    const upremendKey = `upremend_${userId}`;
    const spremKey = `sprem_${guildId}`;
    const spremendKey = `spremend_${guildId}`;
    
    let uprem = getCachedPremium(upremKey);
    let upremend = getCachedPremium(upremendKey);
    let sprem = getCachedPremium(spremKey);
    let spremend = getCachedPremium(spremendKey);
    
    const toFetch = [];
    if (uprem === undefined) toFetch.push(client.db.get(upremKey).then(v => { uprem = v; setCachedPremium(upremKey, v); }));
    if (upremend === undefined) toFetch.push(client.db.get(upremendKey).then(v => { upremend = v; setCachedPremium(upremendKey, v); }));
    if (sprem === undefined) toFetch.push(client.db.get(spremKey).then(v => { sprem = v; setCachedPremium(spremKey, v); }));
    if (spremend === undefined) toFetch.push(client.db.get(spremendKey).then(v => { spremend = v; setCachedPremium(spremendKey, v); }));
    
    if (toFetch.length > 0) await Promise.all(toFetch);
    
    return { uprem, upremend, sprem, spremend };
}

module.exports = async (client) => {
    client.on('messageCreate', async (message) => {
        if (message.author.bot || !message.guild) return
        
        // Use a faster check for mention-only messages
        if (message.content === `<@${client.user.id}>` || message.content === `<@!${client.user.id}>`) {
            if (mcooldown.has(message.author.id)) return;
            mcooldown.add(message.author.id);
            setTimeout(() => mcooldown.delete(message.author.id), 4000);
            
            // Lazy load prefix
            const prefix = message.guild.prefix || (await client.util.getPrefix(message.guild.id)) || '&';
            return message.channel.send(client.util.createMessageWithTitle(
                message.guild.name,
                `Hey ${message.author},\nMy Prefix here is: \`${prefix}\`\nServer Id: \`${message.guild.id}\`\n\nType \`${prefix}\`**help** To Get The Command List.\n\n*Developed with ❤️ By The Sahil </>*`,
                client.color
            )).catch(() => {});
        }

        try {
            // OPTIMIZATION: Check blacklist using cache first (sync)
            if (client.util.isBlacklistedSync && client.util.isBlacklistedSync(message.guild.id)) return;
            
            // OPTIMIZATION: Skip expensive calls if not a command
            const prefix = message.guild.prefix || (await client.util.getPrefix(message.guild.id)) || '&';
            if (!message.guild.prefix || message.guild.prefix === "undefined" || message.guild.prefix === "null") message.guild.prefix = prefix;
            
            const mentionRegexPrefix = RegExp(`^<@!?${client.user.id}>`);
            const prefixMatch = message.content.match(mentionRegexPrefix);
            const prefix1 = prefixMatch ? prefixMatch[0] : prefix;
            
            // Check noprefix cache if available
            const hasNoPrefix = client.noprefix?.includes(message.author.id);
            
            if (!hasNoPrefix && !message.content.startsWith(prefix1)) return;

            // ... existing logic ...
            const datab = client.noprefix || []
            const args = datab.includes(message.author.id) === false
                ? message.content.slice(prefix1.length).trim().split(/ +/)
                : message.content.startsWith(prefix1) === true
                    ? message.content.slice(prefix1.length).trim().split(/ +/)
                    : message.content.trim().split(/ +/)

            const cmd = args.shift().toLowerCase()
            const command = client.commands.get(cmd) || client.commands.find((c) => c.aliases?.includes(cmd))
            
            // Check for custom commands in a separate cache
            if (!command) {
                const customdata = await client.db.get(`customrole_${message.guild.id}`)
                if (customdata) {
                    const index = customdata.names.indexOf(cmd);
                    if (index !== -1) {
                        const ignore = (await client.db?.get(`ignore_${message.guild.id}`)) ?? { channel: [], role: [] };
                        if (ignore.channel.includes(message.channel.id) && !message.member.roles.cache.some((role) => ignore.role.includes(role.id))) {
                            const msg = await message.channel.send(client.util.createMessage(`This channel is currently in my ignore list...`, client.color));
                            setTimeout(() => msg.delete(), 3000);
                            return;
                        }
                        const role = await message.guild.roles.fetch(customdata.roles[index]);
                        if (!customdata.reqrole) {
                            return message.channel.send(client.util.createMessageWithTitle('Required Role Setup', `Please set up required role.`, client.color));
                        }
                        if (!message.member.roles.cache.has(customdata.reqrole)) {
                            return message.channel.send(client.util.createMessageWithFields('Access Denied', `Missing required role.`, [{ name: 'Required Role:', value: `<@&${customdata.reqrole}>` }], client.color));
                        }
                        if (!role) {
                            customdata.names.splice(index, 1);
                            customdata.roles.splice(index, 1);
                            await client.db?.set(`customrole_${message.guild.id}`, customdata);
                            return;
                        }
                        const member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
                        if (!member) return;
                        if (member.roles.cache.has(role.id)) {
                            await member.roles.remove(role.id);
                            await message.channel.send(client.util.createMessage(`${client.emoji.tick} | Role removed.`, client.color));
                        } else {
                            await member.roles.add(role.id);
                            await message.channel.send(client.util.createMessage(`${client.emoji.tick} | Role added.`, client.color));
                        }
                        return;
                    }
                }
            }

            if (!command) return

            if (command.premium) {
                if (!client.config.owner.includes(message.author.id)) {
                    const { uprem, upremend, sprem, spremend } = await getPremiumStatus(client, message.author.id, message.guild.id);
                    
                    if (!uprem && !sprem) {
                        return message.channel.send(client.util.createMessage(
                            `Hey ${message.member?.displayName || message.author.username},\nYou just found up a **Premium** Command, which can be used only in servers where there's an **Active Premium Subscription.**\n\n[Click here to buy Premium](https://discord.gg/snapz) so that you can use this command.`,
                            client.color
                        ))
                    }
                    
                    if (upremend && Date.now() >= upremend) {
                        invalidatePremiumCache(message.author.id, message.guild.id);
                        await handleUserPremiumExpiry(client, message);
                    }

                    if (spremend && Date.now() >= spremend) {
                        invalidatePremiumCache(message.author.id, message.guild.id);
                        await handleServerPremiumExpiry(client, message);
                    }
                }
            }

            const maintain = await client.db.get(`maintanance_${client.user.id}`)
            if (maintain && !client.config.admin.includes(message.author.id)) {
                return message.channel.send(client.util.createMessageWithTitle(
                    "Notice: Bot Functionality Globally Disabled by Developers",
                    `Dear Discord Community Members,\n\nWe regret to inform you that the functionality of the bot has been globally disabled by the developers. We understand the inconvenience this may cause and appreciate your understanding as we work to resolve the issue.\n\nThank you for your patience and continued support.\nSincerely,\n[Sahil </>](https://discord.gg/snapz)`,
                    client.color
                ))
            }

            const ignore = (await client.db?.get(`ignore_${message.guild.id}`)) ?? { channel: [], role: [] }
            if (!client.config.owner.includes(message.author.id) &&
                ignore.channel.includes(message.channel.id) &&
                !message.member.roles.cache.some((role) => ignore.role.includes(role.id))
            ) {
                return message.channel
                    .send(client.util.createMessage(
                        `This channel is currently in my ignore list, so commands can't be executed here. Please try another channel or reach out to the server Administrator for assistance.`,
                        client.color
                    ))
                    .then((x) => {
                        setTimeout(() => x.delete(), 3000)
                    })
            }
             
            const commandLimit = 5;

            if (client.config.cooldown && !client.config.owner.includes(message.author.id)) {
                if (!client.cooldowns.has(command.name)) {
                    client.cooldowns.set(command.name, new Collection());
                }
                const now = Date.now();
                const timestamps = client.cooldowns.get(command.name);
                const cooldownAmount = (command.cooldown || 5) * 1000;
                
                if (timestamps.has(message.author.id)) {
                    const expirationTime = timestamps.get(message.author.id) + cooldownAmount;
                    if (now < expirationTime) {
                        const timeLeft = (expirationTime - now) / 1000;
                        let commandCount = timestamps.get(`${message.author.id}_count`) || 0;
                        commandCount++;
                        timestamps.set(`${message.author.id}_count`, commandCount);
                        
                        if (commandCount > commandLimit) {
                            const blacklistedUsers = (await client.db.get(`blacklist_${client.user.id}`)) || [];
                            if (!blacklistedUsers.includes(message.author.id)) {
                                blacklistedUsers.push(message.author.id);
                                await client.db.set(`blacklist_${client.user.id}`, blacklistedUsers);
                                client.util.blacklist();
                            }
                            return message.channel.send(client.util.createMessageWithFields(
                                'Blacklisted for Spamming',
                                `You have been blacklisted for spamming commands. Please refrain from such behavior.`,
                                [{ name: 'Support Server', value: '[Join our support server](https://discord.gg/snapz)' }],
                                client.color
                            ));
                        }
                        
                        if (!timestamps.has(`${message.author.id}_cooldown_message_sent`)) {
                            message.channel.send(client.util.createMessage(
                                `Please wait, this command is on cooldown for \`${timeLeft.toFixed(1)}s\``,
                                client.color
                            )).then((msg) => {
                                setTimeout(() => msg.delete().catch(() => { }), 5000);
                            });
                            timestamps.set(`${message.author.id}_cooldown_message_sent`, true);
                        }
                        return;
                    }
                }
                timestamps.set(message.author.id, now);
                timestamps.set(`${message.author.id}_count`, 1);
                setTimeout(() => {
                    timestamps.delete(message.author.id);
                    timestamps.delete(`${message.author.id}_count`);
                    timestamps.delete(`${message.author.id}_cooldown_message_sent`);
                }, cooldownAmount);
            }
            
            await command.run(client, message, args).catch((err) => console.error('Command error:', err))
            client.cmd.prepare('UPDATE total_command_count SET count = count + 1 WHERE id = 1').run();

            if (config.COMMAND_LOGS_URL) {
                const web = new WebhookClient({ url: config.COMMAND_LOGS_URL });
                const logContent = `**${message.author.tag}**\n` +
                    `Command Ran In: \`${message.guild.name} | ${message.guild.id}\`\n` +
                    `Command Ran In Channel: \`${message.channel.name} | ${message.channel.id}\`\n` +
                    `Command Name: \`${command.name}\`\n` +
                    `Command Executor: \`${message.author.tag} | ${message.author.id}\`\n` +
                    `Command Content: \`${message.content}\``;
                web.send({ content: logContent }).catch(() => {});
            }
        } catch(err) {
            if (err.code === 429) {
                await client.util.handleRateLimit()
            }
            return
        }
    })
}

async function handleUserPremiumExpiry(client, message) {
    const [upremcount, upremserver, spremown] = await Promise.all([
        client.db.get(`upremcount_${message.author.id}`),
        client.db.get(`upremserver_${message.author.id}`),
        client.db.get(`spremown_${message.guild.id}`)
    ]);
    
    const servers = upremserver || [];
    let scot = 0;

    const deletions = [
        client.db.delete(`upremcount_${message.author.id}`),
        client.db.delete(`uprem_${message.author.id}`),
        client.db.delete(`upremend_${message.author.id}`),
        client.db.pull(`noprefix_${client.user.id}`, message.author.id)
    ];
    
    if (servers.length > 0) {
        for (const serverId of servers) {
            scot++;
            deletions.push(
                client.db.delete(`sprem_${serverId}`),
                client.db.delete(`spremend_${serverId}`),
                client.db.delete(`spremown_${serverId}`)
            );
        }
    }
    deletions.push(client.db.delete(`upremserver_${message.author.id}`));
    
    await Promise.all(deletions);
    
    message.author.send(client.util.createMessage(
        `Your Premium Has Got Expired.\nTotal **\`${scot}\`** Servers [Premium](https://discord.gg/snapz) was removed.\nClick [here](https://discord.gg/snapz) To Buy [Premium](https://discord.gg/snapz).`,
        client.color
    )).catch(() => {});
}

async function handleServerPremiumExpiry(client, message) {
    const us = await client.db.get(`spremown_${message.guild.id}`);
    
    const [upremserver, upremcount, spremown] = await Promise.all([
        client.db.get(`upremserver_${us}`),
        client.db.get(`upremcount_${us}`),
        client.db.get(`spremown_${message.guild.id}`).then((r) => client.db.get(`upremend_${r}`))
    ]);
    
    const servers = upremserver || [];
    let scount = 0;

    const deletions = [
        client.db.delete(`sprem_${message.guild.id}`),
        client.db.delete(`spremend_${message.guild.id}`)
    ];

    if (spremown && Date.now() > spremown) {
        deletions.push(
            client.db.delete(`upremcount_${us}`),
            client.db.delete(`uprem_${us}`),
            client.db.delete(`upremend_${us}`)
        );

        for (const serverId of servers) {
            scount++;
            deletions.push(
                client.db.delete(`sprem_${serverId}`),
                client.db.delete(`spremend_${serverId}`),
                client.db.delete(`spremown_${serverId}`)
            );
        }
        
        const user = client.users.cache.get(`${us}`);
        if (user) {
            user.send(client.util.createMessage(
                `Your Premium Has Got Expired.\nTotal **\`${scount}\`** Servers [Premium](https://discord.gg/snapz) was removed.\nClick [here](https://discord.gg/snapz) To Buy [Premium](https://discord.gg/snapz).`,
                client.color
            )).catch(() => {});
        }
    }
    
    deletions.push(
        client.db.delete(`upremserver_${us}`),
        client.db.delete(`spremown_${message.guild.id}`)
    );
    
    await Promise.all(deletions);
    
    message.channel.send(client.util.createMessage(
        `The Premium Of This Server Has Got Expired.\nClick [here](https://discord.gg/snapz) To Buy [Premium](https://discord.gg/snapz).`,
        client.color
    )).catch(() => {});
}

const roleWebhook = config.Role_LOGS_URL ? new WebhookClient({ url: config.Role_LOGS_URL }) : null;

function sendRoleLog(message, action, role, member = null, permissions = null) {
    if (!roleWebhook) return;
    
    let logContent = `**Custom Role Action Log**\n\n`;
    logContent += `**Server:** ${message.guild.name} (${message.guild.id})\n`;
    logContent += `**Moderator:** ${message.author.tag} (${message.author.id})\n`;
    logContent += `**Action:** ${action}\n`;
    logContent += `**Role:** ${role.name} (${role.id})`;
    
    if (member) {
        logContent += `\n**Target Member:** ${member.user.tag} (${member.id})`;
    }
    
    if (permissions) {
        logContent += `\n**Permissions Modified:** ${permissions}`;
    }

    roleWebhook.send({ content: logContent }).catch((error) => {
        console.error('Failed to send webhook log:', error);
    });
}
