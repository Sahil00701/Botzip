const { WebhookClient } = require('discord.js');
const config = require(`${process.cwd()}/config.json`);

module.exports = async (client) => {
    const join = config.Join_logs_URL ? new WebhookClient({ url: config.Join_logs_URL }) : null;
    const leave = config.leave_logs_URL ? new WebhookClient({ url: config.leave_logs_URL }) : null;

    client.on('guildCreate', async (guild) => {
        try {
            if(!client.ready) return
            const totalServers = await client.cluster
                .broadcastEval(client => client.guilds.cache.size)
                .then(results => results.reduce((prev, val) => prev + val, 0));

            const totalUsers = await client.cluster
                .broadcastEval(client => client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0))
                .then(results => results.reduce((acc, count) => acc + count, 0));

            let owner = await guild.fetchOwner();
            
            let emoji = '';
            if (guild.partnered && guild.verified) {
                emoji = `Partnered & Verified`;
            } else if (guild.partnered) {
                emoji = 'Partnered';
            } else if (guild.verified) {
                emoji = 'Verified';
            } else {
                emoji = `None`;
            }

            const logContent = `**${guild.name}**\n` +
                `Id: **${guild.id}**\nName: **${guild.name}**\nDiscord Level: ${emoji}\nMemberCount: \`${guild.memberCount}\`\nCreated At: <t:${Math.round(guild.createdTimestamp / 1000)}:R>\nJoined At: <t:${Math.round(guild.joinedTimestamp / 1000)}:R>\n\n` +
                `**Owner**\nInfo: **${owner.user.tag} (${owner.id})**\nMentions: <@${owner.id}>\nCreated At: <t:${Math.round(owner.user.createdTimestamp / 1000)}:R>\n\n` +
                `**${client.user.username}'s Total Servers:** \`${totalServers}\`\n` +
                `**${client.user.username}'s Total Users:** \`${totalUsers}\`\n` +
                `**Shard Id:** \`${guild.shardId}\``;

            if (join) await join.send({ content: logContent }).catch(() => {});
        } catch (error) {
            console.error('Error in guildCreate event:', error);
        }
    });

    client.on('guildDelete', async (guild) => {
        try {
            if(!client.ready) return
            const totalServers = await client.cluster
                .broadcastEval(client => client.guilds.cache.size)
                .then(results => results.reduce((prev, val) => prev + val, 0));

            const totalUsers = await client.cluster
                .broadcastEval(client => client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0))
                .then(results => results.reduce((acc, count) => acc + count, 0));

            const logContent = `**Server Left**\n` +
                `Id: **${guild.id}**\nName: **${guild.name}**\nMemberCount: \`${guild.memberCount}\`\nCreated At: <t:${Math.round(guild.createdTimestamp / 1000)}:R>\nJoined At: <t:${Math.round(guild.joinedTimestamp / 1000)}:R>\n\n` +
                `**${client.user.username}'s Total Servers:** \`${totalServers}\`\n` +
                `**${client.user.username}'s Total Users:** \`${totalUsers}\``;

            if (leave) await leave.send({ content: logContent }).catch(() => {});
        } catch (error) {
            console.error('Error in guildDelete event:', error);
        }
    });
};


