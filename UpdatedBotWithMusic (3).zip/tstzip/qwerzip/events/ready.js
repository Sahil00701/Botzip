const { ActivityType, Events } = require('discord.js');

module.exports = async (client) => {
    client.logger.log('Ready event listener attached', 'debug');
    client.on(Events.ClientReady, async () => {
        client.ready = true;
        // Pre-fetch blacklist cache on startup
        await client.util.refreshBlacklistCache();
        
        client.user.setPresence({
            activities: [{
                name: 'Spyder Bot | &help',
                type: ActivityType.Listening
            }],
            status: 'online'
        });
        client.logger.log(`Logged in to ${client.user.tag}`, 'ready');
        console.log(`[READY] Bot is online as ${client.user.tag}`);
    });
    
    // Fallback if client is already ready
    if (client.isReady()) {
        client.ready = true;
        client.logger.log(`Bot was already ready: ${client.user.tag}`, 'ready');
        console.log(`[READY] Bot was already online as ${client.user.tag}`);
    }
};
