const { ContainerBuilder, TextDisplayBuilder, MessageFlags } = require('discord.js');
const db = require('../models/afk.js');

module.exports = async (client) => {
    client.on('messageCreate', async (message) => {
        if (message.author.bot || message.author.system || !message.guild) return;
        try {
            await client.util.manageAfk(message, client);
        } catch (err) {
            console.error("AFK Event Error:", err);
        }
    });
};
