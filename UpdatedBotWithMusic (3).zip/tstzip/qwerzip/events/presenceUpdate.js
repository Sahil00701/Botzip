const { ActivityRole, VCRole, VanityStatus } = require('../models/premiumFeatures');

/**
 * Single presenceUpdate listener for ALL presence-based premium features
 * Handles: Activity Role System + Vanity Status Role System
 */
module.exports = async (client) => {
  client.on('presenceUpdate', async (oldPresence, newPresence) => {
    try {
      // Basic validation
      if (!newPresence || !newPresence.guild || !newPresence.member) return;
      if (newPresence.member.user.bot) return; // Ignore bots

      const guild = newPresence.guild;
      const member = newPresence.member;

      // PREMIUM GATE: Check if guild has premium
      const isPremium = await client.util.CheckPremium(guild);
      if (!isPremium) return; // Stop here if not premium

      // ========================================
      // FEATURE 1: ACTIVITY ROLE SYSTEM
      // ========================================
      await handleActivityRoles(client, guild, member, oldPresence, newPresence);

      // ========================================
      // FEATURE 2: VANITY STATUS ROLE SYSTEM
      // ========================================
      await handleVanityStatus(client, guild, member, oldPresence, newPresence);

    } catch (error) {
      // Silent error handling - no console spam
      return;
    }
  });
};

/**
 * Activity Role System Logic
 * Assigns roles based on Spotify, Gaming, or Streaming activities
 */
async function handleActivityRoles(client, guild, member, oldPresence, newPresence) {
  try {
    // Check if system is configured
    const config = await ActivityRole.findOne({ guildId: guild.id });
    if (!config || !config.enabled) return;

    const oldActivities = oldPresence?.activities || [];
    const newActivities = newPresence.activities || [];

    // Check Spotify Activity
    if (config.spotifyRole) {
      const wasListeningSpotify = oldActivities.some(a => a.name === 'Spotify' && a.type === 2);
      const isListeningSpotify = newActivities.some(a => a.name === 'Spotify' && a.type === 2);
      
      if (!wasListeningSpotify && isListeningSpotify) {
        // Started listening to Spotify - ADD role
        await member.roles.add(config.spotifyRole).catch(() => {});
      } else if (wasListeningSpotify && !isListeningSpotify) {
        // Stopped listening to Spotify - REMOVE role
        await member.roles.remove(config.spotifyRole).catch(() => {});
      }
    }

    // Check Gaming Activity (type 0 = Playing)
    if (config.gamingRole) {
      const wasPlaying = oldActivities.some(a => a.type === 0);
      const isPlaying = newActivities.some(a => a.type === 0);
      
      if (!wasPlaying && isPlaying) {
        // Started playing a game - ADD role
        await member.roles.add(config.gamingRole).catch(() => {});
      } else if (wasPlaying && !isPlaying) {
        // Stopped playing - REMOVE role
        await member.roles.remove(config.gamingRole).catch(() => {});
      }
    }

    // Check Streaming Activity (type 1 = Streaming)
    if (config.streamingRole) {
      const wasStreaming = oldActivities.some(a => a.type === 1);
      const isStreaming = newActivities.some(a => a.type === 1);
      
      if (!wasStreaming && isStreaming) {
        // Started streaming - ADD role
        await member.roles.add(config.streamingRole).catch(() => {});
      } else if (wasStreaming && !isStreaming) {
        // Stopped streaming - REMOVE role
        await member.roles.remove(config.streamingRole).catch(() => {});
      }
    }

  } catch (error) {
    // Silently handle permission errors or other issues
    return;
  }
}

/**
 * Vanity Status Role System Logic
 * Assigns official role when vanity code is in custom status
 */
async function handleVanityStatus(client, guild, member, oldPresence, newPresence) {
  try {
    // Check if system is configured
    const config = await VanityStatus.findOne({ guildId: guild.id });
    if (!config || !config.enabled) return;

    // Get custom status from activities
    const oldStatus = oldPresence?.activities?.find(a => a.type === 4)?.state || '';
    const newStatus = newPresence.activities?.find(a => a.type === 4)?.state || '';

    const hadVanity = oldStatus.toLowerCase().includes(config.vanityCode.toLowerCase());
    const hasVanity = newStatus.toLowerCase().includes(config.vanityCode.toLowerCase());

    // Vanity ADDED to status
    if (!hadVanity && hasVanity) {
      await member.roles.add(config.officialRole).catch(() => {});
      
      // Send log if configured
      if (config.logChannel) {
        const logChannel = guild.channels.cache.get(config.logChannel);
        if (logChannel) {
          const { ContainerBuilder, TextDisplayBuilder, MessageFlags } = require('discord.js');
          const container = new ContainerBuilder();
          container.setAccentColor(0x00ff00); // Green for added
          container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`## ✅ Vanity Added\n\n**Member:** ${member.user.tag} (${member.id})\n**Status:** ${newStatus}\n**Role Assigned:** <@&${config.officialRole}>`)
          );
          await logChannel.send({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
        }
      }
    }
    // Vanity REMOVED from status
    else if (hadVanity && !hasVanity) {
      await member.roles.remove(config.officialRole).catch(() => {});
      
      // Send log if configured
      if (config.logChannel) {
        const logChannel = guild.channels.cache.get(config.logChannel);
        if (logChannel) {
          const { ContainerBuilder, TextDisplayBuilder, MessageFlags } = require('discord.js');
          const container = new ContainerBuilder();
          container.setAccentColor(0xff0000); // Red for removed
          container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`## ❌ Vanity Removed\n\n**Member:** ${member.user.tag} (${member.id})\n**Previous Status:** ${oldStatus}\n**Role Removed:** <@&${config.officialRole}>`)
          );
          await logChannel.send({ components: [container], flags: MessageFlags.IsComponentsV2 }).catch(() => {});
        }
      }
    }

  } catch (error) {
    // Silently handle errors
    return;
  }
}
