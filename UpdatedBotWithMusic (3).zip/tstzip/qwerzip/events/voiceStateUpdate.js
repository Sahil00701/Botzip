const { VCRole } = require('../models/premiumFeatures');

/**
 * Single voiceStateUpdate listener for VC Role System
 * Assigns role when member joins VC, removes when they leave
 */
module.exports = async (client) => {
  client.on('voiceStateUpdate', async (oldState, newState) => {
    try {
      // Basic validation
      if (!newState || !newState.guild || !newState.member) return;
      if (newState.member.user.bot) return; // Ignore bots

      const guild = newState.guild;
      const member = newState.member;

      // PREMIUM GATE: Check if guild has premium
      const isPremium = await client.util.CheckPremium(guild);
      if (!isPremium) return; // Stop here if not premium

      // Check if VC role system is configured
      const config = await VCRole.findOne({ guildId: guild.id });
      if (!config || !config.enabled) return;

      const oldChannel = oldState.channel;
      const newChannel = newState.channel;

      // Member JOINED a voice channel (wasn't in one before)
      if (!oldChannel && newChannel) {
        // Add VC role
        await member.roles.add(config.vcRole).catch(() => {});
      }
      // Member LEFT a voice channel (not in one anymore)
      else if (oldChannel && !newChannel) {
        // Remove VC role
        await member.roles.remove(config.vcRole).catch(() => {});
      }
      // Member SWITCHED voice channels (both exist) - DO NOTHING
      // They're still in a VC, so they should keep the role

    } catch (error) {
      // Silent error handling - no logs
      return;
    }
  });
};
