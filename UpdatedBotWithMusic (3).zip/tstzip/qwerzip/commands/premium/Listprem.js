const {
    ContainerBuilder,
    TextDisplayBuilder,
    MessageFlags
} = require('discord.js');
this.config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'listpremium',
    aliases: ['listprem', 'premusers'],
    category: 'Owner',
    run: async (client, message, args) => {
        if (!this.config.premium.includes(message.author.id)) return;

        const keys = await client.db.all();

        const premiumUsers = keys.filter(key => key.ID.startsWith('uprem_') && key.data === 'true');

        if (premiumUsers.length === 0) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`No premium users found.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        const premiumUserList = await Promise.all(premiumUsers.map(async user => {
            const userId = user.ID.split('_')[1];
            const userEnd = await client.db.get(`upremend_${userId}`);
            const userCount = await client.db.get(`upremcount_${userId}`);

            return `<@${userId}> - Premium Count: \`${userCount}\` - Expiry: <t:${Math.round(userEnd / 1000)}>`;
        }));

        const container = new ContainerBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**Premium Users:**\n${premiumUserList.join('\n')}`)
            );
        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }
};
