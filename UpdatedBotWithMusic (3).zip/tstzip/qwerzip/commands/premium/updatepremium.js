const {
    ContainerBuilder,
    TextDisplayBuilder,
    MessageFlags
} = require('discord.js')
this.config = require(`${process.cwd()}/config.json`)

module.exports = {
    name: 'updatepremium',
    aliases: ['updateprem', 'upremium'],
    run: async (client, message, args) => {
        let time
        let count
        if (!this.config.premium.includes(message.author.id)) return
        if (args[0]) {
            try {
                await client.users.fetch(args[0])
            } catch (error) {
                return message.channel.send('Invalid Id')
            }
            if (args[1]) {
                time = Date.now() + 86400000 * args[1]
            } else if (!args[1]) {
                time = await client.db.get(`upremend_${args[0]}`)
            }
            if (args[2]) {
                count = args[2]
            }
            if (!args[2]) {
                count = (await client.db.get(`upremcount_${args[0]}`))
                    ? await client.db.get(`upremcount_${args[0]}`)
                    : 0
            }
            await client.db.set(`uprem_${args[0]}`, `true`)
            await client.db.set(`upremend_${args[0]}`, time)
            await client.db.set(`upremcount_${args[0]}`, count)
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `<@${args[0]}>'s Premium Has Been Updated\nPremium Count - \`${count}\`    Premium Expiring - <t:${Math.round(time / 1000)}>`
                    )
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        } else {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`Please Give The User Id`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
    }
}
