const {
    ContainerBuilder,
    TextDisplayBuilder,
    MessageFlags
} = require('discord.js')
this.config = require(`${process.cwd()}/config.json`)

module.exports = {
    name: 'removepremium',
    aliases: ['remprem', 'premium-'],
    category: 'Owner',
    run: async (client, message, args) => {
        if (!this.config.premium.includes(message.author.id)) return
        if (args[0]) {
            try {
                await client.users.fetch(args[0])
            } catch (error) {
                return message.channel.send('Invalid Id')
            }
            const use = await client.db.get(`uprem_${args[0]}`)
            if (!use) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`<@${args[0]}> Is Not A Premium User !`)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }
            await client.db.delete(`uprem_${args[0]}`)
            await client.db.delete(`upremend_${args[0]}`)
            await client.db.delete(`upremcount_${args[0]}`)
            await client.db.delete(`upremserver_${args[0]}`)
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`<@${args[0]}> Has Been Removed From A Premium User.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        } else {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`Please Give The User Id`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
    }
}
