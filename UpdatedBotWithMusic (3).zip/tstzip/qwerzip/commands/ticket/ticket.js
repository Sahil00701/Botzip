const { 
    ChannelType, 
    PermissionsBitField,
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    StringSelectMenuBuilder,
    ActionRowBuilder,
    MessageFlags,
    ComponentType
} = require('discord.js');
const ticketPanelSchema = require('../../models/ticket');
const lastRenameMap = new Map();

module.exports = {
    name: 'ticket',
    aliases: [],
    premium: false,
    subcommand : ['panel setup','panel enable','panel disable','panel reset','panel list','member add','member remove','channel open','channel close','channel delete','channel rename'],
    category: 'ticket',
    run: async (client, message, args) => {
        if (!args[0]) {
            let helpContent = `**Ticket System Commands**\n\nUse the commands below to manage your ticket system effectively.\n\n`;
            helpContent += `**${message.guild.prefix}ticket panel setup <panelname>** - \`Create a new ticket panel with the specified name.\`\n`;
            helpContent += `**${message.guild.prefix}ticket panel enable <panelname>** - \`Enable an existing ticket panel to accept ticket requests.\`\n`;
            helpContent += `**${message.guild.prefix}ticket panel disable <panelname>** - \`Disable a ticket panel to stop accepting ticket requests.\`\n`;
            helpContent += `**${message.guild.prefix}ticket panel reset <panelname/all>** - \`Reset a specific ticket panel or all ticket panels at once.\`\n`;
            helpContent += `**${message.guild.prefix}ticket panel list** - \`Show a list of all configured ticket panels.\`\n`;
            helpContent += `**${message.guild.prefix}ticket member add <@mention/userid>** - \`Add a member to the ticket channel so they can view and participate.\`\n`;
            helpContent += `**${message.guild.prefix}ticket member remove <@mention/userid>** - \`Remove a member from the ticket channel.\`\n`;
            helpContent += `**${message.guild.prefix}ticket channel open <#channel/id>** - \`Reopen a previously closed ticket channel.\`\n`;
            helpContent += `**${message.guild.prefix}ticket channel close <#channel/id>** - \`Close an open ticket channel.\`\n`;
            helpContent += `**${message.guild.prefix}ticket channel rename <#channel/id> <new-name>** - \`Rename a ticket channel to a new name.\`\n`;
            helpContent += `**${message.guild.prefix}ticket channel delete <#channel/id>** - \`Permanently delete a ticket channel.\``;

            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(helpContent)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`Ticket System | ${client.user.username}`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }        
        if(!message.guild.members.me.permissions.has('Administrator')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | I must have \`Administrator\` Permissions to run this command`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        if (args[0].toLowerCase() === 'panel') {
            if (['setup', 'list', 'enable', 'disable', 'reset'].includes(args[1].toLowerCase()) && !message.member.permissions.has(PermissionsBitField.Flags.Administrator)) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have \`Administrator\` permissions to run this command.`)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            if (['setup', 'list', 'enable', 'disable', 'reset'].includes(args[1].toLowerCase()) && !client.util.hasHigher(message.member)) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have a higher role than the bot to run this command.`)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            if (args[1].toLowerCase() === 'setup') {
                const panelName = args.slice(2).join(' ');
    
                if (!panelName) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | Please provide a valid panel name to get started!`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`Example: ${message.guild.prefix}ticket panel setup <panelname>`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }
    
                if (panelName.length > 100) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | The panel name cannot exceed 100 characters. Please provide a shorter name.`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`Panel name provided: ${panelName.length}/100 characters`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                const existingSetup = await ticketPanelSchema.findOne({ guildId: message.guild.id });
                if (existingSetup && existingSetup.panels.length >= 2) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | You cannot \`create\` more than 2 ticket panels.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                if (existingSetup && existingSetup.panels.some(panel => panel.panelName.toLowerCase() === panelName.toLowerCase())) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | A ticket panel with the name \`${panelName}\` already exists.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                const maxAttempts = 3;

                async function promptUser(promptMessage, validationFn) {
                    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
                        const promptContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(promptMessage)
                            );
                        await message.channel.send({ components: [promptContainer], flags: MessageFlags.IsComponentsV2 });

                        const filter = response => response.author.id === message.author.id;
                        try {
                            const userResponse = await message.channel.awaitMessages({ filter, max: 1, time: 30000, errors: ['time'] });
                            const result = validationFn(userResponse.first());
                            if (result) return result;

                            const errorContainer = new ContainerBuilder()
                                .addTextDisplayComponents(
                                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | Invalid input. Please try again. (${attempt}/${maxAttempts})`)
                                );
                            await message.channel.send({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 });
                        } catch (error) {
                            const timeoutContainer = new ContainerBuilder()
                                .addTextDisplayComponents(
                                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You didn't respond in time. (${attempt}/${maxAttempts})`)
                                );
                            await message.channel.send({ components: [timeoutContainer], flags: MessageFlags.IsComponentsV2 });
                        }

                        if (attempt === maxAttempts) return null;
                    }
                }

                const panelId = existingSetup ? `panel-${existingSetup.panels.length + 1}` : 'panel-1';

                const ticketSetup = {
                    panelId: panelId,
                    panelName: panelName,
                    guildId: message.guild.id,
                    channelId: null,
                    categoryId: null,
                    logsChannelId: null,
                    supportRoleId: null,
                    staffRoleId: null,
                    transcriptChannelId: null
                };

                const channel = await promptUser(
                    `Please provide the ticket creation channel.`,
                    (response) => {
                        const channel = response.mentions.channels.first() || message.guild.channels.cache.get(response.content);
                        return channel && channel.type === ChannelType.GuildText ? channel.id : null;
                    }
                );
                if (!channel) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | Failed to set up ticket panel.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }
                ticketSetup.channelId = channel;

                const category = await promptUser(
                    `Please provide the ticket creation category.`,
                    (response) => {
                        const category = response.mentions.channels.first() || message.guild.channels.cache.get(response.content);
                        return category && category.type === ChannelType.GuildCategory ? category.id : null;
                    }
                );
                if (!category) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | Failed to set up ticket panel.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }
                ticketSetup.categoryId = category;

                const logsDecision = await promptUser(
                    `Do you need a ticket logs channel? Respond with \`yes\` or \`no\`.`,
                    (response) => ['yes', 'no'].includes(response.content.toLowerCase()) ? response.content.toLowerCase() : null
                );
                if (!logsDecision) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | Failed to set up ticket panel.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                if (logsDecision === 'yes') {
                    const logsChannel = await promptUser(
                        `Please provide the ticket logs channel.`,
                        (response) => {
                            const channel = response.mentions.channels.first() || message.guild.channels.cache.get(response.content);
                            return channel && channel.type === ChannelType.GuildText ? channel.id : null;
                        }
                    );
                    if (!logsChannel) {
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Failed to set up ticket panel.`)
                            );
                        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    }
                    ticketSetup.logsChannelId = logsChannel;
                }

                const transcriptDecision = await promptUser(
                    `Do you need a transcript channel? Respond with \`yes\` or \`no\`.`,
                    (response) => ['yes', 'no'].includes(response.content.toLowerCase()) ? response.content.toLowerCase() : null
                );
                if (!transcriptDecision) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | Failed to set up ticket panel.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                if (transcriptDecision === 'yes') {
                    const transcriptChannel = await promptUser(
                        `Please provide the transcript channel.`,
                        (response) => {
                            const channel = response.mentions.channels.first() || message.guild.channels.cache.get(response.content);
                            return channel && channel.type === ChannelType.GuildText ? channel.id : null;
                        }
                    );
                    if (!transcriptChannel) {
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Failed to set up ticket panel.`)
                            );
                        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    }
                    ticketSetup.transcriptChannelId = transcriptChannel;
                }

                const supportRoleDecision = await promptUser(
                    `Do you want to set a support role? Respond with \`yes\` or \`no\`.`,
                    (response) => ['yes', 'no'].includes(response.content.toLowerCase()) ? response.content.toLowerCase() : null
                );
                if (!supportRoleDecision) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | Failed to set up ticket panel.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                if (supportRoleDecision === 'yes') {
                    const supportRole = await promptUser(
                        `Please provide the support role.`,
                        (response) => {
                            const role = response.mentions.roles.first() || message.guild.roles.cache.get(response.content);
                            return role ? role.id : null;
                        }
                    );
                    if (!supportRole) {
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Failed to set up ticket panel.`)
                            );
                        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    }
                    ticketSetup.supportRoleId = supportRole;
                }

                const staffRoleDecision = await promptUser(
                    `Do you want to set a staff role? Respond with \`yes\` or \`no\`.`,
                    (response) => ['yes', 'no'].includes(response.content.toLowerCase()) ? response.content.toLowerCase() : null
                );
                if (!staffRoleDecision) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | Failed to set up ticket panel.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                if (staffRoleDecision === 'yes') {
                    const staffRole = await promptUser(
                        `Please provide the staff role.`,
                        (response) => {
                            const role = response.mentions.roles.first() || message.guild.roles.cache.get(response.content);
                            return role ? role.id : null;
                        }
                    );
                    if (!staffRole) {
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Failed to set up ticket panel.`)
                            );
                        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    }
                    ticketSetup.staffRoleId = staffRole;
                }

                if (existingSetup) {
                    existingSetup.panels.push(ticketSetup);
                    await existingSetup.save();
                } else {
                    await new ticketPanelSchema({
                        guildId: message.guild.id,
                        panels: [ticketSetup]
                    }).save();
                }

                const selectMenu = new StringSelectMenuBuilder()
                    .setCustomId(`ticket_setup_${panelId}`)
                    .setPlaceholder('📨 Create Tickets')
                    .addOptions([
                        { label: 'Create Ticket', value: 'create_ticket', description: 'Click to create a new ticket', emoji: '📨' }
                    ]);

                const row = new ActionRowBuilder().addComponents(selectMenu);

                const ticketPanelContainer = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**${panelName} Ticket**\n\nSelect the option below to create a ticket.`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${message.guild.name}`)
                    );

                message.guild.channels.cache.get(channel).send({
                    components: [ticketPanelContainer, row],
                    flags: MessageFlags.IsComponentsV2
                });

                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${client.emoji.tick} | Ticket \`panel\` has been set up in <#${channel}>!`)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 }).then(m => {
                    setTimeout(() => {
                        if (m) m.delete().catch(() => null);
                    }, 3000);
                });
            } else if (args[1].toLowerCase() === 'enable') {
                const panelName = args.slice(2).join(' ').trim();
                if (!panelName) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | Please provide a panel name.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                const data = await ticketPanelSchema.findOne({ guildId: message.guild.id });
                if (!data) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | Ticket system is not set up.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                const panel = data.panels.find(p => p.panelName === panelName);
                if (!panel) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | Panel not found.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                if (panel.enabled) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | Panel is already enabled.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                panel.enabled = true;
                await data.save();

                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${client.emoji.tick} | Panel \`${panelName}\` has been enabled.`)
                    );
                message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            } else if (args[1].toLowerCase() === 'disable') {
                const panelName = args.slice(2).join(' ').trim();
                if (!panelName) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | Please provide a panel name.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                const data = await ticketPanelSchema.findOne({ guildId: message.guild.id });
                if (!data) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | Ticket system is not set up.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                const panel = data.panels.find(p => p.panelName === panelName);
                if (!panel) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | Panel not found.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                if (!panel.enabled) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | Panel is already disabled.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                panel.enabled = false;
                await data.save();

                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${client.emoji.tick} | Panel \`${panelName}\` has been disabled.`)
                    );
                message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            if (args[1].toLowerCase() === 'reset') {
                if (!args[2]) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | Please provide the panel name or use \`all\` to reset all panels.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                const panelName = args[2].trim();

                if (panelName.toLowerCase() === 'all') {
                    const data = await ticketPanelSchema.findOneAndDelete({ guildId: message.guild.id });

                    if (!data) {
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | There's **no** ticket setup to reset.`)
                            );
                        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    }

                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.tick} | Successfully **cleared** all ticket panels.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                const data = await ticketPanelSchema.findOne({ guildId: message.guild.id });

                if (!data || !data.panels || data.panels.length === 0) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | No panels are currently set up.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                const panelIndex = data.panels.findIndex(panel => panel.panelName.toLowerCase() === panelName.toLowerCase());

                if (panelIndex === -1) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | A panel with the name \`${panelName}\` doesn't exist.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                data.panels.splice(panelIndex, 1);

                if (data.panels.length === 0) {
                    await ticketPanelSchema.findOneAndDelete({ guildId: message.guild.id });
                } else {
                    await data.save();
                }

                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${client.emoji.tick} | Successfully \`reset\` the panel \`${panelName}\`.`)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            if (args[1].toLowerCase() === 'list') {
                const data = await ticketPanelSchema.findOne({ guildId: message.guild.id });
                if (!data || !data.panels || data.panels.length === 0) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | No ticket panels are set up in this guild.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                const panelList = data.panels.map((panel, index) => {
                    return `**${index + 1}. Panel Name:** \`${panel.panelName}\`\n**Panel ID:** ${panel.panelId}\n**Ticket Channel:** <#${panel.channelId}>\n**Category ID:** ${panel.categoryId}\n**Logs Channel:** ${panel.logsChannelId ? `<#${panel.logsChannelId}>` : 'None'}\n**Transcript Channel:** ${panel.transcriptChannelId ? `<#${panel.transcriptChannelId}>` : 'None'}\n**Panel Status:** ${panel.enabled ? `Enabled` : 'Disabled'}\n`;
                }).join("\n");

                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**Ticket Panels List**`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(panelList)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }
        } else if (args[0].toLowerCase() === 'member') {
            if (['remove','add'].includes(args[1].toLowerCase()) && !message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have \`Manage Channels\` permissions to run this command.`)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }            

            if (args[1].toLowerCase() === 'add') {
                const data = await ticketPanelSchema.findOne({ guildId: message.guild.id });
                if (!data) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | There's \`no\` ticket setup yet!`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                const ticketPanel = data.panels.find(panel => panel.channels.includes(message.channel.id));
                if (!ticketPanel) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | This channel \`isn't\` a valid ticket channel.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                const members = message.channel.members;
                if (members.size >= 10) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | You can only add up to \`10\` members in this ticket.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                if (args[2]) {
                    const member = await message.mentions.members.first() || await message.guild.members.cache.get(args[2]) || await message.guild.members.fetch(args[2]).catch(() => null);
                    if (!member) {
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Member \`not\` found.`)
                            );
                        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    }

                    if (ticketPanel.supportRoleId) {
                        const supportRole = await message.guild.roles.fetch(ticketPanel.supportRoleId).catch(() => null);
                        if (supportRole) {
                            member.roles.add(supportRole).catch(() => null);
                        }
                    }

                    if (ticketPanel.staffRoleId) {
                        const staffRole = await message.guild.roles.fetch(ticketPanel.staffRoleId).catch(() => null);
                        if (staffRole) {
                            member.roles.add(staffRole).catch(() => null);
                        }
                    }

                    try {
                        await message.channel.permissionOverwrites.edit(member.id, {
                            SendMessages: true,
                            AddReactions: true,
                            ViewChannel: true
                        });
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.tick} | Successfully added <@!${member.id}> to the \`ticket\` channel.`)
                            );
                        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    } catch (error) {
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Unable to \`add\` the member to the ticket.`)
                            );
                        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    }
                } else {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | Please specify a member to add using the correct format: \`${message.guild.prefix}ticket member add <member>\`.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }
            } else if (args[1].toLowerCase() === 'remove') {
                const data = await ticketPanelSchema.findOne({ guildId: message.guild.id });
                if (!data) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | There's \`no\` ticket setup yet!`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                const ticketPanel = data.panels.find(panel => panel.channels.includes(message.channel.id));
                if (!ticketPanel) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | This channel \`isn't\` a valid ticket channel.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                if (args[2]) {
                    const member = await message.mentions.members.first() || await message.guild.members.cache.get(args[2]) || await message.guild.members.fetch(args[2]).catch(() => null);
                    if (!member) {
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Member \`not\` found.`)
                            );
                        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    }

                    if (ticketPanel.supportRoleId) {
                        const supportRole = await message.guild.roles.fetch(ticketPanel.supportRoleId).catch(() => null);
                        if (supportRole && member.roles.cache.has(supportRole.id)) {
                            member.roles.remove(supportRole).catch(() => null);
                        }
                    }

                    if (ticketPanel.staffRoleId) {
                        const staffRole = await message.guild.roles.fetch(ticketPanel.staffRoleId).catch(() => null);
                        if (staffRole && member.roles.cache.has(staffRole.id)) {
                            member.roles.remove(staffRole).catch(() => null);
                        }
                    }

                    try {
                        message.channel.permissionOverwrites.edit(member.id, {
                            ViewChannel: false
                        });

                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.tick} | Successfully removed <@!${member.id}> from the \`ticket\` channel.`)
                            );
                        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    } catch (error) {
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Unable to \`remove\` the member from the ticket.`)
                            );
                        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    }
                } else {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | Please specify a member to remove using the correct format: \`${message.guild.prefix}ticket member remove <member>\`.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }
            }
        } else if (args[0].toLowerCase() === 'channel') {
            if (['rename', 'close', 'delete', 'open'].includes(args[1].toLowerCase()) && !message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have \`Manage Channels\` permissions to run this command.`)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            if (args[1].toLowerCase() === 'rename') {
                let channel;
                const data = await ticketPanelSchema.findOne({ guildId: message.guild.id });

                if (!data) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | There's \`no\` ticket setup yet!`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                try {
                    if (args[2]) {
                        channel = await getChannelFromMention(message, args[2]) || message.guild.channels.cache.get(args[2]);
                        if (!channel) {
                            const container = new ContainerBuilder()
                                .addTextDisplayComponents(
                                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | Please Provide a valid channel.`)
                                );
                            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                        }

                        const panel = data.panels.find(panel => panel.channels.includes(channel.id));
                        if (!panel) {
                            const container = new ContainerBuilder()
                                .addTextDisplayComponents(
                                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | This channel \`isn't\` a ticket channel!`)
                                );
                            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                        }

                        const now = Date.now();
                        const lastRename = lastRenameMap.get(channel.id) || 0;
                        const timeDiff = now - lastRename;
                        const tenMinutes = 10 * 60 * 1000;
                        if (timeDiff < tenMinutes) {
                            const container = new ContainerBuilder()
                                .addTextDisplayComponents(
                                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You can rename this ticket only once every 10 minutes!`)
                                );
                            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                        }

                        const newName = args.slice(3).join(' ');
                        if (!newName) {
                            const container = new ContainerBuilder()
                                .addTextDisplayComponents(
                                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | Please provide a valid channel name.`)
                                );
                            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                        }

                        await channel.setName(newName, 'Ticket channel renamed').catch(() => null);
                        lastRenameMap.set(channel.id, Date.now());

                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.tick} | The channel has been \`successfully\` renamed to **${newName}**.`)
                            );
                        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    } 
                } catch (e) {
                    console.log(e);
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | Unable to \`rename\` the channel!`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }
            } else if (args[1].toLowerCase() === 'close') {
                const data = await ticketPanelSchema.findOne({ guildId: message.guild.id });
                if (!data) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | There's \`no\` ticket setup yet!`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                try {
                    let channel = await getChannelFromMention(message, args[2]) || message.guild.channels.cache.get(args[2]);
                    if (!channel) {
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Please Provide a valid channel.`)
                            );
                        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    }

                    const panel = data.panels.find(panel => panel.channels.includes(channel.id));
                    if (!panel) {
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | This channel isn't part of any ticket panel!`)
                            );
                        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    }

                    const ticketIndex = data.createdBy.findIndex(ticket => ticket.panelId === panel.panelId && ticket.channelId === channel.id);
                    if (ticketIndex === -1) {
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Could not find the ticket in the database.`)
                            );
                        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    }

                    const ticketCreator = data.createdBy[ticketIndex]?.userId;
                    const member = message.guild.members.cache.get(ticketCreator) || await message.guild.members.fetch(ticketCreator).catch(console.error);

                    if (!message.member.permissions.has("ManageChannels") && message.author.id !== member?.id) {
                        return message.reply({ content: `${client.emoji.cross} | You don't have permission to close this ticket.` });
                    }

                    const isOpen = channel.permissionOverwrites.cache.get(member.id)?.deny.has(['ViewChannel', 'SendMessages']);
                    if (isOpen) {
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`Ticket <#${channel.id}> is already **closed**.`)
                            );
                        return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    }

                    await channel.permissionOverwrites.edit(member.id, { ViewChannel: false, SendMessages: false });
                    data.createdBy[ticketIndex].status = 'closed';
                    await data.save();

                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`Ticket <#${channel.id}> has been **closed** by ${message.author.tag}.`)
                        );
                    await message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });

                    const ticketlogs = panel.logsChannelId ? message.guild.channels.cache.get(panel.logsChannelId) : null;
                    if (ticketlogs) {
                        let logContent = `**Ticket Closed**\n\nA ticket has been closed.\n\n`;
                        logContent += `**Ticket Owner:** <@${ticketCreator}>\n`;
                        logContent += `**Closed By:** <@${message.author.id}>\n`;
                        logContent += `**Ticket Channel:** ${channel.name}\n`;
                        logContent += `**Ticket Action:** Closed\n`;
                        logContent += `**Panel Name:** ${panel.panelName}\n`;
                        logContent += `**Panel ID:** ${panel.panelId}\n`;
                        logContent += `**Ticket ID:** ${channel.id}`;

                        const logContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(logContent)
                            );
                        ticketlogs.send({ components: [logContainer], flags: MessageFlags.IsComponentsV2 }).catch(err => console.error("Failed to send ticket close log: ", err));
                    } else {
                        if(panel.logsChannelId){
                            panel.logsChannelId = null;
                        }
                        await data.save();
                    }
                } catch (error) {
                    console.error(error);
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | Unable to close the ticket!`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }
            } else if (args[1].toLowerCase() === 'delete') {
                const data = await ticketPanelSchema.findOne({ guildId: message.guild.id });
                if (!data) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | There's \`no\` ticket setup yet!`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                try {
                    let channel = await getChannelFromMention(message, args[2]) || message.guild.channels.cache.get(args[2]);
                    if (!channel) {
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Please Provide a valid channel.`)
                            );
                        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    }

                    const panel = data.panels.find(panel => panel.channels.includes(channel.id));
                    if (!panel) {
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | This channel isn't part of any ticket panel!`)
                            );
                        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    }

                    const ticketIndex = data.createdBy.findIndex(ticket => ticket.panelId === panel.panelId && ticket.channelId === channel.id);
                    if (ticketIndex === -1) {
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Could not find the ticket in the database.`)
                            );
                        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    }

                    const ticketCreator = data.createdBy[ticketIndex]?.userId;

                    const channelIndex = panel.channels.indexOf(channel.id);
                    if (channelIndex !== -1) {
                        panel.channels.splice(channelIndex, 1);
                    }

                    if (ticketIndex !== -1) {
                        data.createdBy.splice(ticketIndex, 1);
                    }

                    await data.save();

                    const ticketlogs = panel.logsChannelId ? message.guild.channels.cache.get(panel.logsChannelId) : null;
                    if (ticketlogs) {
                        let logContent = `**Ticket Deleted**\n\nA ticket has been deleted.\n\n`;
                        logContent += `**Ticket Owner:** <@${ticketCreator}>\n`;
                        logContent += `**Deleted By:** <@${message.author.id}>\n`;
                        logContent += `**Ticket Channel:** ${channel.name}\n`;
                        logContent += `**Ticket Action:** Deleted\n`;
                        logContent += `**Panel Name:** ${panel.panelName}\n`;
                        logContent += `**Panel ID:** ${panel.panelId}\n`;
                        logContent += `**Ticket ID:** ${channel.id}`;

                        const logContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(logContent)
                            );
                        ticketlogs.send({ components: [logContainer], flags: MessageFlags.IsComponentsV2 }).catch(err => console.error("Failed to send ticket delete log: ", err));
                    }

                    await channel.delete().catch(() => null);

                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.tick} | Ticket channel has been \`deleted\`.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                } catch (error) {
                    console.error(error);
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | Unable to delete the ticket!`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }
            } else if (args[1].toLowerCase() === 'open') {
                const data = await ticketPanelSchema.findOne({ guildId: message.guild.id });
                if (!data) {
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | There's \`no\` ticket setup yet!`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }

                try {
                    let channel = await getChannelFromMention(message, args[2]) || message.guild.channels.cache.get(args[2]);
                    if (!channel) {
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Please Provide a valid channel.`)
                            );
                        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    }

                    const panel = data.panels.find(panel => panel.channels.includes(channel.id));
                    if (!panel) {
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | This channel isn't part of any ticket panel!`)
                            );
                        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    }

                    const ticketIndex = data.createdBy.findIndex(ticket => ticket.panelId === panel.panelId && ticket.channelId === channel.id);
                    if (ticketIndex === -1) {
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Could not find the ticket in the database.`)
                            );
                        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    }

                    const ticketCreator = data.createdBy[ticketIndex]?.userId;
                    const member = message.guild.members.cache.get(ticketCreator) || await message.guild.members.fetch(ticketCreator).catch(() => null);

                    if (!member) {
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Ticket creator is no longer in the server.`)
                            );
                        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    }

                    await channel.permissionOverwrites.edit(member.id, { ViewChannel: true, SendMessages: true });
                    data.createdBy[ticketIndex].status = 'open';
                    await data.save();

                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.tick} | Ticket <#${channel.id}> has been **reopened**.`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                } catch (error) {
                    console.error(error);
                    const container = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | Unable to open the ticket!`)
                        );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }
            }
        }
    }
};

function getChannelFromMention(message, mention) {
    if (!mention) return null;
    const matches = mention.match(/^<#(\d+)>$/);
    if (!matches) return null;
    const channelId = matches[1];
    return message.guild.channels.cache.get(channelId);
}
