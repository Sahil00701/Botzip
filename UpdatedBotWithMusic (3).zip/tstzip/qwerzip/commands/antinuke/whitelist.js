const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    StringSelectMenuBuilder,
    ActionRowBuilder,
    MessageFlags,
    ComponentType
} = require('discord.js')
const { Spyder } = require('../../structures/Spyder')
module.exports = {
    name: 'whitelist',
    aliases: ['wl'],
    category: 'security',
    premium: false,
    /**
     * @param {Spyder} client
     */
    run: async (client, message, args) => {

        let own = message.author.id == message.guild.ownerId
        const check = await client.util.isExtraOwner(
            message.author,
            message.guild
        )
        if (!own && !check) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Only Server Owner Or Extraowner Can Run This Command.!`)
            );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        if (
            !own &&
            !(
                message?.guild.members.cache.get(client.user.id).roles.highest
                    .position <= message?.member?.roles?.highest.position
            )
        ) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Only Server Owner Or Extraowner Having Higher Role Than Me Can Run This Command`)
            );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        const antinuke = await client.db.get(`${message.guild.id}_antinuke`)
        if (!antinuke) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`** ${message.guild.name} security settings <a:Spyder_antinuke_cmd:1180431827438153821>\nOhh NO! looks like your server doesn't enabled security\n\nCurrent Status : <:cross:1436754701369737237><:tick:1436755134561521766>\n\nTo enable use antinuke enable **`)
            );
            message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        } else {
            const member =
                message.mentions.users.first() ||
                message.guild.members.cache.get(args[0])
            
            if (!member) {
                const container = new ContainerBuilder();
                container.setAccentColor(client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`__**Whitelist Commands**__`),
                    new TextDisplayBuilder().setContent(`**Adds user to whitelisted users which means that there will be no actions taken on the whitelisted members if they trigger the antinuke module.**`)
                );
                container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small));
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`__**Usage**__\n<:dot:1436754655697699019> \`${message.guild.prefix}whitelist @user/id\`\n<:dot:1436754655697699019> \`${message.guild.prefix}wl @user\``)
                );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }
            
            let data = await client.db?.get(
                `${message.guild.id}_${member.id}_wl`
            )
            if (data !== null) {
                if (
                    data.ban &&
                    data.kick &&
                    data.prune &&
                    data.botadd &&
                    data.serverup &&
                    data.memup &&
                    data.chcr &&
                    data.chup &&
                    data.chdl &&
                    data.rlcr &&
                    data.rldl &&
                    data.rlup &&
                    data.meneve &&
                    data.mngweb &&
                    data.mngstemo
                ) {
                    const container = new ContainerBuilder();
                    container.setAccentColor(client.color);
                    container.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${client.emoji.cross} | <@${member.id}> is already a whitelisted member.`)
                    );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }
            }

            await client.db?.set(`${message.guild.id}_${member.id}_wl`, {
                ban: false,
                kick: false,
                prune: false,
                botadd: false,
                serverup: false,
                memup: false,
                chcr: false,
                chup: false,
                chdl: false,
                rlcr: false,
                rldl: false,
                rlup: false,
                meneve: false,
                mngweb: false,
                mngstemo: false
            })
            
            let menu = [
                {
                    label: 'All Categories',
                    value: 'all',
                    description: 'Whitelist member for all permissions'
                },
                {
                    label: 'Ban',
                    value: 'ban',
                    description: 'Whitelistes a member with ban permission'
                },
                {
                    label: 'Kick',
                    value: 'kick',
                    description: 'Whitelistes a member with kick permission'
                },
                {
                    label: 'Prune',
                    value: 'prune',
                    description: 'Whitelistes a member with prune permission'
                },
                {
                    label: 'Bot Add',
                    value: 'botadd',
                    description: 'Whitelistes a member with bot add permission'
                },
                {
                    label: 'Server Update',
                    value: 'serverup',
                    description:
                        'Whitelistes a member with server update permission'
                },
                {
                    label: 'Member Update',
                    value: 'memup',
                    description:
                        'Whitelistes a member with member update permission'
                },
                {
                    label: 'Channel Create',
                    value: 'chcr',
                    description:
                        'Whitelistes a member with channel create permission'
                },
                {
                    label: 'Channel Delete',
                    value: 'chdl',
                    description:
                        'Whitelistes a member with channel delete permission'
                },
                {
                    label: 'Channel Update',
                    value: 'chup',
                    description:
                        'Whitelistes a member with channel update permission'
                },
                {
                    label: 'Role Create',
                    value: 'rlcr',
                    description:
                        'Whitelistes a member with role create permission'
                },
                {
                    label: 'Role Update',
                    value: 'rlup',
                    description:
                        'Whitelistes a member with role update permission'
                },
                {
                    label: 'Role Delete',
                    value: 'rldl',
                    description:
                        'Whitelistes a member with role delete permission'
                },
                {
                    label: 'Mention Everyone',
                    value: 'meneve',
                    description:
                        'Whitelistes a member with mention everyone permission'
                },
                {
                    label: 'Manage Webhook',
                    value: 'mngweb',
                    description:
                        'Whitelistes a member with manage webhook permission'
                },
                {
                    label: 'Manage Stickers & Emojis',
                    value: 'mngstemo',
                    description:
                        'Whitelistes a member with Manage stickers & emojis permission'
                }
            ]

            const buildStatusDescription = (d) => {
                return `${d.ban ? '<:tick:1436755134561521766>' : '<:cross:1436754701369737237>'}: **Ban**\n${d.kick ? '<:tick:1436755134561521766>' : '<:cross:1436754701369737237>'}: **Kick**\n${d.prune ? '<:tick:1436755134561521766>' : '<:cross:1436754701369737237>'}: **Prune**\n${d.botadd ? '<:tick:1436755134561521766>' : '<:cross:1436754701369737237>'}: **Bot Add**\n${d.serverup ? '<:tick:1436755134561521766>' : '<:cross:1436754701369737237>'}: **Server Update**\n${d.memup ? '<:tick:1436755134561521766>' : '<:cross:1436754701369737237>'}: **Member Role Update**\n${d.chcr ? '<:tick:1436755134561521766>' : '<:cross:1436754701369737237>'}: **Channel Create**\n${d.chdl ? '<:tick:1436755134561521766>' : '<:cross:1436754701369737237>'}: **Channel Delete**\n${d.chup ? '<:tick:1436755134561521766>' : '<:cross:1436754701369737237>'}: **Channel Update**\n${d.rlcr ? '<:tick:1436755134561521766>' : '<:cross:1436754701369737237>'}: **Role Create**\n${d.rldl ? '<:tick:1436755134561521766>' : '<:cross:1436754701369737237>'}: **Role Delete**\n${d.rlup ? '<:tick:1436755134561521766>' : '<:cross:1436754701369737237>'}: **Role Update**\n${d.meneve ? '<:tick:1436755134561521766>' : '<:cross:1436754701369737237>'}: **Mention @everyone**\n${d.mngweb ? '<:tick:1436755134561521766>' : '<:cross:1436754701369737237>'}: **Webhook Management**\n${d.mngstemo ? '<:tick:1436755134561521766>' : '<:cross:1436754701369737237>'}: **Emojis & Stickers Management**\n\n**Executor:** <@!${message.author.id}>\n**Target:** <@!${member.id}>`;
            };

            let menuSelect = new StringSelectMenuBuilder()
                .setCustomId('wl')
                .setMinValues(1)
                .setMaxValues(menu.length)
                .setOptions(menu)
                .setPlaceholder('Choose Your Options')
            
            const row = new ActionRowBuilder().addComponents([menuSelect])
            
            const currentData = data || {
                ban: false,
                kick: false,
                prune: false,
                botadd: false,
                serverup: false,
                memup: false,
                chcr: false,
                chup: false,
                chdl: false,
                rlcr: false,
                rldl: false,
                rlup: false,
                meneve: false,
                mngweb: false,
                mngstemo: false
            };

            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**${message.guild.name}**`),
                new TextDisplayBuilder().setContent(buildStatusDescription(currentData))
            );
            container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small));
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`Developed with ❤️ by ${client.user.username} Development`)
            );

            let msg = await message.channel.send({
                components: [container, row],
                flags: MessageFlags.IsComponentsV2
            });
            
            const collector = msg.createMessageComponentCollector({
                filter: (i) => i.isStringSelectMenu() && i.user,
                time: 60000,
                componentType: ComponentType.StringSelect
            })
            
            collector.on('collect', async (i) => {
                if (i.user.id !== message.author.id)
                    return i.reply({
                        content: `Only <@${message.author.id}> Can Use This Interaction`,
                        flags: 64
                    })
                
                i.deferUpdate()
                data = await client.db?.get(`${i.guild.id}_${member.id}_wl`)
                
                if (i.values.includes('all')) {
                    data.ban = true
                    data.kick = true
                    data.prune = true
                    data.botadd = true
                    data.serverup = true
                    data.memup = true
                    data.chcr = true
                    data.chdl = true
                    data.chup = true
                    data.rlcr = true
                    data.rldl = true
                    data.rlup = true
                    data.meneve = true
                    data.mngweb = true
                    data.mngstemo = true
                    
                    menuSelect = menuSelect.setDisabled(true)
                    const newRow = new ActionRowBuilder().addComponents([menuSelect])
                    
                    const updatedContainer = new ContainerBuilder();
                    updatedContainer.setAccentColor(client.color);
                    updatedContainer.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**${message.guild.name}**`),
                        new TextDisplayBuilder().setContent(buildStatusDescription(data))
                    );
                    updatedContainer.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small));
                    updatedContainer.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`Developed with ❤️ by ${client.user.username} Development`)
                    );
                    
                    msg.edit({
                        components: [updatedContainer, newRow],
                        flags: MessageFlags.IsComponentsV2
                    })
                    
                    let already1 = await client.db.get(
                        `${message.guild.id}_wl.whitelisted`,
                        member.id
                    )

                    if (already1) {
                        await client.db.pull(
                            `${message.guild.id}_wl.whitelisted`,
                            member.id
                        )
                        await client.db.push(
                            `${message.guild.id}_wl.whitelisted`,
                            member.id
                        )
                    } else {
                        await client.db.push(
                            `${message.guild.id}_wl.whitelisted`,
                            member.id
                        )
                    }

                    return client.db?.set(
                        `${i.guild.id}_${member.id}_wl`,
                        data
                    )
                }
                
                const permissionMap = {
                    'ban': 'ban',
                    'kick': 'kick',
                    'prune': 'prune',
                    'botadd': 'botadd',
                    'serverup': 'serverup',
                    'memup': 'memup',
                    'chcr': 'chcr',
                    'chdl': 'chdl',
                    'chup': 'chup',
                    'rlcr': 'rlcr',
                    'rldl': 'rldl',
                    'rlup': 'rlup',
                    'meneve': 'meneve',
                    'mngweb': 'mngweb',
                    'mngstemo': 'mngstemo'
                };

                for (const [key, prop] of Object.entries(permissionMap)) {
                    if (i.values.includes(key)) {
                        data[prop] = !data[prop];
                    }
                }

                const updatedContainer = new ContainerBuilder();
                updatedContainer.setAccentColor(client.color);
                updatedContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**${message.guild.name}**`),
                    new TextDisplayBuilder().setContent(buildStatusDescription(data))
                );
                updatedContainer.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small));
                updatedContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`Developed with ❤️ by ${client.user.username} Development`)
                );

                msg.edit({
                    components: [updatedContainer, row],
                    flags: MessageFlags.IsComponentsV2
                })

                let already = await client.db.get(
                    `${message.guild.id}_wl.whitelisted`,
                    member.id
                )

                if (already) {
                    await client.db.pull(
                        `${message.guild.id}_wl.whitelisted`,
                        member.id
                    )
                    await client.db.push(
                        `${message.guild.id}_wl.whitelisted`,
                        member.id
                    )
                } else {
                    await client.db.push(
                        `${message.guild.id}_wl.whitelisted`,
                        member.id
                    )
                }

                return client.db?.set(
                    `${i.guild.id}_${member.id}_wl`,
                    data
                )
            })
        }
    }
}
