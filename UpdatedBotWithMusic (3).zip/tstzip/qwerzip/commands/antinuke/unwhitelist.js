const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    MessageFlags 
} = require('discord.js');

module.exports = {
    name: 'unwhitelist',
    aliases: ['uwl'],
    category: 'security',
    premium: false,
    run: async (client, message, args) => {
        const { dot, enable, disable, protect, hii, tick } = client.emoji;

        let own = message.author.id === message.guild.ownerId;
        const check = await client.util.isExtraOwner(message.author, message.guild);
        if (!own && !check) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Only Server Owner or Extra Owner can run this command.`)
            );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        if (!own && !(message.guild.members.cache.get(client.user.id).roles.highest.position <= message.member.roles.highest.position)) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Only Server Owner or Extra Owner with a higher role than me can run this command.`)
            );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        const user = message.mentions.users.first() ||
            message.guild.members.cache.get(args[0])
        if (!user) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`__**Unwhitelist Commands**__`),
                new TextDisplayBuilder().setContent(`**Removes user from whitelisted users, which means that there will be proper actions taken on the member if they trigger the antinuke module.**`)
            );
            container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small));
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`__**Usage**__\n${dot} \`${message.guild.prefix}unwhitelist @user/id\`\n${dot} \`${message.guild.prefix}uwl @user\``)
            );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        const antinuke = await client.db.get(`${message.guild.id}_antinuke`);
        if (!antinuke) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**${message.guild.name} security settings ${protect} Ohh NO! Looks like your server hasn't enabled security.\n\nCurrent Status: ${disable}\n\nTo enable use \`antinuke enable\`**`)
            );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        const data = await client.db.get(`${message.guild.id}_${user.id}_wl`);
        if (!data) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${client.emoji.cross} | <@${user.id}> is not a whitelisted member.`)
            );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        await client.db.pull(`${message.guild.id}_wl.whitelisted`, user.id);
        await client.db.delete(`${message.guild.id}_${user.id}_wl`);
        const container = new ContainerBuilder();
        container.setAccentColor(client.color);
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`${client.emoji.tick} | Successfully removed <@${user.id}> from the whitelist.`)
        );
        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }
};
