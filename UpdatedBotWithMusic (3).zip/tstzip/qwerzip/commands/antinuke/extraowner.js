const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    MessageFlags 
} = require('discord.js');

const saixd = [
    '902363493242650635',
    '1408831955369332786',
    '1143155471159664710',
    '1187775437624053770',
    '775333233335205918',
    '855690571535876157',
    '1207801591890190367'
];

module.exports = {
    name: 'extraowner',
    aliases: [],
    category: 'security',
    subcommand: ['add', 'remove', 'list', 'reset'],
    premium: false,
    run: async (client, message, args) => {
        if (
            message.author.id !== message.guild.ownerId &&
            !saixd.includes(message.author.id)
        ) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Only Server Owner Can Run This Command!`)
            );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        const prefix = message.guild.prefix || '&';
        const option = args[0]?.toLowerCase();
        const userMention = args[1];
        const user =
            getUserFromMention(message, userMention) ||
            message.guild.members.cache.get(userMention);

        const buildMainContainer = () => {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`__**Extra Owner**__`),
                new TextDisplayBuilder().setContent(`ExtraOwner Can Edit Server Antinuke Status Whitelisted Members So Be Careful Before Adding Someone in it`)
            );
            container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small));
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`__**Extraowner Add**__\nTo Add Extra Owner, Use - \`${prefix}extraowner add @user\``),
                new TextDisplayBuilder().setContent(`__**Extraowner Remove**__\nTo Remove Extra Owner, Use - \`${prefix}extraowner remove @user\``),
                new TextDisplayBuilder().setContent(`__**Extraowner Reset**__\nTo Reset Extra Owner, Use - \`${prefix}extraowner reset\``),
                new TextDisplayBuilder().setContent(`__**Extraowner List**__\nTo View Extra Owner, Use - \`${prefix}extraowner list\``)
            );
            return container;
        };

        if (!option) {
            return message.channel.send({ components: [buildMainContainer()], flags: MessageFlags.IsComponentsV2 });
        }

        let data = await client.db.get(`extraowner_${message.guild.id}`);
        if (!data || !Array.isArray(data.owner)) {
            data = { owner: [] };
        }

        if (['add', 'set'].includes(option)) {
            if (!user) {
                const container = new ContainerBuilder();
                container.setAccentColor(client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | Please Provide a Valid User Mention or ID to Set as Extra Owner!`)
                );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }
            if (user.bot) {
                const container = new ContainerBuilder();
                container.setAccentColor(client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You Cannot Add Bots to Extra Owner!`)
                );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            const premium = await client.db.get(`sprem_${message.guild.id}`);
            const limit = premium ? 2 : 1;

            if (data.owner.length >= limit) {
                const container = new ContainerBuilder();
                container.setAccentColor(client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You Cannot Add Extra Owner More Than ${limit}`)
                );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            if (!data.owner.includes(user.id)) {
                data.owner.push(user.id);
                await client.db.set(`extraowner_${message.guild.id}`, data);
                const container = new ContainerBuilder();
                container.setAccentColor(client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.tick} | Successfully Added ${user} As Extra Owner`)
                );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            } else {
                const container = new ContainerBuilder();
                container.setAccentColor(client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | ${user} Already Exists in Extra Owner List`)
                );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }
        } else if (['remove', 'del'].includes(option)) {
            if (!user) {
                const container = new ContainerBuilder();
                container.setAccentColor(client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | Please Provide a Valid User Mention or ID to Remove from Extra Owner!`)
                );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            if (data.owner.includes(user.id)) {
                data.owner = data.owner.filter((id) => id !== user.id);
                await client.db.set(`extraowner_${message.guild.id}`, data);
                const container = new ContainerBuilder();
                container.setAccentColor(client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.tick} | Successfully Removed ${user} From Extra Owner List`)
                );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            } else {
                const container = new ContainerBuilder();
                container.setAccentColor(client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | ${user} Does Not Exist in Extra Owner List`)
                );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }
        } else if (option === 'reset') {
            if (!data.owner.length) {
                const container = new ContainerBuilder();
                container.setAccentColor(client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | There Is No Extra Owner Configuration in This Server!`)
                );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            } else {
                await client.db.set(`extraowner_${message.guild.id}`, { owner: [] });
                const container = new ContainerBuilder();
                container.setAccentColor(client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.tick} | Successfully Disabled Extra Owner Configuration!`)
                );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }
        } else if (option === 'list') {
            if (!data.owner.length) {
                const container = new ContainerBuilder();
                container.setAccentColor(client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | No Extra Owner is Set!`)
                );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            } else {
                const mentions = data.owner
                    .map((userId) => `${client.emoji.dot} <@${userId}> (${userId})`)
                    .join('\n');
                const container = new ContainerBuilder();
                container.setAccentColor(client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(mentions)
                );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }
        } else {
            return message.channel.send({ components: [buildMainContainer()], flags: MessageFlags.IsComponentsV2 });
        }
    },
};

function getUserFromMention(message, mention) {
    if (!mention) return null;

    const matches = mention.match(/^<@!?(\d+)>$/);
    if (!matches) return null;

    const id = matches[1];
    return message.client.users.cache.get(id);
}
