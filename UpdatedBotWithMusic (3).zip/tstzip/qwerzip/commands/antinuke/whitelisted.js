const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    MessageFlags 
} = require('discord.js');

module.exports = {
    name: 'wlisted',
    aliases: ['wlist', 'whitelisted'],
    category: 'security',
    premium: false,
    run: async (client, message, args) => {

        let own = message.author.id == message.guild.ownerId
        const check = await client.util.isExtraOwner(
            message.author,
            message.guild
        )
        if (!own && !check) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Only Server Owner Or Extraowner Can Run This Command.!`)
            );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        if (
            !own &&
            !(
                message?.guild.members.cache.get(client.user.id).roles.highest
                    .position <= message?.member?.roles?.highest.position
            )
        ) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Only Server Owner Or Extraowner Having Higher Role Than Me Can Run This Command`)
            );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        const antinuke = await client.db.get(`${message.guild.id}_antinuke`)
        if (!antinuke) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Seems that antinuke module is not enabled in this server.`)
            );
            message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        } else {
            await client.db.get(`${message.guild.id}_wl`).then(async (data) => {
                if (!data) {
                    await client.db.set(`${message.guild.id}_wl`, {
                        whitelisted: []
                    })
                    let users = data.whitelisted
                    let i
                    for (i = 0; i < users.length; i++) {
                        let data2 = await client.db?.get(
                            `${message.guild.id}_${users[i]}_wl`
                        )
                        if (data2) {
                            client.db?.delete(
                                `${message.guild.id}_${users[i]}_wl`
                            )
                        }
                    }
                    const container = new ContainerBuilder();
                    container.setAccentColor(client.color);
                    container.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${client.emoji.cross} | Please again run this command as the database was earlier not assigned.`)
                    );
                    message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                } else {
                    const users = data.whitelisted
                    const mentions = []
                    if (users.length !== 0) {
                        users.forEach((userId) =>
                            mentions.push(
                                `${client.emoji.dot} <@${userId}> (${userId})`
                            )
                        )
                        const container = new ContainerBuilder();
                        container.setAccentColor(client.color);
                        container.addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`__**Whitelisted Users**__`),
                            new TextDisplayBuilder().setContent(mentions.join('\n'))
                        );
                        message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    } else {
                        const container = new ContainerBuilder();
                        container.setAccentColor(client.color);
                        container.addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | There are no whitelisted members in this server.`)
                        );
                        message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                    }
                }
            })
        }
    }
}
