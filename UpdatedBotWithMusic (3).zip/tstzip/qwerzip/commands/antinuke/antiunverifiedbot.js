const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    MessageFlags 
} = require('discord.js');

module.exports = {
    name: 'antiunverified',
    aliases: [],
    category: 'security',
    subcommand : ['enable','disable'],
    premium: false,
    run: async (client, message, args) => {

        const { enable , disable, protect , hii, tick } = client.emoji
        let own = message.author.id == message.guild.ownerId
        const check = await client.util.isExtraOwner(
            message.author,
            message.guild
        )
        if (!own && !check) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Only Server Owner Or Extraowner Can Run This Command.!`)
            );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        if (
            !own &&
            !(
                message?.guild.members.cache.get(client.user.id).roles.highest
                    .position <= message?.member?.roles?.highest.position
            )
        ) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Only Server Owner Or Extraowner Having Higher Role Than Me Can Run This Command`)
            );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        const prefix = '&' || message.guild.prefix;
        const option = args[0];
        const isActivatedAlready = await client.db.get(`antiunverified_${message.guild.id}`) || null

        const buildMainContainer = () => {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`__**Anti-Unverified Bot Addition**__`),
                new TextDisplayBuilder().setContent(`Enhance your server security with Anti-Unverified Bot Addition! It swiftly removes unverified bots added to your server, protecting your members and data. Enable now for superior protection!`)
            );
            container.addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small));
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`__**Enable Anti-Unverified Bot Addition**__\nTo Enable, Use - \`${prefix}antiunverified enable\``),
                new TextDisplayBuilder().setContent(`__**Disable Anti-Unverified Bot Addition**__\nTo Disable, Use - \`${prefix}antiunverified disable\``)
            );
            return container;
        };

        if (!option) {
            return message.channel.send({ components: [buildMainContainer()], flags: MessageFlags.IsComponentsV2 });
        } else if (option === 'enable') {
            if (isActivatedAlready) {
                const container = new ContainerBuilder();
                container.setAccentColor(client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Security Settings For ${message.guild.name} ${protect}\nIt seems your server has already enabled this security feature.\n\nCurrent Status: ${enable}\nTo Disable, use ${prefix}antiunverified disable**`)
                );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            await client.db.set(`antiunverified_${message.guild.id}`, true);
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**Security Settings For ${message.guild.name} ${protect}\nSuccessfully enabled this security feature for your server.\n\nCurrent Status: ${enable}\n\nTo Disable, use ${prefix}antiunverified disable**`)
            );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });

        } else if (option === 'disable') {
            if (!isActivatedAlready) {
                const container = new ContainerBuilder();
                container.setAccentColor(client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Security Settings For ${message.guild.name} ${protect}\nIt seems your server hasn't enabled this security feature.\n\nCurrent Status: ${disable}\n\nTo Enable, use ${prefix}antiunverified enable**`)
                );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            await client.db.delete(`antiunverified_${message.guild.id}`)
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**Security Settings For ${message.guild.name} ${protect}\nSuccessfully disabled this security feature for your server.\n\nCurrent Status: ${disable}\n\nTo Enable, use ${prefix}antiunverified enable**`)
            );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        } else {
            message.channel.send({ components: [buildMainContainer()], flags: MessageFlags.IsComponentsV2 });
        }
    }
};
