const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize,
    PermissionFlagsBits,
    MessageFlags 
} = require('discord.js');
const wait = require('wait');

module.exports = {
    name: 'antinuke',
    aliases: ['antiwizz', 'an'],
    category: 'security',
    subcommand: ['enable', 'disable'],
    premium: false,
    run: async (client, message, args) => {
        const { enable, disable, protect, hii, tick } = client.emoji;

        const createMessage = (description) => {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(description)
            );
            return { components: [container], flags: MessageFlags.IsComponentsV2 };
        };

        let own = message.author.id == message.guild.ownerId;
        const check = await client.util.isExtraOwner(
            message.author,
            message.guild
        );
        if (!own && !check) {
            return message.channel.send(
                createMessage(`${client.emoji.cross} | Only Server Owner Or Extraowner Can Run This Command.!`)
            );
        }

        if (
            !own &&
            !(
                message.guild.members.cache.get(client.user.id).roles.highest
                    .position <= message.member.roles.highest.position
            )
        ) {
            return message.channel.send(
                createMessage(`${client.emoji.cross} | Only Server Owner Or Extraowner Having Higher Role Than Me Can Run This Command`)
            );
        }

        let prefix = '&' || message.guild.prefix;
        const option = args[0];
        const isActivatedAlready = await client.db.get(
            `${message.guild.id}_antinuke`
        );

        const antinukeContainer = new ContainerBuilder();
        antinukeContainer.setAccentColor(client.color);
        antinukeContainer.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`## __**Antinuke**__`),
            new TextDisplayBuilder().setContent(
                `Level up your server security with Antinuke! It swiftly bans admins engaging in suspicious activities, all while safeguarding your whitelisted members. Enhance protection – enable Antinuke now!`
            )
        );
        antinukeContainer.addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        );
        antinukeContainer.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `**__Antinuke Enable__**\nTo Enable Antinuke, Use - \`${prefix}antinuke enable\`\n\n` +
                `**__Antinuke Disable__**\nTo Disable Antinuke, Use - \`${prefix}antinuke disable\``
            )
        );

        if (!option) {
            message.channel.send({ 
                components: [antinukeContainer],
                flags: MessageFlags.IsComponentsV2
            });
        } else if (option === 'enable') {
            if (isActivatedAlready) {
                const enabledContainer = new ContainerBuilder();
                enabledContainer.setAccentColor(client.color);
                enabledContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `**Security Settings For ${message.guild.name} ${protect}\nUmm, looks like your server has already enabled security\n\nCurrent Status : ${enable}\nTo Disable use ${prefix}antinuke disable**`
                    )
                );
                message.channel.send({ 
                    components: [enabledContainer],
                    flags: MessageFlags.IsComponentsV2
                });
            } else {
                await client.db.set(`${message.guild.id}_antinuke`, true);
                await client.db.set(`${message.guild.id}_wl`, {
                    whitelisted: []
                });

                const enabledContainer = new ContainerBuilder();
                enabledContainer.setAccentColor(client.color);
                enabledContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`## ${client.user.username} Security`),
                    new TextDisplayBuilder().setContent(
                        `**Security Settings For ${message.guild.name} ${protect}**\n\nTip: To optimize the functionality of my Anti-Nuke Module, please move my role to the top of the roles list.${hii}\n\n***__Modules Enabled__*** ${protect}\n**Anti Ban: ${enable}\nAnti Unban: ${enable}\nAnti Kick: ${enable}\nAnti Bot: ${enable}\nAnti Channel Create: ${enable}\nAnti Channel Delete: ${enable}\nAnti Channel Update: ${enable}\nAnti Emoji/Sticker Create: ${enable}\nAnti Emoji/Sticker Delete: ${enable}\nAnti Emoji/Sticker Update: ${enable}\nAnti Everyone/Here Ping: ${enable}\nAnti Link Role: ${enable}\nAnti Role Create: ${enable}\nAnti Role Delete: ${enable}\nAnti Role Update: ${enable}\nAnti Role Ping: ${enable}\nAnti Member Update: ${enable}\nAnti Integration: ${enable}\nAnti Server Update: ${enable}\nAnti Automod Rule Create: ${enable}\nAnti Automod Rule Update: ${enable}\nAnti Automod Rule Delete: ${enable}\nAnti Guild Event Create: ${enable}\nAnti Guild Event Update: ${enable}\nAnti Guild Event Delete: ${enable}\nAnti Webhook: ${enable}**\n\n**__Anti Prune__: ${enable}\n__Auto Recovery__: ${enable}**`
                    ),
                    new TextDisplayBuilder().setContent(`*Punishment Type: Ban*`)
                );

                let msg = await message.channel.send(
                    createMessage(`${client.emoji.tick} | Initializing Quick Setup!`)
                );

                const steps = [
                    'Verifying the necessary permissions...',
                    "Checking Spyder's role position for optimal configuration...",
                    'Crafting and configuring the Spyder Impenetrable Power role...',
                    'Ensuring precise placement of the Spyder Impenetrable Power role...',
                    'Safeguarding your changes...',
                    'Activating the Antinuke Modules for enhanced security...!!'
                ];

                let currentDesc = `${tick} | Initializing Quick Setup!`;
                for (const step of steps) {
                    await client.util.sleep(1000);
                    currentDesc += `\n${tick} | ${step}`;
                    const stepContainer = new ContainerBuilder();
                    stepContainer.setAccentColor(client.color);
                    stepContainer.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(currentDesc)
                    );
                    await msg.edit({
                        components: [stepContainer],
                        flags: MessageFlags.IsComponentsV2
                    });
                }

                await client.util.sleep(2000);
                await msg.edit({ 
                    components: [enabledContainer],
                    flags: MessageFlags.IsComponentsV2
                });

                if (message.guild.roles.cache.size > 249)
                    return message.reply(
                        `I Won't Able To Create \`Spyder Impenetrable Power\` Cause There Are Already 249 Roles In This Server`
                    );
                let role = message.guild.members.cache.get(client.user.id)
                    .roles.highest.position;
                let createdRole = await message.guild.roles.create({
                    name: 'Spyder Impenetrable Power',
                    position: role ? role : 0,
                    reason: 'Spyder Role For Ubypassable Setup',
                    permissions: [PermissionFlagsBits.Administrator],
                    colors: '#07ff00'
                });
                await message.guild.members.me.roles.add(createdRole.id);
            }
        } else if (option === 'disable') {
            if (!isActivatedAlready) {
                const disabledContainer = new ContainerBuilder();
                disabledContainer.setAccentColor(client.color);
                disabledContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `**Security Settings For ${message.guild.name} ${protect}\nUmm, looks like your server hasn't enabled security.\n\nCurrent Status: ${disable}\n\nTo Enable use ${prefix}antinuke enable**`
                    )
                );
                message.channel.send({ 
                    components: [disabledContainer],
                    flags: MessageFlags.IsComponentsV2
                });
            } else {
                await client.db
                    .get(`${message.guild.id}_wl`)
                    .then(async (data) => {
                        const users = data.whitelisted;
                        let i;
                        for (i = 0; i < users.length; i++) {
                            let data2 = await client.db?.get(
                                `${message.guild.id}_${users[i]}_wl`
                            );
                            if (data2) {
                                await client.db?.delete(
                                    `${message.guild.id}_${users[i]}_wl`
                                );
                            }
                        }
                    });
                await client.db.set(`${message.guild.id}_antinuke`, null);
                await client.db.set(`panic_${message.guild.id}`, null);
                await client.db.set(`${message.guild.id}_wl`, {
                    whitelisted: []
                });

                const disabledContainer = new ContainerBuilder();
                disabledContainer.setAccentColor(client.color);
                disabledContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `**Security Settings For ${message.guild.name} ${protect}\nSuccessfully disabled security settings for this server.\n\nCurrent Status: ${disable}\n\nTo Enable use ${prefix}antinuke enable**`
                    )
                );
                message.channel.send({ 
                    components: [disabledContainer],
                    flags: MessageFlags.IsComponentsV2
                });
            }
        } else {
            message.channel.send({ 
                components: [antinukeContainer],
                flags: MessageFlags.IsComponentsV2
            });
        }
    }
};
