const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags
} = require('discord.js')

module.exports = {
    name: 'setup',
    aliases: ['customrolesetup', 'crs'],
    category: 'customrole',
    premium: false,
    run: async (client, message, args) => {
        if (!message.member.permissions.has('Administrator')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have \`Administrator\` permissions to use this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        if (!message.guild.members.me.permissions.has('ManageRoles')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | I need \`Manage Roles\` permission to execute this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        let isown = message.author.id == message.guild.ownerId
        if (!isown && !client.util.hasHigher(message.member)) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have a higher role than me to use this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        let input = args[0]?.toLowerCase()

        if (!input) {
            let helpContent = `**Custom Role Setup**\n\n`;
            helpContent += `\`${message.guild.prefix}setup add <name> <role>\` - Setups a role with the provided name.\n\n`;
            helpContent += `\`${message.guild.prefix}setup remove <name>\` - Removes a role with the provided name.\n\n`;
            helpContent += `\`${message.guild.prefix}setup reqrole <role>\` - Setups a requirement role.\n\n`;
            helpContent += `\`${message.guild.prefix}setup add girl <role>\` - Setups a role for girls\n\n`;
            helpContent += `\`${message.guild.prefix}setup add guest <role>\` - Setups a role for guests.\n\n`;
            helpContent += `\`${message.guild.prefix}setup add vip <role>\` - Setups a role for vip members.\n\n`;
            helpContent += `\`${message.guild.prefix}setup add official <role>\` - Setups a role for official members.\n\n`;
            helpContent += `\`${message.guild.prefix}setup list\` - Shows you the list of all custom roles.\n\n`;
            helpContent += `\`${message.guild.prefix}setup config\` - Shows you the configuration of custom roles.`;

            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${message.guild.name}`)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(helpContent)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.user.username}`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        if (input == 'add') {
            let name = args[1]?.toLowerCase()
            if (!name) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${client.emoji.cross} | Please provide a valid name for the custom role.`)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[2]) || message.guild.roles.cache.find((r) => r.name.toLowerCase() === args.slice(2).join(' ').toLowerCase())

            if (!role) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**Role Not Found**\n\nOops! The specified role could not be found. Please double-check the role mention or name and try again.`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`Requested by ${message.author.tag}`)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            if (role.managed) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**Role Not Valid**\n\n<@&${role.id}> appears to be a role managed by an internal service and cannot be assigned as a server role. Please choose a different role.`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`Requested by ${message.author.tag}`)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            if (role.position >= message.member.roles.highest.position && message.author.id !== message.guild.ownerId) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**${client.emoji.cross} Role Position Issue**\n\n<@&${role.id}> cannot be assigned because its position is either equal to or higher than your highest role. Please adjust your roles or choose a role with a lower position.`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`Requested by ${message.author.tag}`)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            if (role.position >= message.guild.members.me.roles.highest.position) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**Role Position Issue**\n\n<@&${role.id}> cannot be assigned because its position is either equal to or higher than my highest role. Please adjust the role positions or choose a role with a lower position.`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`Requested by ${message.author.tag}`)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            let data = await client.db?.get(`customrole_${message.guild.id}`) || {
                roles: [],
                names: [],
                reqrole: null
            }

            if (data.names.includes(name)) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${client.emoji.cross} | A custom role with the name \`${name}\` already exists.`)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            data.roles.push(role.id)
            data.names.push(name)
            await client.db?.set(`customrole_${message.guild.id}`, data)

            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Custom Role Added**\n\nThe role <@&${role.id}> has been successfully set up with the name \`${name}\`.`)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`Setup by ${message.author.tag}`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        } else if (input == 'remove') {
            let name = args[1]?.toLowerCase()
            if (!name) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${client.emoji.cross} | Please provide a valid name for the custom role to remove.`)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            let data = await client.db?.get(`customrole_${message.guild.id}`)

            if (!data || !data.names.includes(name)) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${client.emoji.cross} | A custom role with the name \`${name}\` does not exist.`)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            const index = data.names.indexOf(name)
            data.roles.splice(index, 1)
            data.names.splice(index, 1)
            await client.db?.set(`customrole_${message.guild.id}`, data)

            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Custom Role Removed**\n\nThe custom role with the name \`${name}\` has been successfully removed.`)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`Removed by ${message.author.tag}`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        } else if (input == 'list') {
            let data = await client.db?.get(`customrole_${message.guild.id}`)
            if (!data || data.roles.length === 0) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${client.emoji.cross} | There are no custom roles set up for this server.`)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            let list = data.names.map((n, i) => `**${i + 1}.** \`${n}\` - <@&${data.roles[i]}>`).join('\n')

            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Custom Roles List for ${message.guild.name}**`)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(list)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`Total: ${data.roles.length} roles`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        } else if (input == 'reqrole') {
            let role = message.mentions.roles.first() || message.guild.roles.cache.get(args[1]) || message.guild.roles.cache.find((r) => r.name.toLowerCase() === args.slice(1).join(' ').toLowerCase())

            if (!role) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**Role Not Found**\n\nOops! The specified role could not be found. Please double-check the role mention or name and try again.`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`Requested by ${message.author.tag}`)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            if (role.managed) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**Role Not Valid**\n\n<@&${role.id}> appears to be a role managed by an internal service and cannot be assigned as a server role. Please choose a different role.`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`Requested by ${message.author.tag}`)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            if (role.position >= message.member.roles.highest.position && message.author.id !== message.guild.ownerId) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**${client.emoji.cross} Role Position Issue**\n\n<@&${role.id}> cannot be assigned because its position is either equal to or higher than your highest role. Please adjust your roles or choose a role with a lower position.`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`Requested by ${message.author.tag}`)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            if (role.position >= message.guild.members.me.roles.highest.position) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**Role Position Issue**\n\n<@&${role.id}> cannot be assigned because its position is either equal to or higher than my highest role. Please adjust the role positions or choose a role with a lower position.`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`Requested by ${message.author.tag}`)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            let data = await client.db?.get(`customrole_${message.guild.id}`) || {
                roles: [],
                names: [],
                reqrole: null
            }

            await client.db?.set(`customrole_${message.guild.id}`, {
                roles: data.roles,
                names: data.names,
                reqrole: role.id
            })

            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Custom Requirement Role Set**\n\nThe role <@&${role.id}> has been successfully set up as a custom requirement role. Members will now need this role to assign features.`)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`Setup by ${message.author.tag}`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        } else if (input == 'config') {
            const data = await client.db?.get(`customrole_${message.guild.id}`)
            if (!data) {
                let configContent = `**__Reqrole__**\n\n*Role Not set*.\n\n**__Girl__**\n\n*Role Not set*.\n\n**__Guest__**\n*Role Not set*.\n\n**__Vip__**\n\n*Role Not set*.\n\n**__Official__**\n\n*Role Not set*.`;

                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${message.guild.name}`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(configContent)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${client.user.username}`)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            if (data.roles.length < 1 && data.names.length < 1 && !data.reqrole) {
                let configContent = `**__Reqrole__**\n*Role Not set*.\n\n**__Girl__**\n*Role Not set*.\n\n**__Guest__**\n*Role Not set*.\n\n**__Vip__**\n*Role Not set*.\n\n**__Official__**\n*Role Not set*.`;

                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${message.guild.name}`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(configContent)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${client.user.username}`)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            let reqrole, girl, guest, vip, official
            const check = await message.guild.roles.fetch(data.reqrole).catch(() => null)
            const check1 = await message.guild.roles.fetch(
                data.roles[
                    data.names.indexOf(
                        data.names.filter((n) => n.toLowerCase() === 'girl')[0]
                    )
                ]
            ).catch(() => null)
            const check2 = await message.guild.roles.fetch(
                data.roles[
                    data.names.indexOf(
                        data.names.filter((n) => n.toLowerCase() === 'guest')[0]
                    )
                ]
            ).catch(() => null)
            const check3 = await message.guild.roles.fetch(
                data.roles[
                    data.names.indexOf(
                        data.names.filter((n) => n.toLowerCase() === 'vip')[0]
                    )
                ]
            ).catch(() => null)
            const check4 = await message.guild.roles.fetch(
                data.roles[
                    data.names.indexOf(
                        data.names.filter(
                            (n) => n.toLowerCase() === 'official'
                        )[0]
                    )
                ]
            ).catch(() => null)

            if (check) reqrole = check
            else reqrole = '*Role Not set*'
            if (check1) girl = check1
            else girl = '*Role Not set*'
            if (check2) guest = check2
            else guest = '*Role Not set*'
            if (check3) vip = check3
            else vip = '*Role Not set*'
            if (check4) official = check4
            else official = '*Role Not set*'

            let description = `**__Reqrole__**\n${reqrole?.id ? `<@&${reqrole.id}>` : '*Role Not set*'}.\n\n**__Girl__**\n${girl?.id ? `<@&${girl.id}>` : '*Role Not set*'}.\n\n**__Guest__**\n${guest?.id ? `<@&${guest.id}>` : '*Role Not set*'}.\n\n**__Vip__**\n${vip?.id ? `<@&${vip.id}>` : '*Role Not set*'}.\n\n**__Official__**\n${official?.id ? `<@&${official.id}>` : '*Role Not set*'}.`

            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${message.guild.name}`)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(description)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.user.username}`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        } else {
            let helpContent = `**Custom Role Setup**\n\n`;
            helpContent += `\`${message.guild.prefix}setup add <name> <role>\` - Setups a role with the provided name.\n\n`;
            helpContent += `\`${message.guild.prefix}setup remove <name>\` - Removes a role with the provided name.\n\n`;
            helpContent += `\`${message.guild.prefix}setup reqrole <role>\` - Setups a requirement role.\n\n`;
            helpContent += `\`${message.guild.prefix}setup add girl <role>\` - Setups a role for girls\n\n`;
            helpContent += `\`${message.guild.prefix}setup add guest <role>\` - Setups a role for guests.\n\n`;
            helpContent += `\`${message.guild.prefix}setup add vip <role>\` - Setups a role for vip members.\n\n`;
            helpContent += `\`${message.guild.prefix}setup add official <role>\` - Setups a role for official members.\n\n`;
            helpContent += `\`${message.guild.prefix}setup list\` - Shows you the list of all custom roles.\n\n`;
            helpContent += `\`${message.guild.prefix}setup config\` - Shows you the configuration of custom roles.`;

            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${message.guild.name}`)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(helpContent)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.user.username}`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
    }
}
