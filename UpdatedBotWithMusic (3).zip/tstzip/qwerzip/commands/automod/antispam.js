const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    MessageFlags 
} = require('discord.js');
const enable = `<:cross:1436754701369737237><:tick:1436755134561521766>`
const disable = `<:cross:1436754701369737237><:tick:1436755134561521766>`
const protect = `<a:Spyder_antinuke:1180431827438153821>`
const hii = `<:Spyder:1438835471861026961>`
const wait = require('wait')

module.exports = {
    name: 'antispam',
    aliases: [],
    cooldown: 5,
    category: 'automod',
    subcommand: ['enable', 'disable', 'punishment', 'limit','strikes','config'],
    premium: false,
    run: async (client, message, args) => {
        try {
            let own = message.author.id == message.guild.ownerId
            if (!message.member.permissions.has('Administrator')) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have \`Administrator\` permissions to use this command.`)
                    )
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
            }
            if (!message.guild.members.me.permissions.has('Administrator')) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${client.emoji.cross} | I don't have \`Administrator\` permissions to execute this command.`)
                    )
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
            }
            if (
                !own &&
                message.member.roles.highest.position <=
                message.guild.members.me.roles.highest.position
            ) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have a higher role than me to use this command.`)
                    )
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
            }

            let prefix = message.guild.prefix || '&'

            const option = args[0]
            const isActivatedAlready =
                (await client.db.get(`antispam_${message.guild.id}`)) || null

            const antispamContainer = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`# __**Antispam**__`)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`Prevent spam and maintain the integrity of your server with Antispam! Our advanced algorithms swiftly detect and handle spam messages, ensuring a clean and enjoyable environment for your community.`)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**__Antispam Enable__**\nTo Enable Antispam, use \`${prefix}antispam enable\``)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**__Antispam Disable__**\nTo Disable Antispam, use \`${prefix}antispam disable\``)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**__Antispam Punishment__**\nConfigure the punishment for spammers.`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Options**\n\`ban\` - Ban spammers, \`kick\` - Kick spammers, \`mute\` - Mute spammers`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**__Antispam Limit__**\nConfigure the message limit to trigger antispam.`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Usage**\nUse numbers to specify the message limit, e.g., \`4\`, \`10\``)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**__Antispam Strikes__**\nConfigure the Strike limit to trigger antispam.`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Usage**\nUse numbers to specify the strike limit, e.g., \`1\`, \`10\`\n Defaults Strikes limit is 1`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**__Antispam Config__**\nUse ${prefix}Antispam config\nView Current Antispam Configuration`)
                )

            switch (option) {
                case undefined:
                    message.channel.send({ components: [antispamContainer], flags: MessageFlags.IsComponentsV2 })
                    break

                case 'enable':
                    if (!isActivatedAlready) {
                        await client.db.set(`antispam_${message.guild.id}`, true)
                        await client.db.set(`antispamlimit_${message.guild.id}`, 4)
                        await client.db.set(`antispamstrikes_${message.guild.id}`, 1)
                        await client.db.set(`antispamp_${message.guild.id}`, {
                            data: 'mute'
                        })

                        const enableContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`# Antispam Enabled`)
                            )
                            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**Congratulations! Antispam has been successfully enabled on your server.**`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**Enhanced Protection**\nEnjoy enhanced protection against spam messages!`)
                            )

                        await message.channel.send({ components: [enableContainer], flags: MessageFlags.IsComponentsV2 })
                    } else {
                        const settingsContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`# Antispam Settings for ${message.guild.name} ${protect}`)
                            )
                            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**Antispam Status**`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**Current Status**\nAntispam is already enabled on your server.\n\nCurrent Status: ${enable}`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**To Disable**\nTo disable Antispam, use \`${prefix}antispam disable\``)
                            )

                        await message.channel.send({ components: [settingsContainer], flags: MessageFlags.IsComponentsV2 })
                    }
                    break

                case 'disable':
                    if (isActivatedAlready) {
                        await client.db.set(`antispam_${message.guild.id}`, false)
                        await client.db.set(`antispamp_${message.guild.id}`, {
                            data: null
                        })
                        
                        const disableContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**Antispam Disabled**`)
                            )
                            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**Status**\nAntispam has been successfully disabled on your server.`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**Impact**\nYour server will no longer be protected against spam messages.`)
                            )

                        return message.channel.send({ components: [disableContainer], flags: MessageFlags.IsComponentsV2 })
                    } else {
                        const settingsContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**Antispam Status**`)
                            )
                            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**Current Status**\nAntispam is already disabled on your server.\n\nCurrent Status: ${disable}`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**To Enable**\nTo enable Antispam, use \`${prefix}antispam enable\``)
                            )

                        return message.channel.send({ components: [settingsContainer], flags: MessageFlags.IsComponentsV2 })
                    }
                case 'punishment':
                    let punishment = args[1]?.toLowerCase();
                    if (!punishment) {
                        const errorContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**Error:** Please provide valid punishment arguments.`)
                            )
                            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**Valid Punishments**\nValid options are: \`ban\`, \`kick\`, \`mute\`.`)
                            )

                        return message.channel.send({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 });
                    }
                    const actions = {
                        ban: {
                            description: 'Any user caught spamming will be banned.',
                            title: 'Ban',
                            dbValue: 'ban',
                        },
                        kick: {
                            description: 'Any user caught spamming will be kicked.',
                            title: 'Kick',
                            dbValue: 'kick',
                        },
                        mute: {
                            description: 'Any user caught spamming will be muted.',
                            title: 'Mute',
                            dbValue: 'mute',
                            extraField: { name: 'Duration', value: '5 minutes' }
                        }
                    };
                
                    const action = actions[punishment.toLowerCase()];
                    if (!action) {
                        const errorContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**Error:** Invalid punishment type provided.`)
                            )
                            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**Valid Punishments**\nValid options are: \`ban\`, \`kick\`, \`mute\`.`)
                            )

                        return message.channel.send({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 });
                    }
                
                    await client.db.set(`antispamp_${message.guild.id}`, { data: action.dbValue });
                
                    const punishContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# Anti-Spam Punishment Configured`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`The anti-spam punishment has been successfully configured.`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Punishment Type**\n${action.title}`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Action Taken**\n${action.description}`)
                        )

                    if (action.extraField) {
                        punishContainer.addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**${action.extraField.name}**\n${action.extraField.value}`)
                        )
                    }
                
                    await message.channel.send({ components: [punishContainer], flags: MessageFlags.IsComponentsV2 });
                    break;                    
                case 'limit':
                    let limit = args[1]
                    if (!limit) {
                        const errorContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**Error:** Please provide valid message limit arguments.`)
                            )
                            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**Example**\nUse the command like this: \`Antispam limit 4\``)
                            )

                        return message.channel.send({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 })
                    }
                    if (limit >= 4 && limit <= 10) {
                        await client.db.set(`antispamlimit_${message.guild.id}`, limit)
                        
                        const limitContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.tick} | **Spam Threshold Updated**`)
                            )
                            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**New Spam Threshold:** ${limit}`)
                            )

                        await message.channel.send({ components: [limitContainer], flags: MessageFlags.IsComponentsV2 })
                    } else {
                        const errorContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | **Error: Invalid Message Count Limit**`)
                            )
                            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**Valid Range**\nMessage count limit must be greater than 3 and less than 10`)
                            )

                        await message.channel.send({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 })
                    }
                    break;
                case 'strikes':
                    let strikes = args[1]
                    if (!strikes) {
                        const errorContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**Error:** Please provide valid strikes arguments.`)
                            )
                            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**Example**\nUse the command like this: \`Antispam strikes 4\``)
                            )

                        return message.channel.send({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 })
                    }
                    if (strikes >= 1 && strikes <= 10) {
                        await client.db.set(`antispamstrikes_${message.guild.id}`, strikes)
                        
                        const strikesContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.tick} | **Spam Warnings Updated**`)
                            )
                            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**New Spam Warnings:** ${strikes}`)
                            )

                        await message.channel.send({ components: [strikesContainer], flags: MessageFlags.IsComponentsV2 })
                    } else {
                        const errorContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**Error:** Please provide valid strikes arguments.`)
                            )
                            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**Example**\nUse the command like this: \`Antispam strikes 4\``)
                            )

                        await message.channel.send({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 })
                    }
                    break;

                case 'config':
                    const strike = await client.db.get(`antispamstrikes_${message.guild.id}`)
                    const punish = await client.db.get(`antispamp_${message.guild.id}`)
                    const limits = await client.db.get(`antispamlimit_${message.guild.id}`)
                    const value = await client.db.get(`antispam_${message.guild.id}`)
                    
                    const configContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# Antispam Config for ${message.guild.name}`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Antispam Status:** ${value ? client.emoji.tick : client.emoji.cross}`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Antispam Punishment Type:** ${punish ? punish.data : "None"}`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Antispam Strike Count:** ${strike ? strike : "None"}`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Antispam Limit Count:** ${limits ? limits : "None"}`)
                        )

                    await message.channel.send({ components: [configContainer], flags: MessageFlags.IsComponentsV2 })
                    break;
                default :
                    return message.channel.send({ components: [antispamContainer], flags: MessageFlags.IsComponentsV2 })
            
            }
        } catch (err) {
            console.error(err)
        }
    }
}
