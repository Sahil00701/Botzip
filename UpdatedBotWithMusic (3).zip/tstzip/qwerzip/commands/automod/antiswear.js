const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    MessageFlags 
} = require('discord.js');
let enable = `<:cross:1436754701369737237><:tick:1436755134561521766>`
let disable = `<:cross:1436754701369737237><:tick:1436755134561521766>`
let protect = `<a:Spyder_antinuke:1180431827438153821>`
let hii = `<:Spyder:1438835471861026961>`
const wait = require('wait')

module.exports = {
    name: 'antiswear',
    aliases: [],
    cooldown: 5,
    category: 'automod',
    subcommand: ['enable', 'disable', 'punishment','word add','word remove','word reset','word list'],
    premium: false,
    run: async (client, message, args) => {
        let own = message.author.id == message.guild.ownerId
        if (!message.member.permissions.has('Administrator')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have \`Administrator\` permissions to use this command.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
        }
        if (!message.guild.members.me.permissions.has('Administrator')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | I don't have \`Administrator\` permissions to execute this command.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
        }
        if (
            !own &&
            message.member.roles.highest.position <=
                message.guild.members.me.roles.highest.position
        ) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have a higher role than me to use this command.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
        }
        let prefix = message.guild.prefix || '&'

        const option = args[0]
        const isActivatedAlready =
            (await client.db.get(`antiswear_${message.guild.id}`)) ?? null

        const antiswearContainer = new ContainerBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`# __**AntiSwear**__`)
            )
            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`Fortify your server's security with Antiswear! Our cutting-edge algorithms swiftly detect and neutralize profanity, ensuring a safe and respectful environment for your community.`)
            )
            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**__AntiSwear Enable__**\nTo Enable AntiSwear, use \`${prefix}antiswear enable\``)
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**__AntiSwear Disable__**\nTo Disable AntiSwear, use \`${prefix}antiswear disable\``)
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**__AntiSwear Punishment__**\nConfigure the punishment for users posting suspicious links.`)
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**Options**\n\`ban\` - Ban users, \`kick\` - Kick users, \`mute\` - Mute users, \`none\` - Delete Bad Words`)
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**__AntiSwear Word Add__**\nAdd words to the AntiSwear list`)
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**__AntiSwear Word Remove__**\nRemove words from the AntiSwear list`)
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**__AntiSwear Word Reset__**\nReset the AntiSwear list`)
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**__AntiSwear Word List__**\nShow the list of AntiSwear words`)
            )

        switch (option) {
            case undefined:
                message.channel.send({ components: [antiswearContainer], flags: MessageFlags.IsComponentsV2 })
                break

            case 'enable':
                if (!isActivatedAlready) {
                    await client.db.set(`antiswear_${message.guild.id}`, true)
                    await client.db.set(`antiswearp_${message.guild.id}`, {
                        data: 'mute'
                    })

                    const enableContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# AntiSwear Enabled`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Congratulations! AntiSwear has been successfully enabled on your server.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Enhanced Protection**\nEnjoy enhanced protection against inappropriate words!`)
                        )

                    await message.channel.send({ components: [enableContainer], flags: MessageFlags.IsComponentsV2 })
                } else {
                    const settingsContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# AntiSwear Settings for ${message.guild.name} ${protect}`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**AntiSwear is already enabled on your server.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Current Status**\nAntiSwear is already enabled on your server.\n\nCurrent Status: ${enable}`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**To Disable**\nTo disable AntiSwear, use \`${prefix}antiswear disable\``)
                        )

                    await message.channel.send({ components: [settingsContainer], flags: MessageFlags.IsComponentsV2 })
                }
                break

            case 'disable':
                if (isActivatedAlready) {
                    await client.db.set(`antiswear_${message.guild.id}`, false)
                    await client.db.set(`antiswearp_${message.guild.id}`, {
                        data: null
                    })
                    
                    const disableContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# AntiSwear Disabled`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**AntiSwear has been successfully disabled on your server.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Impact**\nYour server will no longer be protected against inappropriate words!.`)
                        )

                    await message.channel.send({ components: [disableContainer], flags: MessageFlags.IsComponentsV2 })
                } else {
                    const settingsContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# AntiSwear Settings for ${message.guild.name} ${protect}`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**AntiSwear Status**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Current Status**\nAntiSwear is currently disabled on your server.\n\nCurrent Status: ${disable}`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**To Enable**\nTo enable AntiSwear, use \`${prefix}antiswear enable\``)
                        )

                    await message.channel.send({ components: [settingsContainer], flags: MessageFlags.IsComponentsV2 })
                }
                break

            case 'word':
                if (args[1] === 'add') {
                    if (!args[2]) {
                        const errorContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Oops! Please provide a valid word for my badwords list.`)
                            )
                        return message.channel.send({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 });
                    }
                    await client.db
                        .get(`antiswearwords_${message.guild.id}`)
                        .then(async (data) => {
                            let word = args[2].toLowerCase();
                            if (!data) {
                                await client.db.set(
                                    `antiswearwords_${message.guild.id}`,
                                    []
                                );
                                const waitContainer = new ContainerBuilder()
                                    .addTextDisplayComponents(
                                        new TextDisplayBuilder().setContent(`Please wait, setting up configuration for your server.`)
                                    )
                                let msg = await message.channel.send({ components: [waitContainer], flags: MessageFlags.IsComponentsV2 });
                                await client.util.sleep(2000);
                                const doneContainer = new ContainerBuilder()
                                    .addTextDisplayComponents(
                                        new TextDisplayBuilder().setContent(`Great news! Your server is now configured perfectly. Feel free to use AntiSwear module and enjoy using your server hassle-free! 🚀`)
                                    )
                                return await msg.edit({ components: [doneContainer], flags: MessageFlags.IsComponentsV2 });
                            }
                            if (word.length > 30) {
                                const errorContainer = new ContainerBuilder()
                                    .addTextDisplayComponents(
                                        new TextDisplayBuilder().setContent(`${client.emoji.cross} | The word "${word}" has more than 15 characters and cannot be added to the bad words list.`)
                                    )
                                return message.channel.send({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 });
                            }
                            if (word) {
                                if (!data.includes(word)) {
                                    await client.db.push(
                                        `antiswearwords_${message.guild.id}`,
                                        word
                                    );
                                    const successContainer = new ContainerBuilder()
                                        .addTextDisplayComponents(
                                            new TextDisplayBuilder().setContent(`${client.emoji.tick} | Success! The \`${word}\` word has been successfully added to bad words list.`)
                                        )
                                    return message.channel.send({ components: [successContainer], flags: MessageFlags.IsComponentsV2 });
                                } else {
                                    const errorContainer = new ContainerBuilder()
                                        .addTextDisplayComponents(
                                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | Oops! It appears that \`${word}\` is already in my bad words list.`)
                                        )
                                    return message.channel.send({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 });
                                }
                            } 

                        });
                } else if (args[1] === 'remove') {
                    if (!args[2]) {
                        const errorContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Oops! Please provide a valid word for removing in my badwords list.`)
                            )
                        return message.channel.send({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 });
                    }
                    await client.db
                        .get(`antiswearwords_${message.guild.id}`)
                        .then(async (data) => {
                            let word = args[2].toLowerCase();
                            if (!data) {
                                await client.db.set(
                                    `antiswearwords_${message.guild.id}`,
                                    []
                                );
                                const waitContainer = new ContainerBuilder()
                                    .addTextDisplayComponents(
                                        new TextDisplayBuilder().setContent(`Please wait, setting up configuration for your server.`)
                                    )
                                let msg = await message.channel.send({ components: [waitContainer], flags: MessageFlags.IsComponentsV2 });
                                await client.util.sleep(2000);
                                const doneContainer = new ContainerBuilder()
                                    .addTextDisplayComponents(
                                        new TextDisplayBuilder().setContent(`Great news! Your server is now configured perfectly. Feel free to use AntiSwear module and enjoy using your server hassle-free! 🚀`)
                                    )
                                return await msg.edit({ components: [doneContainer], flags: MessageFlags.IsComponentsV2 });
                            }

                            if (word) {
                                if (data.includes(word)) {
                                    await client.db.pull(
                                        `antiswearwords_${message.guild.id}`,
                                        word
                                    );
                                    const successContainer = new ContainerBuilder()
                                        .addTextDisplayComponents(
                                            new TextDisplayBuilder().setContent(`${client.emoji.tick} | Success! The \`${word}\` word has been successfully removed from bad words list.`)
                                        )
                                    return message.channel.send({ components: [successContainer], flags: MessageFlags.IsComponentsV2 });
                                } else {
                                    const errorContainer = new ContainerBuilder()
                                        .addTextDisplayComponents(
                                            new TextDisplayBuilder().setContent(`${client.emoji.cross} | Oops! It appears that \`${word}\` is not in my bad words list.`)
                                        )
                                    return message.channel.send({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 });
                                }
                            } 

                        });

                } else if (args[1] === 'reset') {
                    await client.db
                        .get(`antiswearwords_${message.guild.id}`)
                        .then(async (data) => {
                            if (!data) {
                                await client.db.set(
                                    `antiswearwords_${message.guild.id}`,
                                    []
                                );
                                const waitContainer = new ContainerBuilder()
                                    .addTextDisplayComponents(
                                        new TextDisplayBuilder().setContent(`Please wait, setting up configuration for your server.`)
                                    )
                                let msg = await message.channel.send({ components: [waitContainer], flags: MessageFlags.IsComponentsV2 });
                                await client.util.sleep(2000);
                                const doneContainer = new ContainerBuilder()
                                    .addTextDisplayComponents(
                                        new TextDisplayBuilder().setContent(`Great news! Your server is now configured perfectly. Feel free to use AntiSwear module and enjoy using your server hassle-free! 🚀`)
                                    )
                                return await msg.edit({ components: [doneContainer], flags: MessageFlags.IsComponentsV2 });
                            }


                            if (data.length > 0) {
                                const existingData = await client.db.get(
                                    `antiswearwords_${message.guild.id}`
                                )
                                if (existingData) {
                                    await client.db.set(
                                        `antiswearwords_${message.guild.id}`,[])
                                    const successContainer = new ContainerBuilder()
                                        .addTextDisplayComponents(
                                            new TextDisplayBuilder().setContent(`✨ Success! The server's bad word list has been cleared. You're all set to customize and optimize your experience now.`)
                                        )
                                    return message.channel.send({ components: [successContainer], flags: MessageFlags.IsComponentsV2 })
                                }
                            } else {
                                const errorContainer = new ContainerBuilder()
                                    .addTextDisplayComponents(
                                        new TextDisplayBuilder().setContent(`🌐 Whoops! It looks like no bad words has been set up in this server yet. No worries, though! You can easily configure one to tailor your experience and enhance server functionality.`)
                                    )
                                return message.channel.send({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 })
                            }
                        });
                } else if(args[1] === 'list') {
                    let words = (await client.db.get(`antiswearwords_${message.guild.id}`)) || [];
                    let mentions = [];
                    let i = 1;
                    
                    if (Array.isArray(words) && words.length !== 0) {
                        words.forEach((word) =>
                            mentions.push(`\`${i++}\`   \`${word}\``)
                        );
                    
                        const wordlistContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`# **BAD WORDS LIST**`)
                            )
                            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${mentions.join('\n')}`)
                            )

                        message.channel.send({ components: [wordlistContainer], flags: MessageFlags.IsComponentsV2 });
                    } else {
                        const errorContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | Oops! It seems like there's no designated badwords set up in this server. No worries, though! You can easily configure one to enhance your experience.`)
                            )
                        return message.channel.send({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 });
                    }
                    

                } else if(!args[1]) {
                    const errorContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Error**\nPlease provide valid punishment arguments.`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Valid Options**\n\`add\`, \`remove\`, \`reset\` , \`list\``)
                        )

                    return message.channel.send({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 })
                }
                break;

            case 'punishment':
                let punishment = args[1]?.toLowerCase()
                if (!punishment || !['ban', 'kick', 'mute', 'none'].includes(punishment)) {
                    const errorContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Invalid Punishment**`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Error**\nPlease provide valid punishment arguments.`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Valid Options**\n\`ban\`, \`kick\`, \`mute\`, \`none\``)
                        )

                    return message.channel.send({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 })
                }
                if (punishment === 'ban') {
                    await client.db.set(`antiswearp_${message.guild.id}`, {
                        data: 'ban'
                    })
                    
                    const banContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# Punishment Configured`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`The punishment has been successfully configured.`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Punishment Type**\nBan`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Action Taken**\nAny user violating the rules will be banned from the server.`)
                        )

                    await message.channel.send({ components: [banContainer], flags: MessageFlags.IsComponentsV2 })
                }
                if (punishment === 'kick') {
                    await client.db.set(`antiswearp_${message.guild.id}`, {
                        data: 'kick'
                    })
                    
                    const kickContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# Punishment Configured`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`The punishment has been successfully configured.`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Punishment Type**\nKick`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Action Taken**\nAny user violating the rules will be kicked from the server.`)
                        )

                    await message.channel.send({ components: [kickContainer], flags: MessageFlags.IsComponentsV2 })
                }
                if (punishment === 'mute') {
                    await client.db.set(`antiswearp_${message.guild.id}`, {
                        data: 'mute'
                    })
                    
                    const muteContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# AntiSwear Punishment Configured`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`The antiswear punishment has been successfully configured.`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Punishment Type**\nMute`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Action Taken**\nAny user caught using bad words will be muted.`)
                        )

                    await message.channel.send({ components: [muteContainer], flags: MessageFlags.IsComponentsV2 })
                }
                if (punishment === 'none') {
                    await client.db.set(`antiswearp_${message.guild.id}`, {
                        data: 'none'
                    })
                    
                    const noneContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# AntiSwear Punishment Configured`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`The antiswear punishment has been successfully configured.`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Punishment Type**\nNone`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Action Taken**\nAny user caught using bad words his messages will be deleted.`)
                        )

                    await message.channel.send({ components: [noneContainer], flags: MessageFlags.IsComponentsV2 })
                }
                break;
            default:
                return message.channel.send({ components: [antiswearContainer], flags: MessageFlags.IsComponentsV2 })
        }
    }
}
