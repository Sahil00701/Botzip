const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    MessageFlags 
} = require('discord.js');
const wait = require('wait')

module.exports = {
    name: 'antilink',
    aliases: [],
    cooldown: 5,
    category: 'automod',
    subcommand: ['enable', 'disable', 'punishment', 'config'],
    premium: false,
    run: async (client, message, args) => {
        const { enable , disable, protect , hii } = client.emoji
        
        let own = message.author.id == message.guild.ownerId
        if (!message.member.permissions.has('Administrator')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have \`Administrator\` permissions to use this command.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
        }
        if (!message.guild.members.me.permissions.has('Administrator')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | I don't have \`Administrator\` permissions to execute this command.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
        }
        if (
            !own &&
            message.member.roles.highest.position <=
                message.guild.members.me.roles.highest.position
        ) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have a higher role than me to use this command.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
        }
        let prefix = message.guild.prefix || '&'

        const option = args[0]
        const isActivatedAlready =
            (await client.db.get(`antilink_${message.guild.id}`)) || null

        const antilinkContainer = new ContainerBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`# __**Antilink**__`)
            )
            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`Enhance your server's protection with Antilink! Our advanced algorithms swiftly identify suspicious links and take immediate action against them, safeguarding your community from potential threats.`)
            )
            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**__Antilink Enable__**\nTo Enable Antilink, use \`${prefix}antilink enable\``)
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**__Antilink Disable__**\nTo Disable Antilink, use \`${prefix}antilink disable\``)
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**__Antilink Punishment__**\nConfigure the punishment for users posting suspicious links.`)
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**Options**\n\`ban\` - Ban users, \`kick\` - Kick users, \`mute\` - Mute users, \`none\` - Delete Messages Which includes links`)
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**__Antilink Config__**\nUse ${prefix}Antilink config\nView Current Antilink Configuration`)
            )

        switch (option) {
            case undefined:
                message.channel.send({ components: [antilinkContainer], flags: MessageFlags.IsComponentsV2 })
                break

            case 'enable':
                if (!isActivatedAlready) {
                    await client.db.set(`antilink_${message.guild.id}`, true)
                    await client.db.set(`antilinkp_${message.guild.id}`, {
                        data: 'mute'
                    })

                    const enableContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# Antilink Enabled`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Congratulations! Antilink has been successfully enabled on your server.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Enhanced Protection**\nEnjoy enhanced protection against suspicious links!`)
                        )

                    await message.channel.send({ components: [enableContainer], flags: MessageFlags.IsComponentsV2 })
                } else {
                    const settingsContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# Antilink Settings for ${message.guild.name} ${protect}`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Antilink is already enabled on your server.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Current Status**\nAntilink is already enabled on your server.\n\nCurrent Status: ${enable}`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**To Disable**\nTo disable Antilink, use \`${prefix}antilink disable\``)
                        )

                    await message.channel.send({ components: [settingsContainer], flags: MessageFlags.IsComponentsV2 })
                }
                break

            case 'disable':
                if (isActivatedAlready) {
                    await client.db.set(`antilink_${message.guild.id}`, false)
                    await client.db.set(`antilinkp_${message.guild.id}`, {
                        data: null
                    })
                    
                    const disableContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# Antilink Disabled`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Antilink has been successfully disabled on your server.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Impact**\nYour server will no longer be protected against suspicious links.`)
                        )

                    await message.channel.send({ components: [disableContainer], flags: MessageFlags.IsComponentsV2 })
                } else {
                    const settingsContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# Antilink Settings for ${message.guild.name} ${protect}`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Antilink Status**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Current Status**\nAntilink is currently disabled on your server.\n\nCurrent Status: ${disable}`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**To Enable**\nTo enable Antilink, use \`${prefix}antilink enable\``)
                        )

                    await message.channel.send({ components: [settingsContainer], flags: MessageFlags.IsComponentsV2 })
                }
                break

            case 'punishment':
                let punishment = args[1]?.toLowerCase()
                if (!punishment || !['ban', 'kick', 'mute', 'none'].includes(punishment)) {
                    const errorContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Invalid Punishment**`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Error**\nPlease provide valid punishment arguments.`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Valid Options**\n\`ban\`, \`kick\`, \`mute\`, \`none\``)
                        )

                    return message.channel.send({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 })
                }
                if (punishment === 'ban') {
                    await client.db.set(`antilinkp_${message.guild.id}`, {
                        data: 'ban'
                    })
                    
                    const banContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# Punishment Configured`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`The punishment has been successfully configured.`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Punishment Type**\nBan`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Action Taken**\nAny user violating the rules will be banned from the server.`)
                        )

                    await message.channel.send({ components: [banContainer], flags: MessageFlags.IsComponentsV2 })
                }
                if (punishment === 'kick') {
                    await client.db.set(`antilinkp_${message.guild.id}`, {
                        data: 'kick'
                    })
                    
                    const kickContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# Punishment Configured`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`The punishment has been successfully configured.`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Punishment Type**\nKick`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Action Taken**\nAny user violating the rules will be kicked from the server.`)
                        )

                    await message.channel.send({ components: [kickContainer], flags: MessageFlags.IsComponentsV2 })
                }
                if (punishment === 'mute') {
                    await client.db.set(`antilinkp_${message.guild.id}`, {
                        data: 'mute'
                    })
                    
                    const muteContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# Antilink Punishment Configured`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`The antilink punishment has been successfully configured.`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Punishment Type**\nMute`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Action Taken**\nAny user caught posting links will be muted.`)
                        )

                    await message.channel.send({ components: [muteContainer], flags: MessageFlags.IsComponentsV2 })
                }
                if (punishment === 'none') {
                    await client.db.set(`antilinkp_${message.guild.id}`, {
                        data: 'none'
                    })
                    
                    const noneContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# Antilink Punishment Configured`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`The antilink punishment has been successfully configured.`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Punishment Type**\nNone`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Action Taken**\nAny user caught posting links his messages will be deleted.`)
                        )

                    await message.channel.send({ components: [noneContainer], flags: MessageFlags.IsComponentsV2 })
                }
                break;
            case 'config':
                const punish = await client.db.get(`antilinkp_${message.guild.id}`)
                const value = await client.db.get(`antilink_${message.guild.id}`)
                
                const configContainer = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`# Antilink Config for ${message.guild.name}`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**Antilink Status:** ${value ? client.emoji.tick : client.emoji.cross}`)
                    )
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**Antilink Punishment Type:** ${punish ? punish.data : "None"}`)
                    )

                await message.channel.send({ components: [configContainer], flags: MessageFlags.IsComponentsV2 })
                break;
            default: 
                return message.channel.send({ components: [antilinkContainer], flags: MessageFlags.IsComponentsV2 })
        }
    }
}
