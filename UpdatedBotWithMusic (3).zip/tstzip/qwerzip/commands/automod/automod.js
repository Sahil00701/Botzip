const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    StringSelectMenuBuilder, 
    ActionRowBuilder, 
    MessageFlags, 
    ComponentType 
} = require('discord.js');

module.exports = {
    name: 'automod',
    aliases: [],
    cooldown: 5,
    category: 'automod',
    subcommand: ['whitelist user', 'whitelist role', 'whitelist channel'],
    premium: false,
    run: async (client, message, args) => {
try {
        let own = message.author.id == message.guild.ownerId
        if (!message.member.permissions.has('Administrator')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have \`Administrator\` permissions to use this command.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
        }
        if (!message.guild.members.me.permissions.has('Administrator')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | I don't have \`Administrator\` permissions to execute this command.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
        }
        if (
            !own &&
            message.member.roles.highest.position <=
                message.guild.members.me.roles.highest.position
        ) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have a higher role than me to use this command.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
        }
        const subcommand = args[0]?.toLowerCase()
        const type = args[1]?.toLowerCase()
        const action = args[2]?.toLowerCase()
        const whitelistKey = `automodbypass_${message.guild.id}`;
        const whitelist = await client.db.get(whitelistKey) || { user: [], role: [], channel: [] };
        
        if(!args[0]) {
            const helpContainer = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`# Automod Whitelist`)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod\`**\n**Shows the current page.**`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod whitelist role add <role>\`**\n**Adds the provided role to Automod Whitelist Configuration.**`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod whitelist role remove <role>\`**\n**Remove the provided role to Automod Whitelist Configuration.**`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod whitelist role list\`**\n**Shows the Automod role Whitelist list.**`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod whitelist role reset\`**\n**Reset the Automod Whitelist role Configuration**`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod whitelist user add <user>\`**\n**Adds the provided user to Automod Whitelist user Configuration.**`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod whitelist user remove <user>\`**\n**Remove the provided user to Automod Whitelist user Configuration.**`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod whitelist user list\`**\n**Shows the Automod Whitelist user list.**`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod whitelist user reset\`**\n**Reset the Automod whitelist user Configuration**`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod whitelist channel add <channel>\`**\n**Adds the provided channel to Automod Whitelist channel Configuration.**`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod whitelist channel remove <channel>\`**\n**Remove the provided channel to Automod Whitelist channel Configuration.**`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod whitelist channel list\`**\n**Shows the Automod Whitelist channel list.**`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod whitelist channel reset\`**\n**Reset the Automod whitelist channel Configuration**`)
                )

            return message.channel.send({ components: [helpContainer], flags: MessageFlags.IsComponentsV2 })
        } else if (subcommand === 'whitelist') {
             if (action === 'add') {
                let id;
                let itemName; 
                if (type === 'user') {
                    const userMention = getUserFromMention(message, args[3]) ||
                        message.guild.members.cache.get(args[3])
                    if (!userMention) {
                        const userHelpContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`# AUTOMOD WHITELIST USER OPTIONS`)
                            )
                            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Whitelist User\`**\n**Shows the current page.**`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Automod whitelist user add <user>\`**\n**Adds the provided user to Automod Whitelist Configuration.**`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Automod whitelist user remove <user>\`**\n**Remove the provided user to Automod Whitelist Configuration.**`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Automod whitelist user list\`**\n**Shows the Automod user Whitelist list.**`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Automod whitelist user reset\`**\n**Reset the Automod Whitelist user Configuration**`)
                            )

                        return await message.channel.send({ components: [userHelpContainer], flags: MessageFlags.IsComponentsV2 })
                   }
                    id = userMention.id;
                    itemName = userMention.username;
                } else if (type === 'role') {
                    const roleMention = getRoleFromMention(message, args[3]) ||
                    message.guild.roles.cache.get(args[3])
                    if (!roleMention) {
                        const roleHelpContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`# AUTOMOD WHITELIST ROLE OPTIONS`)
                            )
                            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Whitelist Role\`**\n**Shows the current page.**`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Automod whitelist role add <role>\`**\n**Adds the provided role to Automod Whitelist Configuration.**`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Automod whitelist role remove <role>\`**\n**Remove the provided role to Automod Whitelist Configuration.**`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Automod whitelist role list\`**\n**Shows the Automod role Whitelist list.**`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Automod whitelist role reset\`**\n**Reset the Automod Whitelist role Configuration**`)
                            )

                        return await message.channel.send({ components: [roleHelpContainer], flags: MessageFlags.IsComponentsV2 })
                     }
                    id = roleMention.id;
                    itemName = roleMention.name;
                } else if (type === 'channel') {
                    const channelMention = getChannelFromMention(message, args[3]) || message.guild.channels.cache.get(args[3])
                    if (!channelMention) {
                        const channelHelpContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`# AUTOMOD WHITELIST CHANNEL OPTIONS`)
                            )
                            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Whitelist channel\`**\n**Shows the current page.**`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Automod whitelist channel add <channel>\`**\n**Adds the provided channel to Automod Whitelist Configuration.**`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Automod whitelist channel remove <channel>\`**\n**Remove the provided channel to Automod Whitelist Configuration.**`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Automod whitelist channel list\`**\n**Shows the Automod channel Whitelist list.**`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Automod whitelist channel reset\`**\n**Reset the Automod Whitelist channel Configuration**`)
                            )

                        return await message.channel.send({ components: [channelHelpContainer], flags: MessageFlags.IsComponentsV2 })
                    }
                    id = channelMention.id;
                    itemName = channelMention.name;
                 } if(!['user', 'role', 'channel'].includes(type) || !type) {
                    const helpContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# Automod Whitelist`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod\`**\n**Shows the current page.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist role add <role>\`**\n**Adds the provided role to Automod Whitelist Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist role remove <role>\`**\n**Remove the provided role to Automod Whitelist Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist role list\`**\n**Shows the Automod role Whitelist list.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist role reset\`**\n**Reset the Automod Whitelist role Configuration**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist user add <user>\`**\n**Adds the provided user to Automod Whitelist user Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist user remove <user>\`**\n**Remove the provided user to Automod Whitelist user Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist user list\`**\n**Shows the Automod Whitelist user list.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist user reset\`**\n**Reset the Automod whitelist user Configuration**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist channel add <channel>\`**\n**Adds the provided channel to Automod Whitelist channel Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist channel remove <channel>\`**\n**Remove the provided channel to Automod Whitelist channel Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist channel list\`**\n**Shows the Automod Whitelist channel list.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist channel reset\`**\n**Reset the Automod whitelist channel Configuration**`)
                        )

                    return message.channel.send({ components: [helpContainer], flags: MessageFlags.IsComponentsV2 })
            }
                  const alreadyWhitelisted = whitelist[type].some(entry => entry.id === id);
                if (alreadyWhitelisted) {
                    return message.reply({ content: `${type.charAt(0).toUpperCase() + type.slice(1)} is already whitelisted.` });
                }

                const row = new ActionRowBuilder()
                    .addComponents(
                        new StringSelectMenuBuilder()
                            .setCustomId('whitelist_options')
                            .setPlaceholder('Select automod whitelist settings')
                            .setMinValues(0)
                            .setMaxValues(4)
                            .addOptions([
                                {
                                    label: 'Antilink',
                                    description: `automod whitelist ${type} with Antilink permissions`,
                                    value: 'antilink'
                                },
                                {
                                    label: 'Antispam',
                                    description: `automod whitelist ${type} with Antispam permissions`,
                                    value: 'antispam'
                                },
                                {
                                    label: 'Antiswear',
                                    description: `automod whitelist ${type} with Antiswear permissions`,
                                    value: 'antiswear'
                                },
                                {
                                    label: 'Antiinvite',
                                    description: `automod whitelist ${type} with Antiinvite permissions`,
                                    value: 'antiinvite'
                                }
                            ])
                    );


                const initialMessage = await message.reply({
                    content: `Please select which settings you want to whitelist for the ${type} with ID ${id} (${itemName}).`,
                    components: [row]
                });

                const filter = interaction => interaction.user.id === message.author.id && interaction.customId === 'whitelist_options';
                const collector = initialMessage.createMessageComponentCollector({ filter, componentType: ComponentType.StringSelect, time: 15000 });

                collector.on('collect', async interaction => {
                    if (interaction.user.id !== message.author.id) return interaction.reply({ content: `You are not allowed to interact with these buttons.`, flags: 64 });
                    const selectedValues = interaction.values; 
                    const newEntry = {
                        id: id,
                        settings: {
                            antilink: selectedValues.includes('antilink'),
                            antispam: selectedValues.includes('antispam'),
                            antiswear: selectedValues.includes('antiswear'),
                            antiinvite: selectedValues.includes('antiinvite')
                        }
                    };
                    whitelist[type].push(newEntry);
                    await client.db.set(whitelistKey, whitelist);
                    await interaction.update({ content: `Successfully added ${type} with ID ${id} (${itemName}) with the selected settings: ${selectedValues.join(', ')}`, components: [] });
                });
                collector.on('end', collected => {
                    if (collected.size === 0) {
                        initialMessage.edit({ content: 'No options selected. The whitelist addition was canceled.', components: [] });
                    }
                });
            } else if (action === 'remove') {
                let idToRemove;
                let itemName;
                if (type === 'user') {
                    const userMention = getUserFromMention(message, args[3]) ||
                    message.guild.members.cache.get(args[3])
                if (!userMention) {
                    const userHelpContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# AUTOMOD WHITELIST USER OPTIONS`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Whitelist User\`**\n**Shows the current page.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist user add <user>\`**\n**Adds the provided user to Automod Whitelist Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist user remove <user>\`**\n**Remove the provided user to Automod Whitelist Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist user list\`**\n**Shows the Automod user Whitelist list.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist user reset\`**\n**Reset the Automod Whitelist user Configuration**`)
                        )

                    return await message.channel.send({ components: [userHelpContainer], flags: MessageFlags.IsComponentsV2 })
               }
                   idToRemove = userMention.id;
                   itemName = `<@${userMention.id}>`
                } else if (type === 'role') {
                    const roleMention = getRoleFromMention(message, args[3]) ||
                    message.guild.roles.cache.get(args[3])
                    if (!roleMention) {
                        const roleHelpContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`# AUTOMOD WHITELIST ROLE OPTIONS`)
                            )
                            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Whitelist Role\`**\n**Shows the current page.**`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Automod whitelist role add <role>\`**\n**Adds the provided role to Automod Whitelist Configuration.**`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Automod whitelist role remove <role>\`**\n**Remove the provided role to Automod Whitelist Configuration.**`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Automod whitelist role list\`**\n**Shows the Automod role Whitelist list.**`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Automod whitelist role reset\`**\n**Reset the Automod Whitelist role Configuration**`)
                            )

                        return await message.channel.send({ components: [roleHelpContainer], flags: MessageFlags.IsComponentsV2 })
                    }
                    idToRemove = roleMention.id;
                    itemName = `<@&${roleMention.id}>`
                } else if (type === 'channel') {
                    const channelMention = getChannelFromMention(message, args[3]) || message.guild.channels.cache.get(args[3])
                    if (!channelMention) {
                        const channelHelpContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`# AUTOMOD WHITELIST CHANNEL OPTIONS`)
                            )
                            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Whitelist channel\`**\n**Shows the current page.**`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Automod whitelist channel add <channel>\`**\n**Adds the provided channel to Automod Whitelist Configuration.**`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Automod whitelist channel remove <channel>\`**\n**Remove the provided channel to Automod Whitelist Configuration.**`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Automod whitelist channel list\`**\n**Shows the Automod channel Whitelist list.**`)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**\`Automod whitelist channel reset\`**\n**Reset the Automod Whitelist channel Configuration**`)
                            )

                        return await message.channel.send({ components: [channelHelpContainer], flags: MessageFlags.IsComponentsV2 })
                    }
                    idToRemove = channelMention.id;
                    itemName = `<#${channelMention.id}>`
                } if(!['user', 'role', 'channel'].includes(type) || !type) {
                    const helpContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# Automod Whitelist`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod\`**\n**Shows the current page.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist role add <role>\`**\n**Adds the provided role to Automod Whitelist Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist role remove <role>\`**\n**Remove the provided role to Automod Whitelist Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist role list\`**\n**Shows the Automod role Whitelist list.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist role reset\`**\n**Reset the Automod Whitelist role Configuration**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist user add <user>\`**\n**Adds the provided user to Automod Whitelist user Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist user remove <user>\`**\n**Remove the provided user to Automod Whitelist user Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist user list\`**\n**Shows the Automod Whitelist user list.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist user reset\`**\n**Reset the Automod whitelist user Configuration**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist channel add <channel>\`**\n**Adds the provided channel to Automod Whitelist channel Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist channel remove <channel>\`**\n**Remove the provided channel to Automod Whitelist channel Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist channel list\`**\n**Shows the Automod Whitelist channel list.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist channel reset\`**\n**Reset the Automod whitelist channel Configuration**`)
                        )

                    return message.channel.send({ components: [helpContainer], flags: MessageFlags.IsComponentsV2 })
                }
                const index = whitelist[type].findIndex(entry => entry.id === idToRemove);
                if (index === -1) {
                    return message.reply({ content: `${type.charAt(0).toUpperCase() + type.slice(1)} is not whitelisted.` });
                }
                whitelist[type].splice(index, 1);
                await client.db.set(whitelistKey, whitelist);
                return message.reply({ content: `Successfully removed ${itemName} from the ${type} whitelist.` });
            } else if (action === 'reset') {
                if(!['user', 'role', 'channel'].includes(type) || !type) {
                    const helpContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# Automod Whitelist`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod\`**\n**Shows the current page.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist role add <role>\`**\n**Adds the provided role to Automod Whitelist Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist role remove <role>\`**\n**Remove the provided role to Automod Whitelist Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist role list\`**\n**Shows the Automod role Whitelist list.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist role reset\`**\n**Reset the Automod Whitelist role Configuration**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist user add <user>\`**\n**Adds the provided user to Automod Whitelist user Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist user remove <user>\`**\n**Remove the provided user to Automod Whitelist user Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist user list\`**\n**Shows the Automod Whitelist user list.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist user reset\`**\n**Reset the Automod whitelist user Configuration**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist channel add <channel>\`**\n**Adds the provided channel to Automod Whitelist channel Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist channel remove <channel>\`**\n**Remove the provided channel to Automod Whitelist channel Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist channel list\`**\n**Shows the Automod Whitelist channel list.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist channel reset\`**\n**Reset the Automod whitelist channel Configuration**`)
                        )

                    return message.channel.send({ components: [helpContainer], flags: MessageFlags.IsComponentsV2 })
                }
                whitelist[type] = [];
                await client.db.set(whitelistKey, whitelist);
                return message.reply({ content: `Successfully reset the ${type} whitelist.` });
            } else if (action === 'list') {
                if(!['user', 'role', 'channel'].includes(type) || !type) {
                    const helpContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# Automod Whitelist`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod\`**\n**Shows the current page.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist role add <role>\`**\n**Adds the provided role to Automod Whitelist Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist role remove <role>\`**\n**Remove the provided role to Automod Whitelist Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist role list\`**\n**Shows the Automod role Whitelist list.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist role reset\`**\n**Reset the Automod Whitelist role Configuration**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist user add <user>\`**\n**Adds the provided user to Automod Whitelist user Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist user remove <user>\`**\n**Remove the provided user to Automod Whitelist user Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist user list\`**\n**Shows the Automod Whitelist user list.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist user reset\`**\n**Reset the Automod whitelist user Configuration**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist channel add <channel>\`**\n**Adds the provided channel to Automod Whitelist channel Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist channel remove <channel>\`**\n**Remove the provided channel to Automod Whitelist channel Configuration.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist channel list\`**\n**Shows the Automod Whitelist channel list.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**\`Automod whitelist channel reset\`**\n**Reset the Automod whitelist channel Configuration**`)
                        )

                    return message.channel.send({ components: [helpContainer], flags: MessageFlags.IsComponentsV2 })
                }
                const list = whitelist[type];
                if (list.length === 0) {
                    return message.reply({ content: `No ${type}s are whitelisted.` });
                }
                let listContent = '';
                if (type === 'user') {
                    listContent = list.map((entry, index) => `${index + 1}. <@${entry.id}> - Antilink: ${entry.settings.antilink ? '✅' : '❌'}, Antispam: ${entry.settings.antispam ? '✅' : '❌'}, Antiswear: ${entry.settings.antiswear ? '✅' : '❌'}, Antiinvite: ${entry.settings.antiinvite ? '✅' : '❌'}`).join('\n');
                } else if (type === 'role') {
                    listContent = list.map((entry, index) => `${index + 1}. <@&${entry.id}> - Antilink: ${entry.settings.antilink ? '✅' : '❌'}, Antispam: ${entry.settings.antispam ? '✅' : '❌'}, Antiswear: ${entry.settings.antiswear ? '✅' : '❌'}, Antiinvite: ${entry.settings.antiinvite ? '✅' : '❌'}`).join('\n');
                } else if (type === 'channel') {
                    listContent = list.map((entry, index) => `${index + 1}. <#${entry.id}> - Antilink: ${entry.settings.antilink ? '✅' : '❌'}, Antispam: ${entry.settings.antispam ? '✅' : '❌'}, Antiswear: ${entry.settings.antiswear ? '✅' : '❌'}, Antiinvite: ${entry.settings.antiinvite ? '✅' : '❌'}`).join('\n');
                }

                const listContainer = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`# Whitelisted ${type.charAt(0).toUpperCase() + type.slice(1)}s`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(listContent)
                    )

                return message.channel.send({ components: [listContainer], flags: MessageFlags.IsComponentsV2 });
            } else {
                const helpContainer = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`# Automod Whitelist`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**\`Automod\`**\n**Shows the current page.**`)
                    )
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**\`Automod whitelist role add <role>\`**\n**Adds the provided role to Automod Whitelist Configuration.**`)
                    )
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**\`Automod whitelist role remove <role>\`**\n**Remove the provided role to Automod Whitelist Configuration.**`)
                    )
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**\`Automod whitelist role list\`**\n**Shows the Automod role Whitelist list.**`)
                    )
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**\`Automod whitelist role reset\`**\n**Reset the Automod Whitelist role Configuration**`)
                    )
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**\`Automod whitelist user add <user>\`**\n**Adds the provided user to Automod Whitelist user Configuration.**`)
                    )
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**\`Automod whitelist user remove <user>\`**\n**Remove the provided user to Automod Whitelist user Configuration.**`)
                    )
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**\`Automod whitelist user list\`**\n**Shows the Automod Whitelist user list.**`)
                    )
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**\`Automod whitelist user reset\`**\n**Reset the Automod whitelist user Configuration**`)
                    )
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**\`Automod whitelist channel add <channel>\`**\n**Adds the provided channel to Automod Whitelist channel Configuration.**`)
                    )
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**\`Automod whitelist channel remove <channel>\`**\n**Remove the provided channel to Automod Whitelist channel Configuration.**`)
                    )
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**\`Automod whitelist channel list\`**\n**Shows the Automod Whitelist channel list.**`)
                    )
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**\`Automod whitelist channel reset\`**\n**Reset the Automod whitelist channel Configuration**`)
                    )

                return message.channel.send({ components: [helpContainer], flags: MessageFlags.IsComponentsV2 })
            }
        } else {
            const helpContainer = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`# Automod Whitelist`)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod\`**\n**Shows the current page.**`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod whitelist role add <role>\`**\n**Adds the provided role to Automod Whitelist Configuration.**`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod whitelist role remove <role>\`**\n**Remove the provided role to Automod Whitelist Configuration.**`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod whitelist role list\`**\n**Shows the Automod role Whitelist list.**`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod whitelist role reset\`**\n**Reset the Automod Whitelist role Configuration**`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod whitelist user add <user>\`**\n**Adds the provided user to Automod Whitelist user Configuration.**`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod whitelist user remove <user>\`**\n**Remove the provided user to Automod Whitelist user Configuration.**`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod whitelist user list\`**\n**Shows the Automod Whitelist user list.**`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod whitelist user reset\`**\n**Reset the Automod whitelist user Configuration**`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod whitelist channel add <channel>\`**\n**Adds the provided channel to Automod Whitelist channel Configuration.**`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod whitelist channel remove <channel>\`**\n**Remove the provided channel to Automod Whitelist channel Configuration.**`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod whitelist channel list\`**\n**Shows the Automod Whitelist channel list.**`)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**\`Automod whitelist channel reset\`**\n**Reset the Automod whitelist channel Configuration**`)
                )

            return message.channel.send({ components: [helpContainer], flags: MessageFlags.IsComponentsV2 })
        }
    } catch(err) {
        console.error(err)
    }
}
}

function getUserFromMention(message, mention) {
    if (!mention) return null;
    const matches = mention.match(/^<@!?(\d+)>$/);
    if (!matches) return null;
    const userId = matches[1];
    return message.guild.members.cache.get(userId);
}

function getRoleFromMention(message, mention) {
    if (!mention) return null;
    const matches = mention.match(/^<@&(\d+)>$/);
    if (!matches) return null;
    const roleId = matches[1];
    return message.guild.roles.cache.get(roleId);
}

function getChannelFromMention(message, mention) {
    if (!mention) return null;
    const matches = mention.match(/^<#(\d+)>$/);
    if (!matches) return null;
    const channelId = matches[1];
    return message.guild.channels.cache.get(channelId);
}
