const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    MessageFlags 
} = require('discord.js');
const wait = require('wait')

module.exports = {
    name: 'antiinvite',
    aliases: [],
    cooldown: 5,
    category: 'automod',
    subcommand: ['enable', 'disable', 'punishment','config'],
    premium: false,
    run: async (client, message, args) => {
        const { enable , disable, protect , hii } = client.emoji
        
        let own = message.author.id == message.guild.ownerId
        if (!message.member.permissions.has('Administrator')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have \`Administrator\` permissions to use this command.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
        }
        if (!message.guild.members.me.permissions.has('Administrator')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | I don't have \`Administrator\` permissions to execute this command.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
        }
        if (
            !own &&
            message.member.roles.highest.position <=
                message.guild.members.me.roles.highest.position
        ) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have a higher role than me to use this command.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
        }
        let prefix = message.guild.prefix || '&'

        const option = args[0]
        const isActivatedAlready =
            (await client.db.get(`antiinvite_${message.guild.id}`)) || { enabled : null , punishment : null}

        const antiinviteContainer = new ContainerBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`# __**Antiinvite**__`)
            )
            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`Protect your server with AntiInvite! Our intelligent system detects and blocks Discord invite links, ensuring your community remains safe from spam and unauthorized promotions.`)
            )
            .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**__Antiinvite Enable__**\nTo Enable Antiinvite, use \`${prefix}antiinvite enable\``)
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**__Antiinvite Disable__**\nTo Disable Antiinvite, use \`${prefix}antiinvite disable\``)
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**__Antiinvite Punishment__**\nConfigure the punishment for users posting discord links.`)
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**Options**\n\`ban\` - Ban users, \`kick\` - Kick users, \`mute\` - Mute users, \`none\` - Delete Messages Which includes links`)
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**__Antiinvite Config__**\nUse ${prefix}Antiinvite config\nView Current Antiinvite Configuration`)
            )

        switch (option) {
            case undefined:
                message.channel.send({ components: [antiinviteContainer], flags: MessageFlags.IsComponentsV2 })
                break

            case 'enable':
                if (!isActivatedAlready.enabled) {
                    let data = await client.db.get(`antiinvite_${message.guild.id}`) || { enabled : null , punishment : null}
                    data.enabled = true
                    data.punishment = 'mute'
                    await client.db.set(`antiinvite_${message.guild.id}`, data)
                    
                    const enableContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# Antiinvite Enabled`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Congratulations! Antiinvite has been successfully enabled on your server.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Enhanced Protection**\nEnjoy enhanced protection against discord links!`)
                        )

                    await message.channel.send({ components: [enableContainer], flags: MessageFlags.IsComponentsV2 })
                } else {
                    const settingsContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# Antiinvite Settings for ${message.guild.name} ${protect}`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Antiinvite is already enabled on your server.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Current Status**\nAntiinvite is already enabled on your server.\n\nCurrent Status: ${enable}`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**To Disable**\nTo disable Antiinvite, use \`${prefix}antiinvite disable\``)
                        )

                    await message.channel.send({ components: [settingsContainer], flags: MessageFlags.IsComponentsV2 })
                }
                break

            case 'disable':
                if (isActivatedAlready.enabled) {
                    let data = await client.db.get(`antiinvite_${message.guild.id}`) || { enabled : null , punishment : null}
                    data.enabled = null
                    data.punishment = null
                    await client.db.set(`antiinvite_${message.guild.id}`, data)
                    
                    const disableContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# Antiinvite Disabled`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Antiinvite has been successfully disabled on your server.**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Impact**\nYour server will no longer be protected against discord links.`)
                        )

                    await message.channel.send({ components: [disableContainer], flags: MessageFlags.IsComponentsV2 })
                } else {
                    const settingsContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# Antiinvite Settings for ${message.guild.name} ${protect}`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Antiinvite Status**`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Current Status**\nAntiinvite is currently disabled on your server.\n\nCurrent Status: ${disable}`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**To Enable**\nTo enable Antiinvite, use \`${prefix}antiinvite enable\``)
                        )

                    await message.channel.send({ components: [settingsContainer], flags: MessageFlags.IsComponentsV2 })
                }
                break

            case 'punishment':
                let punishment = args[1]?.toLowerCase()
                if (!punishment || !['ban', 'kick', 'mute', 'none'].includes(punishment)) {
                    const errorContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Invalid Punishment**`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Error**\nPlease provide valid punishment arguments.`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Valid Options**\n\`ban\`, \`kick\`, \`mute\`, \`none\``)
                        )

                    return message.channel.send({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 })
                }
                if (punishment === 'ban') {
                    let data = await client.db.get(`antiinvite_${message.guild.id}`)
                    data.enabled = data.enabled
                    data.punishment = 'ban'
                    await client.db.set(`antiinvite_${message.guild.id}`, data)
                    
                    const banContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# Punishment Configured`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`The punishment has been successfully configured.`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Punishment Type**\nBan`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Action Taken**\nAny user violating the rules will be banned from the server.`)
                        )

                    await message.channel.send({ components: [banContainer], flags: MessageFlags.IsComponentsV2 })
                }
                if (punishment === 'kick') {
                    let data = await client.db.get(`antiinvite_${message.guild.id}`)
                    data.enabled = data.enabled
                    data.punishment = 'kick'
                    await client.db.set(`antiinvite_${message.guild.id}`, data)
                    
                    const kickContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# Punishment Configured`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`The punishment has been successfully configured.`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Punishment Type**\nKick`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Action Taken**\nAny user violating the rules will be kicked from the server.`)
                        )

                    await message.channel.send({ components: [kickContainer], flags: MessageFlags.IsComponentsV2 })
                }
                if (punishment === 'mute') {
                    let data = await client.db.get(`antiinvite_${message.guild.id}`)
                    data.enabled = data.enabled
                    data.punishment = 'mute'
                    await client.db.set(`antiinvite_${message.guild.id}`, data)
                    
                    const muteContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# Antiinvite Punishment Configured`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`The antiinvite punishment has been successfully configured.`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Punishment Type**\nMute`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Action Taken**\nAny user caught posting discord links will be muted.`)
                        )

                    await message.channel.send({ components: [muteContainer], flags: MessageFlags.IsComponentsV2 })
                }
                if (punishment === 'none') {
                    let data = await client.db.get(`antiinvite_${message.guild.id}`)
                    data.enabled = data.enabled
                    data.punishment = 'none'
                    await client.db.set(`antiinvite_${message.guild.id}`, data)
                    
                    const noneContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`# Antiinvite Punishment Configured`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`The antiinvite punishment has been successfully configured.`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Punishment Type**\nNone`)
                        )
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Action Taken**\nAny user caught posting discord links his messages will be deleted.`)
                        )

                    await message.channel.send({ components: [noneContainer], flags: MessageFlags.IsComponentsV2 })
                }
                break;
            case 'config':
                let data = await client.db.get(`antiinvite_${message.guild.id}`) || { enabled: null, punishment: null };
                
                const configContainer = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`# Antiinvite Config for ${message.guild.name}`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**Antiinvite Status:** ${data.enabled ? client.emoji.tick : client.emoji.cross}`)
                    )
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**Antiinvite Punishment Type:** ${data.punishment ? data.punishment : "None"}`)
                    )

                await message.channel.send({ components: [configContainer], flags: MessageFlags.IsComponentsV2 });
                break;
            default:
                return message.channel.send({ components: [antiinviteContainer], flags: MessageFlags.IsComponentsV2 })
        }
    }
}
