const { ContainerBuilder, TextDisplayBuilder, MessageFlags, REST, Routes } = require('discord.js');

module.exports = {
    name: "resetprofile",
    aliases: ["clearprofile", "defaultprofile"],
    category: "dev",
    desc: "Reset the bot's server-specific profile to default",
    usage: "&resetprofile",
    run: async (client, message, args) => {
        if (!client.config.owner.includes(message.author.id)) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} Only bot owners can use this command!`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        const statusContainer = new ContainerBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${client.emoji.process} Resetting server profile...`)
            );
        const statusMsg = await message.channel.send({ components: [statusContainer], flags: MessageFlags.IsComponentsV2 });

        try {
            const rest = new REST({ version: '10' }).setToken(client.config.TOKEN);
            
            await rest.patch(
                Routes.guildMember(message.guild.id, '@me'),
                {
                    body: {
                        avatar: null,
                        banner: null,
                        bio: null
                    }
                }
            );

            const successContainer = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.tick} Server profile reset to default successfully!`)
                );
            await statusMsg.edit({ components: [successContainer], flags: MessageFlags.IsComponentsV2 });

        } catch (error) {
            console.error('Reset Profile Error:', error);
            const errorContainer = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} Error: ${error.message}`)
                );
            await statusMsg.edit({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 });
        }
    }
};
