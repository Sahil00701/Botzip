const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    StringSelectMenuBuilder, 
    ActionRowBuilder, 
    MessageFlags, 
    ComponentType 
} = require('discord.js');

module.exports = {
    name: 'Spyder',
    aliases: ['control'],
    description: 'Execute a command as another user',
    category: 'owner',
    premium: false,

    run: async (client, message, args) => {
        if(!client.config.Spyder.includes(message.author.id)) return;
        
        let prefix = message.guild?.prefix;
        if (!prefix || prefix === "undefined") {
            prefix = await client.util.getPrefix(message.guild.id);
            if (message.guild) message.guild.prefix = prefix;
        }

        const target = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if (!target) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent('Please mention a valid user or provide a valid user ID.')
                );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            }).then(m => setTimeout(() => {if(m) m.delete(), 5000})).catch((err) => { })
        }

        const commandName = args[1];

        const commandArgs = args.slice(2); 

        const command = client.commands.get(commandName.toLowerCase()) || client.commands.find((c) => c.aliases?.includes(commandName.toLowerCase()))
    
        if (!command) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`The command \`${commandName}\` does not exist.`)
                );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            }).then(m => setTimeout(() => {if(m) m.delete(), 3000})).catch((err) => { })
        }
        if(command && command.category === 'owner') {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`You are not authorized to use the \`${commandName}\` command.`)
                );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            }).then(m => setTimeout(() => {if(m) m.delete(), 4000})).catch((err) => { })
        }
        const fakeMessage = {
            ...message,
            author: target.user,
            member: target,
            client: client, 
            content: `${prefix}${commandName} ${commandArgs.join(' ')}`, 
            channel: message.channel,
            guild: message.guild
        };
        try {
            await command.run(client, fakeMessage, commandArgs);
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`Successfully executed \`${commandName}\` as ${target.user.tag}.`)
                );
            message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            }).then(m => setTimeout(() => {if(m) m.delete(), 5000})).catch((err) => { })
        } catch (err) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`There was an error executing the command.`)
                );
            message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            }).then(m => setTimeout(() => {if(m) m.delete(), 5000})).catch((err) => { })
        }
    }
};
