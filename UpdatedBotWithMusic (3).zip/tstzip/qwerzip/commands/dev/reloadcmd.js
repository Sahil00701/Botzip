const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    StringSelectMenuBuilder, 
    ActionRowBuilder, 
    MessageFlags, 
    ComponentType 
} = require('discord.js');

module.exports = {
    name: 'reload',
    aliases: ['rlcmd'],
    category: 'owner',
    run: async (client, message, args) => {
        if (!client.config.owner.includes(message.author.id)) return
        try {
            let reload = false
            for (let i = 0; i < client.categories.length; i += 1) {
                let dir = client.categories[i]
                try {
                    if (!args[0]) {
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(
                                    `${client.emoji.cross} | You didn't provided the command name.`
                                )
                            );
                        return message.channel.send({ 
                            components: [container],
                            flags: MessageFlags.IsComponentsV2
                        })
                    }
                    delete require.cache[
                        require.resolve(`../../commands/${dir}/${args[0]}.js`)
                    ]
                    client.commands.delete(args[0])
                    const pull = require(`../../commands/${dir}/${args[0]}.js`)
                    client.commands.set(args[0], pull)
                    reload = true
                } catch {}
            }
            if (reload) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `${client.emoji.tick} | Successfully reloaded \`${args[0]}\``
                        )
                    );
                return message.channel.send({ 
                    components: [container],
                    flags: MessageFlags.IsComponentsV2
                })
            }
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `${client.emoji.cross} | I was unable to reload \`${args[0]}\``
                    )
                );
            return message.channel.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            })
        } catch (e) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `${client.emoji.cross} | I was unable to reload \`${args[0]}\``
                    )
                );
            return message.channel.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            })
        }
    }
}
