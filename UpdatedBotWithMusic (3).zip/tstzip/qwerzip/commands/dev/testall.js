const { ContainerBuilder, TextDisplayBuilder, SeparatorBuilder, SeparatorSpacingSize, MessageFlags } = require('discord.js');

module.exports = {
    name: 'testall',
    aliases: ['testcommands', 'cmdtest'],
    category: 'dev',
    cooldown: 120,
    premium: false,
    run: async (client, message, args) => {
        if (!client.config.owner.includes(message.author.id)) {
            return message.channel.send(client.util.createMessage(
                `${client.emoji.cross} | Only bot owners can use this command.`,
                client.color
            ));
        }

        const commandCategories = {
            'Information': [
                'help', 'ping', 'uptime', 'stats', 'invite', 'serverinfo', 'userinfo',
                'avatar', 'banner', 'membercount', 'channelcount', 'boostcount',
                'servericon', 'serverbanner', 'emojilist', 'premium', 'truth', 'dare',
                'wouldyourather', 'cute', 'Intelligence', 'ship'
            ],
            'Voice': [
                'vclist'
            ],
            'Settings Viewers': [
                'list', 'automod', 'antinuke', 'welcome', 'ticket', 'jointocreate'
            ],
            'Dev (Safe)': [
                'serverslist', 'shards', 'Spyder'
            ],
            'Premium': [
                'listpremium'
            ]
        };

        const dangerousCommands = [
            'eval', 'execute', 'ban', 'kick', 'mute', 'nuke', 'purge', 'softban',
            'warn', 'unban', 'unbanall', 'unmute', 'unmuteall', 'lock', 'lockall',
            'unlock', 'unlockall', 'hide', 'hideall', 'unhide', 'unhideall',
            'block', 'unblock', 'addrole', 'nick', 'snipe', 'ignore', 'mediachannel',
            'modrole', 'prefix', 'globalban', 'blacklist', 'blacklistserver',
            'leaveserver', 'maintancemode', 'noprefix', 'reloadcmd', 'testall',
            'afk', 'embed', 'reaction', 'roleicon', 'setboost', 'steal', 'imagine',
            'vcdeafen', 'vcdeafenall', 'vckick', 'vckickall', 'vcmoveall',
            'vcmute', 'vcmuteall', 'vcpull', 'vcpush', 'vcrole', 'vcundeafen',
            'vcundeafenall', 'vcunmute', 'vcunmuteall', 'antiunverifiedbot',
            'extraowner', 'mainrole', 'nightmode', 'panicmode', 'unwhitelist',
            'whitelist', 'whitelisted', 'whitelistreset', 'antiinvite', 'antilink',
            'antispam', 'antiswear', 'addpremium', 'removepremium', 'updatepremium',
            'autorole', 'welcomechannel', 'welcomemessage', 'welcomereset', 'welcometest',
            'setup'
        ];

        let results = {
            total: 0,
            passed: 0,
            failed: 0,
            skipped: 0,
            categoryResults: {},
            errors: []
        };

        for (const category of Object.keys(commandCategories)) {
            results.categoryResults[category] = { passed: 0, failed: 0, total: 0 };
        }

        let totalCommands = Object.values(commandCategories).flat().length;
        let currentIndex = 0;

        const statusMsg = await message.channel.send(client.util.createMessage(
            `🔍 **Comprehensive Command Testing Started**\n\n` +
            `📊 Testing ${totalCommands} safe commands across ${Object.keys(commandCategories).length} categories\n` +
            `⏱️ Delay: 500ms between commands\n` +
            `⚠️ Skipping ${dangerousCommands.length} dangerous commands\n\n` +
            `*Starting tests...*`,
            client.color
        ));

        for (const [category, commands] of Object.entries(commandCategories)) {
            for (const cmdName of commands) {
                currentIndex++;
                const cmd = client.commands.get(cmdName) || client.commands.get(cmdName.toLowerCase());
                
                if (!cmd) {
                    results.skipped++;
                    results.errors.push({
                        command: cmdName,
                        category: category,
                        error: 'Command not found in client.commands'
                    });
                    continue;
                }

                results.total++;
                results.categoryResults[category].total++;

                try {
                    const progressBar = createProgressBar(currentIndex, totalCommands);
                    await statusMsg.edit(client.util.createMessage(
                        `🔍 **Testing Commands**\n\n` +
                        `**Category:** ${category}\n` +
                        `**Command:** \`${cmdName}\`\n\n` +
                        `${progressBar}\n` +
                        `Progress: ${currentIndex}/${totalCommands} (${Math.round(currentIndex/totalCommands*100)}%)\n\n` +
                        `✅ Passed: ${results.passed} | ❌ Failed: ${results.failed} | ⏭️ Skipped: ${results.skipped}`,
                        client.color
                    )).catch(() => {});

                    const timeout = new Promise((_, reject) =>
                        setTimeout(() => reject(new Error('Command timeout (10s)')), 10000)
                    );

                    const cmdRun = cmd.run(client, message, []);

                    await Promise.race([cmdRun, timeout]);
                    results.passed++;
                    results.categoryResults[category].passed++;

                } catch (err) {
                    results.failed++;
                    results.categoryResults[category].failed++;
                    results.errors.push({
                        command: cmdName,
                        category: category,
                        error: err.message || String(err)
                    });
                }

                await new Promise(r => setTimeout(r, 500));
            }
        }

        await statusMsg.edit(client.util.createMessage(
            `✅ **Testing Complete!**\n\n*Generating results...*`,
            client.color
        )).catch(() => {});

        const container = new ContainerBuilder();
        container.setAccentColor(client.color);

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`## 📊 Command Test Results`)
        );

        container.addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        );

        let summaryText = `**Overall Summary**\n\n`;
        summaryText += `✅ **Passed:** ${results.passed}\n`;
        summaryText += `❌ **Failed:** ${results.failed}\n`;
        summaryText += `⏭️ **Skipped:** ${results.skipped}\n`;
        summaryText += `📊 **Total Tested:** ${results.total}\n`;
        summaryText += `🚫 **Dangerous (Not Tested):** ${dangerousCommands.length}\n\n`;
        
        const successRate = results.total > 0 ? Math.round((results.passed / results.total) * 100) : 0;
        summaryText += `**Success Rate:** ${successRate}%`;

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(summaryText)
        );

        container.addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        );

        let categoryText = `**Results by Category**\n\n`;
        for (const [category, data] of Object.entries(results.categoryResults)) {
            if (data.total === 0) continue;
            const catRate = Math.round((data.passed / data.total) * 100);
            const statusEmoji = data.failed === 0 ? '✅' : '⚠️';
            categoryText += `${statusEmoji} **${category}:** ${data.passed}/${data.total} passed (${catRate}%)\n`;
        }

        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(categoryText)
        );

        if (results.errors.length > 0) {
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );

            let errorText = `**❌ Errors Found (${results.errors.length})**\n\n`;
            const maxErrors = 10;
            const displayErrors = results.errors.slice(0, maxErrors);
            
            for (const err of displayErrors) {
                const shortError = err.error.length > 60 ? err.error.substring(0, 60) + '...' : err.error;
                errorText += `**${err.command}** (${err.category})\n\`${shortError}\`\n\n`;
            }

            if (results.errors.length > maxErrors) {
                errorText += `*...and ${results.errors.length - maxErrors} more errors*`;
            }

            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(errorText)
            );
        } else {
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`🎉 **All tested commands passed without errors!**`)
            );
        }

        container.addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        );
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`*Test completed at ${new Date().toLocaleString()}*`)
        );

        await message.channel.send({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};

function createProgressBar(current, total, length = 20) {
    const progress = Math.round((current / total) * length);
    const empty = length - progress;
    return `[${'█'.repeat(progress)}${'░'.repeat(empty)}]`;
}
