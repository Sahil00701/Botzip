const { ContainerBuilder, TextDisplayBuilder, MessageFlags, REST, Routes } = require('discord.js');
const https = require('https');
const http = require('http');

module.exports = {
    name: "setavatar",
    aliases: ["serveravatar", "botavatar"],
    category: "dev",
    desc: "Set the bot's server-specific avatar",
    usage: "&setavatar <image_url>",
    run: async (client, message, args) => {
        if (!client.config.owner.includes(message.author.id)) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} Only bot owners can use this command!`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        if (!args[0]) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} **Usage:** \`&setavatar <image_url>\`\n\n**Example:** \`&setavatar https://i.imgur.com/avatar.png\``)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        const imageUrl = args[0];

        if (!imageUrl.startsWith('http://') && !imageUrl.startsWith('https://')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} Please provide a valid image URL!`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        const statusContainer = new ContainerBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${client.emoji.process} Updating server avatar...`)
            );
        const statusMsg = await message.channel.send({ components: [statusContainer], flags: MessageFlags.IsComponentsV2 });

        try {
            const avatarData = await downloadAndEncodeImage(imageUrl);

            if (!avatarData) {
                const errorContainer = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${client.emoji.cross} Failed to download image. Check the URL and try again.`)
                    );
                return statusMsg.edit({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 });
            }

            const rest = new REST({ version: '10' }).setToken(client.config.TOKEN);
            
            await rest.patch(
                Routes.guildMember(message.guild.id, '@me'),
                {
                    body: {
                        avatar: avatarData
                    }
                }
            );

            const successContainer = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.tick} Server avatar updated successfully!`)
                );
            await statusMsg.edit({ components: [successContainer], flags: MessageFlags.IsComponentsV2 });

        } catch (error) {
            console.error('Set Avatar Error:', error);
            const errorContainer = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} Error: ${error.message}`)
                );
            await statusMsg.edit({ components: [errorContainer], flags: MessageFlags.IsComponentsV2 });
        }
    }
};

function downloadAndEncodeImage(url) {
    return new Promise((resolve) => {
        const protocol = url.startsWith('https') ? https : http;
        
        protocol.get(url, (response) => {
            if (response.statusCode !== 200) {
                resolve(null);
                return;
            }

            const chunks = [];

            response.on('data', (chunk) => {
                chunks.push(chunk);
            });

            response.on('end', () => {
                try {
                    const buffer = Buffer.concat(chunks);
                    const base64 = buffer.toString('base64');
                    const ext = url.split('.').pop().split('?')[0].toLowerCase();
                    const mimeTypes = {
                        'png': 'image/png',
                        'jpg': 'image/jpeg',
                        'jpeg': 'image/jpeg',
                        'gif': 'image/gif',
                        'webp': 'image/webp'
                    };
                    const mimeType = mimeTypes[ext] || 'image/png';
                    const dataUri = `data:${mimeType};base64,${base64}`;
                    resolve(dataUri);
                } catch (error) {
                    resolve(null);
                }
            });

        }).on('error', () => {
            resolve(null);
        });
    });
}
