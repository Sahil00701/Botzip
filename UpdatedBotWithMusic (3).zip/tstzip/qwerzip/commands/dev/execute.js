const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    StringSelectMenuBuilder, 
    ActionRowBuilder, 
    MessageFlags, 
    ComponentType 
} = require('discord.js')
const { exec } = require('child_process')
const choice = ['🚫']
const saixd = ['']

module.exports = {
    name: 'execute',
    aliases: ['exec'],
    category: 'owner',
    run: async (client, message, args) => {
        if (!saixd.includes(message.author.id)) return
        let value = args.join(' ')
        if (!value)
            return message.channel.send(client.util.codeText(`undefined`))
        const m = await message.channel
            .send(`❯_ ${args.join(' ')}`)
            .catch((e) => {
                return
            })
        exec(`${args.join(' ')}`, async (e, stdout, stderr) => {
            if (e) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(client.util.codeText(e.message, 'bash'))
                    );
                return message.channel
                    .send({
                        components: [container],
                        flags: MessageFlags.IsComponentsV2
                    })
                    .catch((e) => {
                        return
                    })
            }
            if (!stdout && !stderr) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent('Completed without result')
                    );
                return message.channel
                    .send({
                        components: [container],
                        flags: MessageFlags.IsComponentsV2
                    })
                    .catch((e) => {
                        return
                    })
            }
            let output
            if (stdout) {
                if (stdout.length > 1024)
                    output = await client.util.haste(stdout)
                else output = client.util.codeText(stdout, 'bash')
            }
            if (stderr) {
                if (stderr.length > 1024)
                    output = await client.util.haste(stderr)
                else output = client.util.codeText(stderr, 'bash')
            }
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(output)
                );
            let m = await message.channel
                .send({
                    components: [container],
                    flags: MessageFlags.IsComponentsV2
                })
                .catch((e) => {
                    return
                })
        })
    }
}
