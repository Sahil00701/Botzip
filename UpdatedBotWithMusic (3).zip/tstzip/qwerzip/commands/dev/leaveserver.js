const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    StringSelectMenuBuilder, 
    ActionRowBuilder, 
    MessageFlags, 
    ComponentType 
} = require('discord.js')
this.config = require(`${process.cwd()}/config.json`)
module.exports = {
    name: `leaveserver`,
    category: `owner`,
    aliases: [`leaveg`, `gleave`],
    description: `Leaves A Guild`,
    run: async (client, message, args) => {
        if (!this.config.admin.includes(message.author.id)) return
        let id = args[0]
        if (!id) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `${client.emoji.cross} | You didn't provided the server Id.`
                    )
                );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            })
        }
        let guild = await client.guilds.fetch(id)
        let name = guild?.name || 'No Name Found'
        if (!guild) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `${client.emoji.cross} | You didn't provided a valid server Id.`
                    )
                );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            })
        }
        await guild.leave()
        const container = new ContainerBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.tick} | Successfully left **${name} (${id})**.`
                )
            );
        return message.channel.send({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        })
    }
}
