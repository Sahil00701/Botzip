const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    StringSelectMenuBuilder, 
    ActionRowBuilder, 
    MessageFlags, 
    ComponentType 
} = require('discord.js');
const config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'shards',
    aliases: ['cluster', 'clusters'],
    category: 'owner',
    run: async (client, message, args) => {
        if (!client.config.owner.includes(message.author.id)) return;

        const shardInfo = await client.cluster.broadcastEval((client) => {
            const cpuUsage = process.cpuUsage();
            const cpuPercent = ((cpuUsage.user + cpuUsage.system) / (process.uptime() * 1e6)) * 100;
            const uptime = Date.now() - process.uptime() * 1000;

            return {
                id: client.cluster.id,
                shardId: client.cluster.ids[0],
                latency: client.ws.ping,
                uptime,
                ram: process.memoryUsage().rss / 1024 / 1024,
                cpu: cpuPercent,
                servers: client.guilds.cache.size,
                members: client.guilds.cache.reduce((acc, guild) => acc + guild.memberCount, 0),
            };
        });

        let currentIndex = 0;
        const clustersPerPage = 3;

        const createContainer = (pageIndex) => {
            const start = pageIndex * clustersPerPage;
            const end = start + clustersPerPage;
            const pageClusters = shardInfo.slice(start, end);

            const container = new ContainerBuilder();
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**Cluster Status (Page ${pageIndex + 1}/${Math.ceil(shardInfo.length / clustersPerPage)})**`)
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
            );

            pageClusters.forEach(shard => {
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `**Cluster [${shard.id}] Status:**\n` +
                        `**Latency:** ${shard.latency}ms\n` +
                        `**Uptime:** <t:${Math.floor(shard.uptime / 1000)}:R>\n` +
                        `**RAM:** ${Math.round(shard.ram)} MB\n` +
                        `**CPU:** ${shard.cpu.toFixed(2)}%\n` +
                        `**Servers:** ${shard.servers}\n` +
                        `**Members:** ${shard.members.toLocaleString()}`
                    )
                );
                container.addSeparatorComponents(
                    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
                );
            });

            return container;
        };

        const createSelectMenu = () => {
            const options = [];
            const totalPages = Math.ceil(shardInfo.length / clustersPerPage);
            for (let i = 0; i < totalPages; i++) {
                options.push({
                    label: `Page ${i + 1}`,
                    value: `page_${i}`,
                    default: i === currentIndex
                });
            }
            return new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('shard_page_select')
                    .setPlaceholder('Select a page')
                    .addOptions(options)
            );
        };

        const messageEmbed = await message.channel.send({
            components: [createContainer(currentIndex), createSelectMenu()],
            flags: MessageFlags.IsComponentsV2
        });

        const filter = (i) => i.user.id === message.author.id;
        const collector = messageEmbed.createMessageComponentCollector({ filter, time: 60000, componentType: ComponentType.StringSelect });

        collector.on('collect', async (interaction) => {
            const selectedPage = parseInt(interaction.values[0].split('_')[1]);
            currentIndex = selectedPage;

            await interaction.update({
                components: [createContainer(currentIndex), createSelectMenu()],
                flags: MessageFlags.IsComponentsV2
            });
        });

        collector.on('end', async () => {
            await messageEmbed.edit({
                components: [createContainer(currentIndex)],
                flags: MessageFlags.IsComponentsV2
            });
        });
    }
};
