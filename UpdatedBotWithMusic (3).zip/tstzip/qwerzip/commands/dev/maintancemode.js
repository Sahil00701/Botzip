const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    StringSelectMenuBuilder, 
    ActionRowBuilder, 
    MessageFlags, 
    ComponentType 
} = require('discord.js');

module.exports = {
    name: 'maintanance',
    aliases: ['main'],
    category: 'owner',
    run: async (client, message, args) => {
        if (!client.config.owner.includes(message.author.id)) return;
        if (!args[0]) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent("Please provide arguments like `&maintanance enable/disable`")
                );
            return message.channel.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }
        let maintain = await client.db.get(`maintanance_${client.user.id}`)
        
        if (args[0].toLowerCase() == "enable") {
            if (!maintain) {
                await client.db.set(`maintanance_${client.user.id}`,true)
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent("Maintenance mode is successfully enabled!")
                    );
                return message.channel.send({ 
                    components: [container],
                    flags: MessageFlags.IsComponentsV2
                });
            } else {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent("Maintenance mode is already enabled!")
                    );
                return message.channel.send({ 
                    components: [container],
                    flags: MessageFlags.IsComponentsV2
                });
            }
        } else if (args[0].toLowerCase() == "disable") {
            if (maintain) {
                await client.db.set(`maintanance_${client.user.id}`,false)
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent("Maintenance mode is successfully disabled!")
                    );
                return message.channel.send({ 
                    components: [container],
                    flags: MessageFlags.IsComponentsV2
                });
            }
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent("Maintenance mode is not enabled yet!")
                );
            return message.channel.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        } else {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent("Please give valid arguments like `&maintanance enable/disable`")
                );
            return message.channel.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }
    }
}
