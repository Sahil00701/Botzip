const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    StringSelectMenuBuilder, 
    ActionRowBuilder, 
    MessageFlags, 
    ComponentType 
} = require('discord.js')
this.config = require(`${process.cwd()}/config.json`)
module.exports = {
    name: 'blacklistserver',
    aliases: ['bs'],
    category: 'owner',
    run: async (client, message, args) => {
        if (!this.config.admin.includes(message.author.id)) return
        let prefix = message.guild.prefix
        if (!args[0]) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `Please provide the required arguments.\n${prefix}blacklistserver \`<add/remove/list>\` \`<server id>\``
                    )
                );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            })
        }
        if (args[0].toLowerCase() === `list`) {
            let listing = (await client.db.get(`blacklistserver_${client.user.id}`))
                ? await client.db.get(`blacklistserver_${client.user.id}`)
                : []
            let info = []
            let ss
            if (listing.length < 1) info.push(`No servers ;-;`)
            else {
                for (let i = 0; i < listing.length; i++) {
                    ss = await client.guilds.fetch(listing[i]).catch(() => null);
                    if (ss) {
                        info.push(`${i + 1}) ${ss.name} (${ss.id})`);
                    } else {
                        await client.db.set(`blacklistserver_${client.user.id}`, listing.filter(id => id !== listing[i]));
                    }
                }
            }
            return await client.util.pagination(
                message,
                info,
                '**Blacklist Server List** :-'
            )
        }
        let check = 0
        if (!args[1]) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `Please provide the required arguments.\n${prefix}blacklistserver \`<add/remove/list>\` \`<server id>\``
                    )
                );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            })
        }
        let user = await client.guilds.fetch(`${args[1]}`).catch((er) => {
            check += 1
        })
        if (check == 1 || !user) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `Please provide a valid server ID.\n${prefix}blacklistserver \`<add/remove/list>\` \`<server id>\``
                    )
                );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            })
        }
        let added = (await client.db.get(`blacklistserver_${client.user.id}`))
            ? await client.db.get(`blacklistserver_${client.user.id}`)
            : []

        let opt = args[0].toLowerCase()
        if (opt == `add` || opt == `a` || opt == `+`) {
            added.push(`${user.id}`)
            added = client.util.removeDuplicates2(added)
            await client.db.set(`blacklistserver_${client.user.id}`, added)
            client.util.blacklistserver()
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `${client.emoji.tick} | **${user.name} (${user.id})** has been added as a **Blacklist** server.`
                    )
                );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            })
        }
        if (opt == `remove` || opt == `r` || opt == `-`) {
            if (!added.includes(args[1])) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(
                            `${client.emoji.cross} | **${args[1]}** is not in the blacklist.`
                        )
                    );
                return message.channel.send({
                    components: [container],
                    flags: MessageFlags.IsComponentsV2
                });
            }
            
            added = added.filter((srv) => srv !== args[1]);
            added = client.util.removeDuplicates2(added);
            await client.db.set(`blacklistserver_${client.user.id}`, added);
            client.util.blacklistserver();
        
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `${client.emoji.tick} | **Server ID: ${args[1]}** has been removed from the **Blacklist**.`
                    )
                );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }
        
        const container = new ContainerBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${prefix}blacklistserver \`<add/remove/list>\` \`<user id>\``
                )
            );
        message.channel.send({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        })
    }
}
