const {
    ContainerBuilder,
    TextDisplayBuilder,
    MessageFlags
} = require('discord.js');

module.exports = {
    name: 'skip',
    aliases: ['sk', 'next'],
    category: 'music',
    premium: true,
    run: async (client, message, args) => {
        // Premium check
        const isPremium = await client.util.CheckPremium(message.guild);
        if (!isPremium) {
            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | This is a **Premium-Only** feature.\n\n` +
                    `Upgrade your server to access music commands!`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        // Check if user is in voice channel
        if (!message.member.voice.channel) {
            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | You must be in a voice channel to use this command.`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        // Check if music manager exists
        if (!client.music) {
            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | Nothing is playing right now.`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        const state = client.music.get(message.guild.id);
        if (!state || !state.player) {
            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | Nothing is playing right now.`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        try {
            const currentTrack = state.current;
            await client.music.skip(message.guild.id);

            const container = new ContainerBuilder();
            container.setAccentColor(client.color);

            if (state.queue.length > 0) {
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `${client.emoji.tick} | Skipped **[${currentTrack?.info?.title || 'Track'}]**\n\n` +
                        `Now playing: **[${state.queue[0]?.info?.title || 'Next Track'}]**`
                    )
                );
            } else {
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `${client.emoji.tick} | Skipped **[${currentTrack?.info?.title || 'Track'}]**\n\n` +
                        `Queue is now empty.`
                    )
                );
            }

            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        } catch (error) {
            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | Error skipping track: ${error.message}`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }
    }
};
