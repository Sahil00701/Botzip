const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags
} = require('discord.js');

module.exports = {
    name: 'play',
    aliases: ['p'],
    category: 'music',
    premium: true,
    run: async (client, message, args) => {
        // Premium check
        const isPremium = await client.util.CheckPremium(message.guild);
        if (!isPremium) {
            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | This is a **Premium-Only** feature.\n\n` +
                    `Upgrade your server to access music commands!\n\n` +
                    `**Premium Benefits:**\n` +
                    `• Full Music Access\n` +
                    `• Advanced Moderation\n` +
                    `• Custom Welcome Messages\n` +
                    `• And much more...`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        // Check if args provided
        if (!args.length) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | Please provide a song name or URL.\n\n` +
                    `**Usage:** \`play <song name or URL>\``
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        // Check if user is in voice channel
        const voice = message.member.voice.channel;
        if (!voice) {
            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | You must be in a voice channel to play music.`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        // Check bot permissions
        const me = message.guild.members.me;
        const perms = voice.permissionsFor(me);
        if (!perms.has('Connect') || !perms.has('Speak')) {
            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | I need **Connect** and **Speak** permissions in your voice channel.`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        // Initialize music manager if not exists
        if (!client.music) {
            const { MusicManager } = require('../music/manager');
            client.music = new MusicManager(client, {
                host: process.env.LAVALINK_HOST,
                port: parseInt(process.env.LAVALINK_PORT),
                password: process.env.LAVALINK_PASSWORD,
                secure: process.env.LAVALINK_SECURE === "true"
            });
        }

        // Get or create player state
        let state = client.music.get(message.guild.id);

        // If already playing in different voice channel
        if (state && state.voiceChannelId && state.voiceChannelId !== voice.id) {
            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | I'm already playing music in a different voice channel.\n\n` +
                    `Join <#${state.voiceChannelId}> to control playback.`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        const query = args.join(' ');
        const shardId = message.guild.shardId || 0;

        try {
            // Create player if not exists
            if (!state) {
                state = await client.music.create(
                    message.guild.id,
                    voice.id,
                    message.channel.id,
                    shardId,
                    message.author.id
                );
            }

            // Search for tracks
            const result = await client.music.search(query, message.guild.id);

            if (!result || !result.tracks || result.tracks.length === 0) {
                const container = new ContainerBuilder();
                container.setAccentColor(0xff0000);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `${client.emoji.cross} | No results found for: \`${query}\``
                    )
                );
                return message.channel.send({
                    components: [container],
                    flags: MessageFlags.IsComponentsV2
                });
            }

            // Add tracks to queue
            const tracks = result.tracks.slice(0, result.loadType === 'playlist' ? result.tracks.length : 1);

            tracks.forEach(track => {
                track.requesterId = message.author.id;
            });

            const added = await client.music.enqueue(message.guild.id, tracks);

            // If nothing was playing, start playback
            if (!state.current) {
                await client.music.play(message.guild.id);
            }

            // Send success message
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);

            if (result.loadType === 'playlist') {
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `${client.emoji.tick} | Added **${tracks.length}** tracks from playlist to queue.`
                    )
                );
            } else {
                const track = tracks[0];
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `${client.emoji.tick} | Added to queue: **[${track.info.title}](${track.info.uri})**`
                    )
                );
            }

            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `*Queue: ${client.music.get(message.guild.id)?.queue.length || 0} tracks*`
                )
            );

            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });

        } catch (error) {
            console.error('[Play Command Error]', error);

            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | Error playing music: ${error.message}`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }
    }
};
