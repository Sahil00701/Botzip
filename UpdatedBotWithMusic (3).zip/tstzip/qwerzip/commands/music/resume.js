const {
    ContainerBuilder,
    TextDisplayBuilder,
    MessageFlags
} = require('discord.js');

module.exports = {
    name: 'resume',
    aliases: ['res'],
    category: 'music',
    premium: true,
    run: async (client, message, args) => {
        // Premium check
        const isPremium = await client.util.CheckPremium(message.guild);
        if (!isPremium) {
            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | This is a **Premium-Only** feature.\n\n` +
                    `Upgrade your server to access music commands!`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        // Check if user is in voice channel
        if (!message.member.voice.channel) {
            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | You must be in a voice channel to use this command.`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        // Check if music manager exists
        if (!client.music) {
            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | Nothing is playing right now.`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        const state = client.music.get(message.guild.id);
        if (!state || !state.player) {
            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | Nothing is playing right now.`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        try {
            await client.music.resume(message.guild.id);

            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.tick} | Music has been **resumed**.\n\n` +
                    `Use \`pause\` to pause again.`
                )
            );

            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        } catch (error) {
            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | Error resuming music: ${error.message}`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }
    }
};
