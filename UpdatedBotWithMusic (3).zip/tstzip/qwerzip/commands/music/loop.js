const {
    ContainerBuilder,
    TextDisplayBuilder,
    MessageFlags
} = require('discord.js');

module.exports = {
    name: 'loop',
    aliases: ['repeat'],
    category: 'music',
    premium: true,
    run: async (client, message, args) => {
        // Premium check
        const isPremium = await client.util.CheckPremium(message.guild);
        if (!isPremium) {
            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | This is a **Premium-Only** feature.\n\n` +
                    `Upgrade your server to access music commands!`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        // Check if user is in voice channel
        if (!message.member.voice.channel) {
            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | You must be in a voice channel to use this command.`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        // Check if music manager exists
        if (!client.music) {
            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | Nothing is playing right now.`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        const state = client.music.get(message.guild.id);
        if (!state || !state.player) {
            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | Nothing is playing right now.`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        // Toggle loop mode
        const mode = args[0]?.toLowerCase();
        let newMode;

        if (mode === 'track' || mode === 'song') {
            newMode = 'track';
        } else if (mode === 'queue' || mode === 'all') {
            newMode = 'queue';
        } else if (mode === 'off' || mode === 'none') {
            newMode = 'off';
        } else {
            // Toggle current mode
            if (state.repeat === 'off') {
                newMode = 'track';
            } else if (state.repeat === 'track') {
                newMode = 'queue';
            } else {
                newMode = 'off';
            }
        }

        state.repeat = newMode;

        const modeText = {
            'off': 'Loop is now **disabled**',
            'track': 'Looping **current track**',
            'queue': 'Looping **entire queue**'
        };

        const container = new ContainerBuilder();
        container.setAccentColor(client.color);
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `${client.emoji.tick} | ${modeText[newMode]}\n\n` +
                `**Loop Modes:**\n` +
                `• \`loop\` - Toggle between off/track/queue\n` +
                `• \`loop track\` - Loop current track\n` +
                `• \`loop queue\` - Loop entire queue\n` +
                `• \`loop off\` - Disable loop`
            )
        );

        return message.channel.send({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};
