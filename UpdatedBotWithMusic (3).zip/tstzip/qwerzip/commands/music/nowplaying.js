const {
    ContainerBuilder,
    TextDisplayBuilder,
    MessageFlags
} = require('discord.js');

module.exports = {
    name: 'nowplaying',
    aliases: ['np', 'playing'],
    category: 'music',
    premium: true,
    run: async (client, message, args) => {
        // Premium check
        const isPremium = await client.util.CheckPremium(message.guild);
        if (!isPremium) {
            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | This is a **Premium-Only** feature.\n\n` +
                    `Upgrade your server to access music commands!`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        // Check if music manager exists
        if (!client.music) {
            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | Nothing is playing right now.`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        const state = client.music.get(message.guild.id);
        if (!state || !state.current) {
            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | Nothing is playing right now.`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        const track = state.current;
        const title = track.info.title;
        const uri = track.info.uri;
        const author = track.info.author || 'Unknown';
        const duration = formatDuration(track.info.length);
        const requester = track.requesterId ? `<@${track.requesterId}>` : 'Unknown';

        // Create progress bar
        const progress = state.player?.track?.position || 0;
        const total = track.info.length;
        const progressPercent = Math.floor((progress / total) * 20);
        const progressBar = '▬'.repeat(progressPercent) + '🔘' + '▬'.repeat(20 - progressPercent);
        const progressTime = formatDuration(progress);

        const container = new ContainerBuilder();
        container.setAccentColor(client.color);
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `**Now Playing** ${client.emoji.tick}\n\n` +
                `[${title}](${uri})\n\n` +
                `**Progress:**\n` +
                `${progressBar}\n` +
                `${progressTime} / ${duration}\n\n` +
                `**Author:** ${author}\n` +
                `**Requested by:** ${requester}\n` +
                `**Volume:** ${state.volume}%`
            )
        );

        return message.channel.send({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};

function formatDuration(ms) {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);

    if (hours > 0) {
        return `${hours}:${String(minutes % 60).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
    }
    return `${minutes}:${String(seconds % 60).padStart(2, '0')}`;
}
