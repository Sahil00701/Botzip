const {
    ContainerBuilder,
    TextDisplayBuilder,
    MessageFlags
} = require('discord.js');

module.exports = {
    name: 'queue',
    aliases: ['q', 'list'],
    category: 'music',
    premium: true,
    run: async (client, message, args) => {
        // Premium check
        const isPremium = await client.util.CheckPremium(message.guild);
        if (!isPremium) {
            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | This is a **Premium-Only** feature.\n\n` +
                    `Upgrade your server to access music commands!`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        // Check if music manager exists
        if (!client.music) {
            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | Nothing is playing right now.`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        const state = client.music.get(message.guild.id);
        if (!state) {
            const container = new ContainerBuilder();
            container.setAccentColor(0xff0000);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.cross} | Nothing is playing right now.`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        // If queue is empty
        if (state.queue.length === 0 && !state.current) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `${client.emoji.dot} | The queue is empty.\n\n` +
                    `Use \`play <song>\` to add songs to the queue.`
                )
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        // Build queue display
        let queueText = '';

        // Add current track
        if (state.current) {
            const current = state.current;
            queueText += `**Now Playing:** [${current.info.title}](${current.info.uri})\n`;
            queueText += `> Author: ${current.info.author || 'Unknown'} | Duration: ${formatDuration(current.info.length)}\n\n`;
        }

        // Add upcoming tracks
        if (state.queue.length > 0) {
            queueText += `**Up Next:**\n`;
            state.queue.slice(0, 10).forEach((track, index) => {
                queueText += `${index + 1}. [${track.info.title}](${track.info.uri}) - ${formatDuration(track.info.length)}\n`;
            });

            if (state.queue.length > 10) {
                queueText += `\n*...and ${state.queue.length - 10} more tracks*`;
            }
        }

        const container = new ContainerBuilder();
        container.setAccentColor(client.color);
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `**Music Queue** ${client.emoji.tick}\n\n${queueText}`
            )
        );
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `*Total: ${state.queue.length} tracks in queue*`
            )
        );

        return message.channel.send({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};

function formatDuration(ms) {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);

    if (hours > 0) {
        return `${hours}:${String(minutes % 60).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
    }
    return `${minutes}:${String(seconds % 60).padStart(2, '0')}`;
}
