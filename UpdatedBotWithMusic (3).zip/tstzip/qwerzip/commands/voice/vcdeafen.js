const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags
} = require('discord.js')

module.exports = {
    name: 'vcdeafen',
    aliases: ['vcdeaf'],
    category: 'voice',
    run: async (client, message, args) => {
        if (!message.member.permissions.has('DeafenMembers')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`You must have \`Deafen members\` permission to use this command.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
        }
        if (!message.guild.members.me.permissions.has('DeafenMembers')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`I must have \`Deafen members\` permission to use this command.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
        }
        if (!message.member.voice.channel) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`You must be connected to a voice channel first.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
        }
        let member1 =
            message.mentions.members.first() ||
            message.guild.members.cache.get(args[0])
        if (!member1) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`You must mention someone whom you want to deafen in your vc.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
        }
        let member =
            message.mentions.members.first() ||
            message.guild.members.cache.get(args[0])
        if (!member.voice.channel) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`<@${member.user.id}> is not in your vc.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
        }
        try {
            member.voice.setDeaf(
                true,
                `${message.author.tag} (${message.author.id})`
            )
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.tick} | Successfully deafened <@${member.user.id}> From Voice!`)
                )
            message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
        } catch (err) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`I was unable to voice deafen <@${member.user.id}>.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
        }
    }
}
