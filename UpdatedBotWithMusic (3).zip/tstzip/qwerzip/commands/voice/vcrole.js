const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    StringSelectMenuBuilder,
    ActionRowBuilder,
    MessageFlags,
    ComponentType
} = require('discord.js')

module.exports = {
    name: 'vcrole',
    aliases: ['invcrole'],
    category: 'voice',
    premium: false,
    run: async (client, message, args) => {
        if (!message.member.permissions.has('Administrator')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`You must have \`Administration\` perms to run this command.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
        }
        const invcContainer = new ContainerBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**${message.author.tag}**`)
            )
            .addSeparatorComponents(
                new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`\`vcrole\` - **Shows the current page.**\n\`vcrole humans set <role>\` - **set role to vcrole human configuration.**\n\`vcrole bot set <role>\` - **set role to vcrole bot configuration.**\n\`vcrole view \` - **view vcrole configuration.**\n\`vcrole reset\` - **reset vcrole configuration**`)
            )
            .addSeparatorComponents(
                new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`Note: At the time of providing Vc-Role when someone joins the vc, I'll ignore the role if its having Dangerous Perms.`)
            )
        let option = args[0]
        if (!option) {
            message.channel.send({ components: [invcContainer], flags: MessageFlags.IsComponentsV2 })
        } else if (option === 'humans' || option === 'humans') {
            if (!args[1]) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**${message.author.tag}**`)
                    )
                    .addSeparatorComponents(
                        new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
                    )
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`Please provide valid role arguments: \`set\`.`)
                    )
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
            }
            if (
                args[1].toLowerCase() === 'set' ||
                args[1].toLowerCase() === 'sets' ||
                args[1].toLowerCase() === 'add'
            ) {
                await client.db
                    .get(`vcroles_${message.guild.id}`)
                    .then(async (data) => {
                        let role =
                            getRoleFromMention(message, args[2]) ||
                            message.guild.roles.cache.get(args[2])
                        if (!data) {
                            await client.db.set(`vcroles_${message.guild.id}`, {
                                vcrole: null,
                                vcrolebot: null
                            })
                            const container = new ContainerBuilder()
                                .addTextDisplayComponents(
                                    new TextDisplayBuilder().setContent(`Please wait, setting up configuration for your server.`)
                                )
                            let msg = await message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
                            await client.util.sleep(2000)
                            const successContainer = new ContainerBuilder()
                                .addTextDisplayComponents(
                                    new TextDisplayBuilder().setContent(`Great news! Your server is now configured perfectly. Feel free to use vcrole module and enjoy using your server hassle-free! 🚀`)
                                )
                            return await msg.edit({ components: [successContainer], flags: MessageFlags.IsComponentsV2 })
                        }
                        if (role) {
                            if (
                                role &&
                                !role.permissions.has(
                                    'Administrator',
                                    'KICK_MEMBERS',
                                    'BanMembers',
                                    'MANAGE_CHANNELS',
                                    'ManageGuild',
                                    'MENTION_EVERYONE',
                                    'ManageRoles',
                                    'ManageWebhooks'
                                )
                            ) {
                                await client.db.set(
                                    `vcroles_${message.guild.id}`,
                                    {
                                        vcrole: role.id,
                                        vcrolebot: data ? data.vcrolebot : null
                                    }
                                )
                                const container = new ContainerBuilder()
                                    .addTextDisplayComponents(
                                        new TextDisplayBuilder().setContent(`${client.emoji.tick} | successfully added ${role} as vcrole human.!`)
                                    )
                                message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
                            } else {
                                const container = new ContainerBuilder()
                                    .addTextDisplayComponents(
                                        new TextDisplayBuilder().setContent(`${client.emoji.cross} | this role is having dangerous permissions.!`)
                                    )
                                message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
                            }
                        }
                        if (!role) {
                            const container = new ContainerBuilder()
                                .addTextDisplayComponents(
                                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | please provide a valid role mention or id to set as vcrole!`)
                                )
                            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
                        }
                        if (
                            role.position >=
                            message.guild.me.roles.highest.position
                        ) {
                            const container = new ContainerBuilder()
                                .addTextDisplayComponents(
                                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | I can't provide this role as my highest role is either below or equal to the provided role.`)
                                )
                            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
                        }
                        if (role.managed) {
                            const container = new ContainerBuilder()
                                .addTextDisplayComponents(
                                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | you cannot add any integrated role in My vcrole.! `)
                                )
                            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
                        }
                    })
            }
        } else if (option === 'bot' || option === 'bots') {
            if (!args[1]) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**${message.author.tag}**`)
                    )
                    .addSeparatorComponents(
                        new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
                    )
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`Please provide valid role arguments: \`set\`.`)
                    )
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
            }
            if (
                args[1].toLowerCase() === 'set' ||
                args[1].toLowerCase() === 'sets' ||
                args[1].toLowerCase() === 'add'
            ) {
                await client.db
                    .get(`vcroles_${message.guild.id}`)
                    .then(async (data) => {
                        let role =
                            getRoleFromMention(message, args[2]) ||
                            message.guild.roles.cache.get(args[2])
                        if (!data) {
                            await client.db.set(`vcroles_${message.guild.id}`, {
                                vcrole: null,
                                vcrolebot: null
                            })
                            const container = new ContainerBuilder()
                                .addTextDisplayComponents(
                                    new TextDisplayBuilder().setContent(`Please wait, setting up configuration for your server.`)
                                )
                            let msg = await message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
                            await client.util.sleep(2000)
                            const successContainer = new ContainerBuilder()
                                .addTextDisplayComponents(
                                    new TextDisplayBuilder().setContent(`Great news! Your server is now configured perfectly. Feel free to use vcrole module and enjoy using your server hassle-free! 🚀`)
                                )
                            return await msg.edit({ components: [successContainer], flags: MessageFlags.IsComponentsV2 })
                        }
                        if (role) {
                            if (
                                role &&
                                !role.permissions.has(
                                    'Administrator',
                                    'KICK_MEMBERS',
                                    'BanMembers',
                                    'MANAGE_CHANNELS',
                                    'ManageGuild',
                                    'MENTION_EVERYONE',
                                    'ManageRoles',
                                    'ManageWebhooks'
                                )
                            ) {
                                await client.db.set(
                                    `vcroles_${message.guild.id}`,
                                    {
                                        vcrole: data ? data.vcrole : null,
                                        vcrolebot: role.id
                                    }
                                )
                                const container = new ContainerBuilder()
                                    .addTextDisplayComponents(
                                        new TextDisplayBuilder().setContent(`${client.emoji.tick} | successfully added ${role} as vcrole bot.!`)
                                    )
                                message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
                            } else {
                                const container = new ContainerBuilder()
                                    .addTextDisplayComponents(
                                        new TextDisplayBuilder().setContent(`${client.emoji.cross} | this role is having dangerous permissions.!`)
                                    )
                                message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
                            }
                        }
                        if (!role) {
                            const container = new ContainerBuilder()
                                .addTextDisplayComponents(
                                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | please provide a valid role mention or id to set as vcrole!`)
                                )
                            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
                        }
                        if (
                            role.position >=
                            message.guild.me.roles.highest.position
                        ) {
                            const container = new ContainerBuilder()
                                .addTextDisplayComponents(
                                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | I can't provide this role as my highest role is either below or equal to the provided role.`)
                                )
                            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
                        }
                        if (role.managed) {
                            const container = new ContainerBuilder()
                                .addTextDisplayComponents(
                                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | you cannot add any integrated role in My vcrole.! `)
                                )
                            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
                        }
                    })
            }
        } else if (
            option === 'show' ||
            option === 'view' ||
            option === 'config'
        ) {
            await client.db
                .get(`vcroles_${message.guild.id}`)
                .then(async (data) => {
                    if (!data) {
                        await client.db.set(`vcroles_${message.guild.id}`, {
                            vcrole: null,
                            vcrolebot: null
                        })
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`Please wait, setting up configuration for your server.`)
                            )
                        let msg = await message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
                        await client.util.sleep(2000)
                        const successContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`Great news! Your server is now configured perfectly. Feel free to use vcrole module and enjoy using your server hassle-free! 🚀`)
                            )
                        return await msg.edit({ components: [successContainer], flags: MessageFlags.IsComponentsV2 })
                    }
                    if (!data.vcrole && !data.vcrolebot) {
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | No vcrole is configured.!`)
                            )
                        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
                    } else {
                        let configText = `**Vc role Configuration**\n\n`
                        if (data.vcrole) {
                            configText += `**Vc Role Human:** <@&${data.vcrole}>\n`
                        } else {
                            configText += `**Vc Role Human:** \`NOT SET\`\n`
                        }
                        if (data.vcrolebot) {
                            configText += `**Vc Role Bot:** <@&${data.vcrolebot}>`
                        } else {
                            configText += `**Vc Role Bot:** \`NOT SET\``
                        }
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`**${message.author.tag}**`)
                            )
                            .addSeparatorComponents(
                                new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
                            )
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(configText)
                            )
                        await message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
                    }
                })
        } else if (option === 'reset') {
            await client.db
                .get(`vcroles_${message.guild.id}`)
                .then(async (data) => {
                    if (!data) {
                        await client.db.set(`vcroles_${message.guild.id}`, {
                            vcrole: null,
                            vcrolebot: null
                        })
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`Please wait, setting up configuration for your server.`)
                            )
                        let msg = await message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
                        await client.util.sleep(2000)
                        const successContainer = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`Great news! Your server is now configured perfectly. Feel free to use vcrole module and enjoy using your server hassle-free! 🚀`)
                            )
                        return await msg.edit({ components: [successContainer], flags: MessageFlags.IsComponentsV2 })
                    }
                    if (!data.vcrole && !data.vcrolebot) {
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.cross} | there is no vcrole in this server.!`)
                            )
                        message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
                    } else if (
                        data
                            ? data.vcrole
                            : null && data
                              ? data.vcrolebot
                              : null
                    ) {
                        await client.db.set(`vcroles_${message.guild.id}`, {
                            vcrole: null,
                            vcrolebot: null
                        })
                        const container = new ContainerBuilder()
                            .addTextDisplayComponents(
                                new TextDisplayBuilder().setContent(`${client.emoji.tick} | successfully disabled vcrole configuration.!`)
                            )
                        message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
                    }
                })
        }
    }
}

function getRoleFromMention(message, mention) {
    if (!mention) return null
    const matches = mention.match(/^<@&?(\d+)>$/)
    if (!matches) return null
    const id = matches[1]
    return message.guild.roles.cache.get(id)
}
