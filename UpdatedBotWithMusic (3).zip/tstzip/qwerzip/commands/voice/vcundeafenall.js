const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags
} = require('discord.js');

module.exports = {
    name: 'vcundeafenall',
    category: 'voice',
    run: async (client, message, args) => {

        if (!message.member.permissions.has('DeafenMembers')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`You must have \`Deafen members\` permission to use this command.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        if (!message.guild.members.me.permissions.has('DeafenMembers')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`I must have \`Deafen members\` permission to use this command.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        if (!message.member.voice.channel) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`You must be connected to a voice channel first.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        let own = message.author.id == message.guild.ownerId
        if (
            !own &&
            message.member.roles.highest.position <=
                message.guild.members.me.roles.highest.position
        ) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have a higher role than me to use this command.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
        }
        try {
            let i = 0;
            message.member.voice.channel.members.forEach(async (member) => {
                i++;
                await member.voice.setDeaf(false,`${message.author.tag} | ${message.author.id}`);
                await client.util.sleep(1000);
            });
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.tick} | Successfully Undeafened ${i} Members in ${message.member.voice.channel}!`)
                )
            message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        } catch (err) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`I don't have the required permissions to undeafen members.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
    }
};
