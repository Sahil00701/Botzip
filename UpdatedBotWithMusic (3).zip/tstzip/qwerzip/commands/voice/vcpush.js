const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags,
    ChannelType,
    PermissionsBitField
} = require('discord.js');

module.exports = {
    name: 'vcpush',
    category: 'voice',
    run: async (client, message, args) => {
        const roastingLines = [
            "Next time, try reading the rules, genius.",
            "Permission denied. Better luck next time, champ.",
            "Looks like you're not the boss here.",
            "You can't sit with us... or move us.",
            "No power, no glory. Sad life.",
            "Imagine thinking you have permissions. Couldn't be you.",
            "Try again when you're in charge, rookie.",
            "Permission? Nah, not today.",
            "Oops, someone forgot to level up their permissions.",
            "Not everyone can be a hero. Especially not you."
        ];

        const getRandomRoast = () => roastingLines[Math.floor(Math.random() * roastingLines.length)];

        if (!message.member.permissions.has(PermissionsBitField.Flags.MoveMembers)) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`You must have \`Move Members\` permission to use this command.`)
                )
                .addSeparatorComponents(
                    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(getRandomRoast())
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.MoveMembers)) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`I must have \`Move Members\` permission to use this command.`)
                )
                .addSeparatorComponents(
                    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(getRandomRoast())
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        let member = message.mentions.members.first() || message.guild.members.cache.get(args[0]);
        if (!member) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`Please provide a valid member.`)
                )
                .addSeparatorComponents(
                    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(getRandomRoast())
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        let channel = message.guild.channels.cache.get(args[1]) || message.mentions.channels.first();
        if (!channel || channel.type !== ChannelType.GuildVoice) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`Please provide a valid voice channel.`)
                )
                .addSeparatorComponents(
                    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(getRandomRoast())
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        if (!member.voice.channel) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`The provided member is not connected to a voice channel.`)
                )
                .addSeparatorComponents(
                    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(getRandomRoast())
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        if (member.voice.channel.id === channel.id) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`The member is already in the specified voice channel.`)
                )
                .addSeparatorComponents(
                    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(getRandomRoast())
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        const permissions = channel.permissionsFor(message.member);
        if (!permissions || !permissions.has(PermissionsBitField.Flags.Connect)) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`You do not have permission to join ${channel}.`)
                )
                .addSeparatorComponents(
                    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(getRandomRoast())
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        try {
            await member.voice.setChannel(channel.id, `${message.author.tag} | ${message.author.id}`);
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`Successfully moved ${member} to ${channel}!`)
                )
            await message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        } catch (err) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`I don't have the required permissions to move members to ${channel}.`)
                )
                .addSeparatorComponents(
                    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
                )
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(getRandomRoast())
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
    }
};
