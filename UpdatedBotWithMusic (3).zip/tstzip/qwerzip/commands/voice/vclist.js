const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags
} = require('discord.js')

module.exports = {
    name: 'vclist',
    category: 'voice',
    premium: true,

    run: async (client, message, args) => {
        if (!message.member.voice.channel) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`You must be connected to a voice channel first.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
        }
        let members = message.guild.members.cache
            .filter(
                (m) =>
                    m.voice?.channel?.id == message.member?.voice?.channel?.id
            )
            .map((m) => `${m.user.tag} | <@${m.user.id}>`)
            .join(`\n`)
        const container = new ContainerBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`**Users in ${message.member.voice.channel.name} - ${message.member.voice.channel.members.size}**`)
            )
            .addSeparatorComponents(
                new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
            )
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(members)
            )
        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
    }
}
