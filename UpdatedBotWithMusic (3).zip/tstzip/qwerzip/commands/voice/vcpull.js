const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags
} = require('discord.js');

module.exports = {
    name: 'vcpull',
    category: 'voice',
    run: async (client, message, args) => {
        if (!message.member.permissions.has('MoveMembers')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`You must have \`Move members\` permission to use this command.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        if (!message.guild.members.me.permissions.has('MoveMembers')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`I must have \`Move members\` permission to use this command.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        if (!message.member.voice.channel) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`You must be connected to a voice channel first.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        let member =
            message.mentions.members.first() ||
            message.guild.members.cache.get(args[0]);
        if (!member) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`Please Proide a valid member`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        if(!member.voice.channel) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`provided member is not connected to voice channel.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        if(member.voice.channel.id === message.member.voice.channel.id) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | did you think i am dumb ? you both are in same voice channel`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 })
        }
        try {
            await member.voice.setChannel(message.member.voice.channel.id,`${message.author.tag} | ${message.author.id}`)
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.tick} | Successfully Moved ${member} Members to ${message.member.voice.channel}!`)
                )
            await message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        } catch (err) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`I don't have the required permissions to move members to ${channel}.`)
                )
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
    }
};
