const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    MessageFlags 
} = require('discord.js');

module.exports = {
    name: 'roleinfo',
    aliases: ['ri'],
    category: 'info',
    description: 'To Get Information About A Role',
    premium: false,
    run: async (client, message, args) => {
        let role = await message.mentions.roles.first() || await message.guild.roles.fetch(args[0]);
        
        if (!role) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${client.emoji.cross} | You didn't provided a valid role.`)
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }
        
        let size = await message.guild.members.fetch().then(members => members.filter(member => member.roles.cache.has(role.id))).then(x => x.size);
        let color = role.color == 0 ? '#000000' : role.color;
        let created = `<t:${Math.round(role.createdTimestamp / 1000)}:R>`;

        const permissions = role.permissions.toArray().includes('Administrator')
            ? '`Administrator`'
            : role.permissions
                .toArray()
                .sort((a, b) => a.localeCompare(b))
                .map((p) => `\`${p}\``)
                .join(', ');

        const container = new ContainerBuilder();
        container.setAccentColor(color == '#000000' ? '000001' : client.color);
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`## ${role.name}'s Information`)
        );
        container.addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        );
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(
                `**General Info**\n` +
                `Role Name: **${role.name}**\n` +
                `Role Id: \`${role.id}\`\n` +
                `Role Position: **${role.rawPosition}**\n` +
                `Hex Code: \`${color}\`\n` +
                `Created At: ${created}\n` +
                `Mentionability: ${role.mentionable}\n` +
                `Integration: ${role.managed}`
            )
        );
        container.addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        );
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`**Allowed Permissions**\n${permissions || 'None'}`)
        );
        container.addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        );
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`**Role Members**\n\`${size}\``)
        );

        message.channel.send({ 
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};
