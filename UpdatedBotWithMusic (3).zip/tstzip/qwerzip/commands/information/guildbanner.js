const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    MessageFlags,
    MediaGalleryBuilder,
    MediaGalleryItemBuilder
} = require('discord.js');

module.exports = {
    name: 'serverbanner',
    category: 'info',
    premium: false,

    run: async (client, message, args) => {
        const container = new ContainerBuilder();
        
        if (message.guild.banner) {
            const bannerUrl = message.guild.bannerURL({ size: 4096 });
            container.setAccentColor('#2f3136');
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## ${message.guild.name} SERVER BANNER`)
            );
            container.addMediaGalleryComponents(
                new MediaGalleryBuilder().addItems(
                    new MediaGalleryItemBuilder().setURL(bannerUrl)
                )
            );
        } else {
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`This Server has no Banner!`)
            );
        }
        
        message.channel.send({ 
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};
