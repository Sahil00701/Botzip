const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    StringSelectMenuBuilder, 
    ActionRowBuilder, 
    MessageFlags, 
    ComponentType,
    PermissionsBitField,
    MediaGalleryBuilder,
    MediaGalleryItemBuilder
} = require('discord.js');
const { parse } = require('twemoji-parser');
const fetch = require('node-fetch');

module.exports = {
    name: 'steal',
    aliases: [],
    cooldown: 5,
    category: 'info',
    premium: false,

    run: async (client, message, args) => {
        const createContainer = (content) => {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(content)
            );
            return container;
        };

        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageEmojisAndStickers)) {
            return message.channel.send({
                components: [createContainer(`${client.emoji.cross} | You must have \`Manage Emoji\` perms to use this command.`)],
                flags: MessageFlags.IsComponentsV2
            });
        }
        
        if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageEmojisAndStickers)) {
            return message.channel.send({
                components: [createContainer(`${client.emoji.cross} | I must have \`Manage Emoji\` perms to use this command.`)],
                flags: MessageFlags.IsComponentsV2
            });
        }

        let emojis = args.length ? args.join(' ').match(/<a?:\w+:\d+>/g) : [];
        if (!emojis.length) {
            const reply = message.reference?.messageId
                ? await message.channel.messages.fetch(message.reference.messageId)
                : null;

            if (!reply) {
                return message.channel.send({
                    components: [createContainer('You need to reply to a message containing emojis or stickers, or provide an emoji as an argument to use this command.')],
                    flags: MessageFlags.IsComponentsV2
                });
            }

            const customEmojis = reply.content.match(/<a?:\w+:\d+>/g) || [];
            const unicodeEmojis = parse(reply.content).map(emoji => emoji.url);
            const stickers = reply.stickers.map(sticker => sticker.url);

            emojis = customEmojis.concat(unicodeEmojis).concat(stickers);
        }

        if (emojis.length === 0) {
            return message.channel.send({
                components: [createContainer('No emojis or stickers found in the provided arguments or the replied message.')],
                flags: MessageFlags.IsComponentsV2
            });
        }

        let currentPage = 0;
        const totalPages = emojis.length;

        const getItemUrl = (index) => {
            const item = emojis[index];
            const isCustomEmoji = item.startsWith('<');
            const isSticker = item.endsWith('.webp');

            if (isCustomEmoji) {
                return `https://cdn.discordapp.com/emojis/${item.split(':')[2]?.replace('>', '')}${item.startsWith('<a') ? '.gif' : '.png'}`;
            } else if (isSticker) {
                return item.replace('.webp', '.png');
            }
            return item || 'https://via.placeholder.com/128?text=Invalid+Item';
        };

        const buildContainer = (page) => {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## Item ${page + 1} of ${totalPages}`)
            );
            container.addMediaGalleryComponents(
                new MediaGalleryBuilder().addItems(
                    new MediaGalleryItemBuilder().setURL(getItemUrl(page))
                )
            );

            const navOptions = [];
            if (totalPages > 1) {
                navOptions.push({ label: 'First', description: 'Go to first item', value: 'first' });
                navOptions.push({ label: 'Previous', description: 'Go to previous item', value: 'previous' });
                navOptions.push({ label: 'Next', description: 'Go to next item', value: 'next' });
                navOptions.push({ label: 'Last', description: 'Go to last item', value: 'last' });
            }
            navOptions.push({ label: 'Steal as Emoji', description: 'Add as emoji to server', value: 'steal_emoji' });
            navOptions.push({ label: 'Steal as Sticker', description: 'Add as sticker to server', value: 'steal_sticker' });
            navOptions.push({ label: 'Delete', description: 'Delete this message', value: 'delete' });

            const selectMenu = new StringSelectMenuBuilder()
                .setCustomId('steal_select')
                .setPlaceholder('Choose an action')
                .addOptions(navOptions);

            const actionRow = new ActionRowBuilder().addComponents(selectMenu);
            container.addActionRowComponents(actionRow);
            
            return container;
        };

        const itemMessage = await message.channel.send({ 
            components: [buildContainer(currentPage)],
            flags: MessageFlags.IsComponentsV2
        });

        const collector = itemMessage.createMessageComponentCollector({ 
            componentType: ComponentType.StringSelect,
            filter: (i) => i.user.id === message.author.id, 
            time: 60000 
        });

        collector.on('collect', async (interaction) => {
            const value = interaction.values[0];

            if (value === 'first') {
                currentPage = 0;
            } else if (value === 'previous') {
                currentPage = Math.max(0, currentPage - 1);
            } else if (value === 'next') {
                currentPage = Math.min(totalPages - 1, currentPage + 1);
            } else if (value === 'last') {
                currentPage = totalPages - 1;
            } else if (value === 'steal_emoji') {
                try {
                    const itemUrl = getItemUrl(currentPage);
                    const name = `emoji_${Date.now()}`;
                    await message.guild.emojis.create({ attachment: itemUrl, name: name });
                    await interaction.reply({ content: `Emoji added with name: ${name}`, flags: 64 });
                    return;
                } catch (error) {
                    await interaction.reply({ content: 'Failed to add emoji. Ensure the bot has the Manage Emojis permission.', flags: 64 });
                    return;
                }
            } else if (value === 'steal_sticker') {
                try {
                    const itemUrl = getItemUrl(currentPage);
                    const name = `sticker_${Date.now()}`;
                    const response = await fetch(itemUrl);
                    const buffer = await response.buffer();
                    await message.guild.stickers.create({
                        file: buffer,
                        name: name,
                        description: 'An awesome sticker'
                    });
                    await interaction.reply({ content: `Sticker added with name: ${name}`, flags: 64 });
                    return;
                } catch (error) {
                    await interaction.reply({ content: 'Failed to add sticker. Ensure the bot has the Manage Stickers permission.', flags: 64 });
                    return;
                }
            } else if (value === 'delete') {
                await itemMessage.delete();
                await message.channel.send({
                    components: [createContainer('Item selection has been deleted.')],
                    flags: MessageFlags.IsComponentsV2
                });
                collector.stop();
                return;
            }

            await interaction.update({ 
                components: [buildContainer(currentPage)],
                flags: MessageFlags.IsComponentsV2
            });
        });

        collector.on('end', async () => {
            try {
                const finalContainer = new ContainerBuilder();
                finalContainer.setAccentColor(client.color);
                finalContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`## Item ${currentPage + 1} of ${totalPages}`)
                );
                finalContainer.addMediaGalleryComponents(
                    new MediaGalleryBuilder().addItems(
                        new MediaGalleryItemBuilder().setURL(getItemUrl(currentPage))
                    )
                );
                await itemMessage.edit({ 
                    components: [finalContainer],
                    flags: MessageFlags.IsComponentsV2
                });
            } catch (error) {
                console.error(error);
            }
        });
    },
};
