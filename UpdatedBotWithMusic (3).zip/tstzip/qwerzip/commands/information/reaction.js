const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    MessageFlags 
} = require('discord.js');

const cooldown = new Set();

module.exports = {
    name: 'reaction',
    category: 'info',
    premium: false,

    run: async (client, message, args) => {
        if (cooldown.has(message.author.id)) {
            return message.reply("You are currently in cooldown. Please try again later.");
        }

        cooldown.add(message.author.id);

        try {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## React to play the game! 🎮`),
                new TextDisplayBuilder().setContent(`React with the emojis below to play.`)
            );

            const gameMessage = await message.channel.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });

            const allEmojis = ['🍇', '🍒', '🍊', '🍓', '🍐', '🍍', '🍋', '🍎', '🥝', '🍌', '🥭', '🍏', '🍅', '🍆', '🥑'];

            for (let i = allEmojis.length - 1; i > 0; i--) {
                const j = Math.floor(Math.random() * (i + 1));
                [allEmojis[i], allEmojis[j]] = [allEmojis[j], allEmojis[i]];
            }
            const emojis = allEmojis.slice(0, 6);

            for (const emoji of emojis) {
                await gameMessage.react(emoji);
            }

            const chosenEmoji = emojis[Math.floor(Math.random() * emojis.length)];
            await gameMessage.react(chosenEmoji);

            const updatedContainer = new ContainerBuilder();
            updatedContainer.setAccentColor(client.color);
            updatedContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## React to play the game! 🎮`),
                new TextDisplayBuilder().setContent(`The bot chose ${chosenEmoji}!`)
            );
            await gameMessage.edit({ 
                components: [updatedContainer],
                flags: MessageFlags.IsComponentsV2
            });

            const filter = (reaction, user) => {
                return reaction.emoji.name === chosenEmoji && !user.bot;
            };

            const collected = await gameMessage.awaitReactions({ filter, max: 1, time: 5000 });

            const finalContainer = new ContainerBuilder();
            finalContainer.setAccentColor(client.color);
            finalContainer.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## React to play the game! 🎮`)
            );

            if (collected.size > 0) {
                const winner = collected.first().users.cache.find(user => !user.bot);
                if (winner) {
                    finalContainer.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`<@${winner.id}> won the game!`)
                    );
                } else {
                    finalContainer.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`Unable to determine the winner.`)
                    );
                }
            } else {
                finalContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`Nobody reacted in time! Game over.`)
                );
            }
            await gameMessage.edit({ 
                components: [finalContainer],
                flags: MessageFlags.IsComponentsV2
            });
        } finally {
            cooldown.delete(message.author.id);
        }
    }
};
