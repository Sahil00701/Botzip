const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    MessageFlags,
    MediaGalleryBuilder,
    MediaGalleryItemBuilder
} = require('discord.js');

module.exports = {
    name: 'servericon',
    aliases: ['serverav', 'serveravatar'],
    category: 'info',
    premium: false,

    run: async (client, message, args) => {
        const container = new ContainerBuilder();
        container.setAccentColor(client.color);

        if (message.guild.icon !== null) {
            const iconUrl = message.guild.iconURL({ dynamic: true, size: 2048 });
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## ${message.guild.name}'s Server Icon`)
            );
            container.addMediaGalleryComponents(
                new MediaGalleryBuilder().addItems(
                    new MediaGalleryItemBuilder().setURL(iconUrl)
                )
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `[\`PNG\`](${message.guild.iconURL({
                        dynamic: true,
                        size: 2048,
                        format: 'png'
                    })}) | [\`JPG\`](${message.guild.iconURL({
                        dynamic: true,
                        size: 2048,
                        format: 'jpg'
                    })}) | [\`WEBP\`](${message.guild.iconURL({
                        dynamic: true,
                        size: 2048,
                        format: 'webp'
                    })})`
                )
            );
        } else {
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${client.emoji.cross} | This Guild Has No Avatar`)
            );
        }

        message.channel.send({ 
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};
