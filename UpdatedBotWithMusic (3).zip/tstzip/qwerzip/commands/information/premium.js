const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    MessageFlags 
} = require('discord.js');
const config = require(`${process.cwd()}/config.json`);

module.exports = {
    name: 'premium',
    aliases: ['prime'],
    category: 'info',
    premium: false,
    run: async (client, message, args) => {
        const prefix = '&' || message.guild.prefix;
        let link = 'https://discord.gg/snapz';

        const createContainer = (content, footer = null) => {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(content)
            );
            if (footer) {
                container.addSeparatorComponents(
                    new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
                );
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(footer)
                );
            }
            return container;
        };

        if (!args[0]) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## ${client.user.username} Premium`)
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**Upgrade Server**\nIf you are a subscriber, you can upgrade this server by typing \`${prefix}premium activate\`\n\n` +
                    `**Downgrade Server**\nIf you have activated [Premium](${link}) here then you can downgrade [Premium](${link}) from this server by typing \`${prefix}premium revoke\`\n\n` +
                    `**Check Server Premium Status**\nTo check the [Premium](${link}) status of this server just type \`${prefix}premium validity\`\n\n` +
                    `**Check Your Premium Status**\nTo check your [Premium](${link}) status just type \`${prefix}premium stats\`\n\n` +
                    `**Activate Noprefix**\nTo activate your [Premium](${link}) noprefix just type \`${prefix}premium noprefix\`\n\n` +
                    `**Get Premium**\n[Click here](${link}) to Get **[Premium](${link})**`
                )
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`*Developed with 💖 By Spyder Team*`)
            );
            return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        const isprem = await client.db.get(`uprem_${message.author.id}`);
        let type = args[0].toLowerCase();
        let own = await client.db.get(`spremown_${message.guild.id}`);
        let servers = (await client.db.get(`upremserver_${message.author.id}`)) || [];
        let isp = await client.db.get(`sprem_${message.guild.id}`);
        let time = await client.db.get(`upremend_${message.author.id}`);
        let count = (await client.db.get(`upremcount_${message.author.id}`)) || 0;

        switch (type) {
            case `activate`:
                if (!isprem) {
                    return message.reply({ components: [createContainer(`You don't have any type of premium subscription. Click [here](${link}) to [Purchase](${link}).`)], flags: MessageFlags.IsComponentsV2 });
                }
                if (count < 1) {
                    return message.reply({ components: [createContainer(`You have \`0\` Premium Count remaining. Click [here](${link}) to [Purchase](${link}).`)], flags: MessageFlags.IsComponentsV2 });
                }
                if (isp === `true`) {
                    return message.reply({ components: [createContainer(`This server's [Premium](${link}) has already been activated by <@${own}>.`)], flags: MessageFlags.IsComponentsV2 });
                }
                if (count > 0) {
                    await client.db.set(`sprem_${message.guild.id}`, `true`);
                    await client.db.set(`spremend_${message.guild.id}`, time);
                    await client.db.set(`spremown_${message.guild.id}`, `${message.author.id}`);
                    await client.db.set(`upremcount_${message.author.id}`, count - 1);
                    servers.push(`${message.guild.id}`);
                    client.db.set(`upremserver_${message.author.id}`, servers);
                    await message.guild.members.me.setNickname("Spyder Prime").catch(() => {});
                    const endTime = await client.db.get(`spremend_${message.guild.id}`);
                    return message.reply({ components: [createContainer(`This server has been added as a [Premium](${link}) Server.\n[Premium](${link}) valid till: <t:${Math.round(endTime / 1000)}> (<t:${Math.round(endTime / 1000)}:R>)`)], flags: MessageFlags.IsComponentsV2 });
                }
                break;

            case `revoke`:
                if (!isprem) {
                    return message.reply({ components: [createContainer(`You have \`0\` Premium Count remaining. Click [here](${link}) to [Purchase](${link}).`)], flags: MessageFlags.IsComponentsV2 });
                }
                if (!isp) {
                    return message.reply({ components: [createContainer(`This server haven't any type of premium subscription! If you are a subscriber, you can **upgrade** this server by typing \`${prefix}premium activate\`\nClick [here](${link}) to [Purchase](${link}).`)], flags: MessageFlags.IsComponentsV2 });
                }
                if (own !== message.author.id) {
                    return message.reply({ components: [createContainer(`You haven't activated the [Premium](${link}) on this Server to revoke it.`)], flags: MessageFlags.IsComponentsV2 });
                }
                await client.db.delete(`sprem_${message.guild.id}`);
                await client.db.delete(`spremend_${message.guild.id}`);
                await client.db.delete(`spremown_${message.guild.id}`);
                await client.db.set(`upremcount_${message.author.id}`, count + 1);
                servers = servers.filter((srv) => srv != `${message.guild.id}`);
                await client.db.set(`upremserver_${message.author.id}`, servers);
                await message.guild.members.me.setNickname(null).catch(() => {});
                return message.reply({ components: [createContainer(`You have successfully **revoked** the [Premium](${link}) from this server.`)], flags: MessageFlags.IsComponentsV2 });

            case `validity`:
                if (!isp) {
                    return message.reply({ components: [createContainer(`This server haven't any type of premium subscription! If you are a subscriber, you can **upgrade** this server by typing \`${prefix}premium activate\`\nClick [here](${link}) to [Purchase](${link}).`)], flags: MessageFlags.IsComponentsV2 });
                }
                const validityTime = await client.db.get(`spremend_${message.guild.id}`);
                return message.reply({ components: [createContainer(`**Premium: \`Active\`\nPremium Activator: <@${own}>\nPremium Ends: <t:${Math.round(validityTime / 1000)}> (<t:${Math.round(validityTime / 1000)}:R>)**`)], flags: MessageFlags.IsComponentsV2 });

            case `stats`:
                if (!isprem) {
                    return message.reply({ components: [createContainer(`You have \`0\` Premium Count remaining. Click [here](${link}) to [Purchase](${link}).`)], flags: MessageFlags.IsComponentsV2 });
                }
                let info = '';
                if (servers.length < 1) {
                    info = `No Servers`;
                } else {
                    for (let i = 0; i < servers.length; i++) {
                        try {
                            const ss = await client.guilds.fetch(`${servers[i]}`);
                            info = info + `${i + 1} - ${ss.name} (${servers[i]})\n`;
                        } catch (error) {
                            info = info + `${i + 1} - Unknown Server (${servers[i]})\n`;
                        }
                    }
                }
                const statsContainer = new ContainerBuilder();
                statsContainer.setAccentColor(client.color);
                statsContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Premium Count: \`${count}\`\nPremium Ends: <t:${Math.round(time / 1000)}> (<t:${Math.round(time / 1000)}:R>)**`)
                );
                statsContainer.addSeparatorComponents(
                    new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
                );
                statsContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Servers where you activated Premium**\n\`\`\`nim\n${info}\`\`\``)
                );
                return message.reply({ components: [statsContainer], flags: MessageFlags.IsComponentsV2 });

            case `noprefix`:
                if (!isprem) {
                    return message.reply({ components: [createContainer(`You don't have any type of premium subscription. Click [here](${link}) to [Purchase](${link}).`)], flags: MessageFlags.IsComponentsV2 });
                }
                let data = await client.db.get(`noprefix_${client.user.id}`);
                if (!data.includes(message.author.id)) {
                    await client.db.push(`noprefix_${client.user.id}`, message.author.id);
                    return message.reply({ components: [createContainer(`${client.emoji.tick} Your Premium Noprefix Is Successfully Activated`)], flags: MessageFlags.IsComponentsV2 });
                } else {
                    return message.reply({ components: [createContainer(`${client.emoji.cross} You Already Have Noprefix Perks`)], flags: MessageFlags.IsComponentsV2 });
                }

            default:
                const defaultContainer = new ContainerBuilder();
                defaultContainer.setAccentColor(client.color);
                defaultContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`## ${client.user.username} Premium`)
                );
                defaultContainer.addSeparatorComponents(
                    new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
                );
                defaultContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `**Upgrade Server**\nIf you are a subscriber, you can upgrade this server by typing \`${prefix}premium activate\`\n\n` +
                        `**Downgrade Server**\nIf you have activated [Premium](${link}) here then you can downgrade [Premium](${link}) from this server by typing \`${prefix}premium revoke\`\n\n` +
                        `**Check Server Premium Status**\nTo check the [Premium](${link}) status of this server just type \`${prefix}premium validity\`\n\n` +
                        `**Check Your Premium Status**\nTo check your [Premium](${link}) status just type \`${prefix}premium stats\`\n\n` +
                        `**Activate Noprefix**\nTo activate your [Premium](${link}) noprefix just type \`${prefix}premium noprefix\`\n\n` +
                        `**Get Premium**\n[Click here](${link}) to Get **[Premium](${link})**`
                    )
                );
                defaultContainer.addSeparatorComponents(
                    new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
                );
                defaultContainer.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`*Developed with 💖 By Spyder Team*`)
                );
                return message.reply({ components: [defaultContainer], flags: MessageFlags.IsComponentsV2 });
        }
    }
};
