const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    MessageFlags,
    ThumbnailBuilder,
    MediaGalleryBuilder,
    MediaGalleryItemBuilder
} = require('discord.js');
const { ChannelType } = require('discord.js');
const moment = require('moment');

const verificationLevels = {
    0: 'None',
    1: 'Low',
    2: 'Medium',
    3: 'High',
    4: 'Very High',
};

const booster = {
    0: 'Level 0',
    1: 'Level: 1',
    2: 'Level: 2',
    3: 'Level: 3',
};

const disabled = '<:Spyder_crosss:1180470543896551438>';
const enabled = '<:Spyder_tick:1180470648053702657>';

module.exports = {
    name: 'serverinfo',
    category: 'info',
    aliases: ['si'],
    description: 'To Get Information About The Server',
    premium: false,
    run: async (client, message, args) => {
        try {
            const guild = message.guild;
            const { createdTimestamp, ownerId, description, features } = guild;

            const roles = guild.roles.cache
                .sort((a, b) => b.position - a.position)
                .map((role) => role.toString())
                .slice(0, -1);

            const rolesdisplay = roles.length < 15
                ? roles.join(' ') || 'None'
                : `${roles.slice(0, 15).join(' ')} \`and more...\``;

            const members = guild.members.cache;
            const channels = guild.channels.cache;
            const emojis = guild.emojis.cache;

            const bans = await guild.bans.fetch().then((x) => x.size).catch(() => 'N/A');
            const activeInvites = await guild.invites.fetch().catch(() => []);
            const inviteCount = activeInvites.size;

            let vanityData;
            try {
                vanityData = await guild.fetchVanityData();
            } catch {
                vanityData = { code: 'No vanity URL', uses: 'N/A' };
            }

            const featuresList = features.map(feature => `${enabled} \`${feature.replace(/_/g, ' ').toLowerCase()}\``).join('\n');

            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## ${guild.name}'s Information`)
            );
            if (guild.iconURL()) {
                container.addMediaGalleryComponents(
                    new MediaGalleryBuilder().addItems(
                        new MediaGalleryItemBuilder().setURL(guild.iconURL({ size: 256 }))
                    )
                );
            }
            
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**__About__**\n` +
                    `**Name**: ${guild.name}\n` +
                    `**ID**: ${guild.id}\n` +
                    `**Owner <a:OWNER:1183476311038111865>:** <@!${ownerId}> (${ownerId})\n` +
                    `**Created at:** <t:${parseInt(createdTimestamp / 1000)}:R>\n` +
                    `**Description**: ${description || 'No description set.'}\n` +
                    `**Region**: ${guild.preferredLocale}\n` +
                    `**Members:** ${guild.memberCount}\n` +
                    `**Banned Members:** ${bans}`
                )
            );
            
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**__Server Information__**\n` +
                    `**Verification Level:** ${verificationLevels[guild.verificationLevel]}\n` +
                    `**Inactive Channel:** ${guild.afkChannelId ? `<#${guild.afkChannelId}>` : `${disabled}`}\n` +
                    `**Inactive Timeout:** ${guild.afkTimeout / 60} mins\n` +
                    `**System Messages Channel:** ${guild.systemChannelId ? `<#${guild.systemChannelId}>` : disabled}\n` +
                    `**Boost Bar Enabled:** ${guild.premiumProgressBarEnabled ? enabled : disabled}\n` +
                    `**Active Invites:** ${inviteCount}\n` +
                    `**Vanity URL:** ${vanityData.code}\n` +
                    `**Vanity URL Uses:** ${vanityData.uses}`
                )
            );
            
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**__Channels__**\n` +
                    `**Total:** ${channels.size}\n` +
                    `**Text Channels:** ${channels.filter((channel) => channel.type === ChannelType.GuildText).size}\n` +
                    `**Voice Channels:** ${channels.filter((channel) => channel.type === ChannelType.GuildVoice).size}\n` +
                    `**Categories:** ${channels.filter((channel) => channel.type === ChannelType.GuildCategory).size}\n` +
                    `**Announcements:** ${channels.filter((channel) => channel.type === ChannelType.GuildNews).size}\n` +
                    `**Stages:** ${channels.filter((channel) => channel.type === ChannelType.GuildStageVoice).size}`
                )
            );
            
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**__Emoji Info__**\n` +
                    `**Regular:** ${emojis.filter((emoji) => !emoji.animated).size}\n` +
                    `**Animated:** ${emojis.filter((emoji) => emoji.animated).size}\n` +
                    `**Total:** ${emojis.size}`
                )
            );
            
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `**__Boost Status__**\n${booster[guild.premiumTier]} [<a:boost:1183480032035876936> ${guild.premiumSubscriptionCount || '0'} Boosts]`
                )
            );

            if (featuresList) {
                container.addSeparatorComponents(
                    new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
                );
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**__Server Features__**\n${featuresList}`)
                );
            }

            if (guild.bannerURL()) {
                container.addMediaGalleryComponents(
                    new MediaGalleryBuilder().addItems(
                        new MediaGalleryItemBuilder().setURL(guild.bannerURL({ dynamic: true, size: 4096 }))
                    )
                );
            }

            message.channel.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        } catch (error) {
            console.error(error);
        }
    },
};
