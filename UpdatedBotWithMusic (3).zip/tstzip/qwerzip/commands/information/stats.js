const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    StringSelectMenuBuilder, 
    ActionRowBuilder, 
    MessageFlags, 
    ComponentType,
    MediaGalleryBuilder,
    MediaGalleryItemBuilder
} = require('discord.js');
const moment = require('moment');
const os = require('os');

module.exports = {
    name: 'stats',
    category: 'info',
    aliases: ['botinfo', 'bi'],
    usage: 'stats',
    premium: false,

    run: async (client, message, args) => {
        try {
            const row1 = client.cmd.prepare('SELECT count FROM total_command_count WHERE id = 1').get();
            const totalCount = row1 ? row1.count : 0;
            
            const uptime = Math.round(Date.now() - client.uptime);
            let guilds1 = client.guilds.cache.size;
            let member1 = client.guilds.cache.reduce((x, y) => x + y.memberCount, 0);

            const selectMenu = new StringSelectMenuBuilder()
                .setCustomId('stats_select')
                .setPlaceholder('Select information type')
                .addOptions([
                    { label: 'General Info', description: 'View general bot information', value: 'general' },
                    { label: 'Team Info', description: 'View team information', value: 'team' },
                    { label: 'System Info', description: 'View system information', value: 'system' },
                    { label: 'Partners', description: 'View partners', value: 'partners' },
                    { label: 'Latency Graph', description: 'View latency graph', value: 'latencyGraph' }
                ]);

            const row = new ActionRowBuilder().addComponents(selectMenu);

            const buildGeneralContainer = () => {
                const container = new ContainerBuilder();
                container.setAccentColor(client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`## These statistics are only for cluster ${client.cluster.id} not for the entire bot.`),
                    new TextDisplayBuilder().setContent(`[Support Server](https://discord.gg/snapz)`)
                );
                container.addSeparatorComponents(
                    new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
                );
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `**__General Informations__**\n` +
                        `Bot's Mention: <@!${client.user.id}>\n` +
                        `Bot's Tag: ${client.user.tag}\n` +
                        `Cluster: ${client.cluster.id}\n` +
                        `Shard: ${message.guild.shardId}\n` +
                        `Bot's Version: 4.0.0\n` +
                        `Total Servers: ${guilds1}\n` +
                        `Total Users: ${member1} (${client.users.cache.size} Cached)\n` +
                        `Total Channels: ${client.channels.cache.size}\n` +
                        `Last Rebooted: ${moment(uptime).fromNow()}\n` +
                        `Commands Executed: ${totalCount}`
                    )
                );
                container.addSeparatorComponents(
                    new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
                );
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`*Requested By ${message.author.tag}*`)
                );
                container.addActionRowComponents(row);
                return container;
            };

            let msg = await message.channel.send({ 
                components: [buildGeneralContainer()],
                flags: MessageFlags.IsComponentsV2
            });

            const collector = msg.createMessageComponentCollector({
                componentType: ComponentType.StringSelect,
                time: 60000
            });

            collector.on('collect', async (i) => {
                if (i.user.id !== message.author.id) {
                    return i.reply({ content: "> This isn't for you.", flags: 64 });
                }

                const value = i.values[0];
                let newContainer;

                if (value === 'latencyGraph') {
                    let db = await client.db.ping();
                    const uri = await client.util.generateLatencyChart(client.ws.ping, db);
                    
                    newContainer = new ContainerBuilder();
                    newContainer.setAccentColor(client.color);
                    newContainer.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`## Latency Graph`),
                        new TextDisplayBuilder().setContent('This graph represents the latency between the bot and the database, alongside the WebSocket ping. A lower value indicates better performance.')
                    );
                    newContainer.addMediaGalleryComponents(
                        new MediaGalleryBuilder().addItems(
                            new MediaGalleryItemBuilder().setURL(uri)
                        )
                    );
                    newContainer.addSeparatorComponents(
                        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
                    );
                    newContainer.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`*Requested by ${message.author.tag} | Latency Overview*`)
                    );
                    newContainer.addActionRowComponents(row);
                } else if (value === 'partners') {
                    newContainer = new ContainerBuilder();
                    newContainer.setAccentColor(client.color);
                    newContainer.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`## Spyder Partner's`),
                        new TextDisplayBuilder().setContent(
                            `snapzhosting was born in 2025 with the idea of providing the latest generation products to customers. We provide **Virtual Private Servers**, **Panels**, Virtual Dedicated Servers, and Dedicated Servers [click here to see website](https://www.snapzone.online/)\n[Discord Server](https://discord.gg/XC6P9kMnTr)`
                        )
                    );
                    newContainer.addSeparatorComponents(
                        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
                    );
                    newContainer.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`*© Powered By Snapz Hosting*`)
                    );
                    newContainer.addActionRowComponents(row);
                } else if (value === 'team') {
                    let user = await client.users.fetch('1408831955369332786');
                    
                    newContainer = new ContainerBuilder();
                    newContainer.setAccentColor(client.color);
                    newContainer.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`## ${client.user.username}'s Information`)
                    );
                    newContainer.addSeparatorComponents(
                        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
                    );
                    newContainer.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**__Developers__**\n[${user.username}](https://discord.com/users/1408831955369332786)`)
                    );
                    newContainer.addSeparatorComponents(
                        new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
                    );
                    newContainer.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`*Requested By ${message.author.tag}*`)
                    );
                    newContainer.addActionRowComponents(row);
                } else if (value === 'general') {
                    newContainer = buildGeneralContainer();
                } else if (value === 'system') {
                    newContainer = new ContainerBuilder();
                    newContainer.setAccentColor(client.color);
                    newContainer.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`## Spyder Informations`),
                        new TextDisplayBuilder().setContent('<:Spyder_mainrole:1181290802022977576> | **Fetching** all the **resources**...')
                    );
                    newContainer.addActionRowComponents(row);

                    await i.update({ components: [newContainer], flags: MessageFlags.IsComponentsV2 });

                    const totalMemoryBytes = os.totalmem();
                    const cpuCount = os.cpus().length;
                    const freeMemoryBytes = os.freemem();
                    const memoryUsageBytes = totalMemoryBytes - freeMemoryBytes;

                    let totalMemoryGB = (totalMemoryBytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';
                    let memoryUsageGB = (memoryUsageBytes / (1024 * 1024 * 1024)).toFixed(2) + ' GB';

                    const processors = os.cpus();
                    const cpuUsage1 = os.cpus()[0].times;

                    setTimeout(async () => {
                        const cpuUsage2 = os.cpus()[0].times;
                        const ping = await client?.db?.ping();
                        
                        const systemContainer = new ContainerBuilder();
                        systemContainer.setAccentColor(client.color);
                        systemContainer.addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`## Spyder Informations`)
                        );
                        systemContainer.addSeparatorComponents(
                            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
                        );
                        systemContainer.addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(
                                `**__System Informations__**\n` +
                                `System Latency: ${client.ws.ping}ms\n` +
                                `Platform: ${process.platform}\n` +
                                `Architecture: ${process.arch}\n` +
                                `Memory Usage: ${memoryUsageGB}/${totalMemoryGB}\n` +
                                `Processor 1:\n` +
                                ` Model: ${processors[0].model}\n` +
                                ` Speed: ${processors[0].speed} MHz\n` +
                                `Times:\n` +
                                ` User: ${cpuUsage2.user} ms\n` +
                                ` Sys: ${cpuUsage2.sys} ms\n` +
                                ` Idle: ${cpuUsage2.idle} ms\n` +
                                ` IRQ: ${cpuUsage2.irq} ms\n` +
                                `Database Latency: ${ping?.toFixed(2) || '0'}ms`
                            )
                        );
                        systemContainer.addSeparatorComponents(
                            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
                        );
                        systemContainer.addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`*Requested By ${message.author.tag}*`)
                        );
                        systemContainer.addActionRowComponents(row);

                        await msg.edit({ components: [systemContainer], flags: MessageFlags.IsComponentsV2 });
                    }, 2000);

                    return;
                }

                await i.update({ components: [newContainer], flags: MessageFlags.IsComponentsV2 });
            });

            collector.on('end', async () => {
                const finalContainer = buildGeneralContainer();
                finalContainer.spliceComponents(-1, 1);
                await msg.edit({ components: [finalContainer], flags: MessageFlags.IsComponentsV2 });
            });
        } catch (e) {
            console.log(e);
        }
    }
};
