const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    MessageFlags 
} = require('discord.js');
const axios = require("axios");

module.exports = {
    name: 'truth',
    category: 'info',
    premium: false,
    run: async (client, message, args) => {
        try {
            const request = await axios.get("https://api.truthordarebot.xyz/api/truth");
            
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## ${request.data.question}`)
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`*Truth - ${message.author.displayName}*`)
            );
            
            return message.channel.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        } catch(e) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${client.emoji.cross} | truth or dare api is **currently down**.`)
            );
            return message.channel.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }
    }
};
