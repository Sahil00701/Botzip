const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    StringSelectMenuBuilder, 
    ActionRowBuilder, 
    MessageFlags, 
    ComponentType,
    MediaGalleryBuilder,
    MediaGalleryItemBuilder
} = require('discord.js');

module.exports = {
    name: 'avatar',
    aliases: ['av', 'photo'],
    category: 'info',
    cooldown: 4,
    premium: false,

    run: async (client, message, args) => {
        let member;

        if (args[0]) {
            member = await getUserFromMention(message, args[0]);
            if (!member) {
                try {
                    member = await client.users.fetch(args[0]);
                } catch (error) {
                    member = message.member;
                }
            }
        } else {
            member = message.member;
        }

        const guildMember = message.guild.members.cache.get(member.id);
        const hasServerAvatar = guildMember && guildMember.avatar;

        const createContainer = (avatarUrl, type = 'User') => {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## ${member.username || member.user.username}'s ${type} Avatar`)
            );
            container.addMediaGalleryComponents(
                new MediaGalleryBuilder().addItems(
                    new MediaGalleryItemBuilder().setURL(avatarUrl)
                )
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    `[\`PNG\`](${avatarUrl.replace(/\.(gif|webp|jpg)/, '.png')}) | ` +
                    `[\`JPG\`](${avatarUrl.replace(/\.(gif|webp|png)/, '.jpg')}) | ` +
                    `[\`WEBP\`](${avatarUrl.replace(/\.(gif|png|jpg)/, '.webp')})`
                )
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`*Requested By ${message.member.displayName}*`)
            );
            return container;
        };

        if (hasServerAvatar) {
            const selectMenu = new StringSelectMenuBuilder()
                .setCustomId('avatar_select')
                .setPlaceholder('Choose avatar type')
                .addOptions([
                    {
                        label: 'User Avatar',
                        description: 'View user avatar',
                        value: 'avatar',
                    },
                    {
                        label: 'Server Avatar',
                        description: 'View server avatar',
                        value: 'server_avatar',
                    }
                ]);

            const actionRow = new ActionRowBuilder().addComponents(selectMenu);
            const userAvatarUrl = member.displayAvatarURL({ forceStatic: false, size: 2048 });
            const container = createContainer(userAvatarUrl, 'User');
            container.addActionRowComponents(actionRow);

            const msg = await message.channel.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });

            const collector = msg.createMessageComponentCollector({ 
                componentType: ComponentType.StringSelect, 
                time: 60000 
            });

            collector.on('collect', async (interaction) => {
                if (interaction.user.id !== message.author.id) {
                    return interaction.reply({ content: `${client.emoji.cross} | ${interaction.user} Hey! it's not your interaction`, flags: 64 });
                }

                let newContainer;
                if (interaction.values[0] === 'avatar') {
                    const avatarUrl = member.displayAvatarURL({ forceStatic: false, size: 2048 });
                    newContainer = createContainer(avatarUrl, 'User');
                } else if (interaction.values[0] === 'server_avatar') {
                    const serverAvatarUrl = guildMember.displayAvatarURL({ forceStatic: false, size: 2048, dynamic: true });
                    newContainer = createContainer(serverAvatarUrl, 'Server');
                }

                const newSelectMenu = new StringSelectMenuBuilder()
                    .setCustomId('avatar_select')
                    .setPlaceholder('Choose avatar type')
                    .addOptions([
                        {
                            label: 'User Avatar',
                            description: 'View user avatar',
                            value: 'avatar',
                        },
                        {
                            label: 'Server Avatar',
                            description: 'View server avatar',
                            value: 'server_avatar',
                        }
                    ]);

                const newActionRow = new ActionRowBuilder().addComponents(newSelectMenu);
                newContainer.addActionRowComponents(newActionRow);

                await interaction.update({ 
                    components: [newContainer],
                    flags: MessageFlags.IsComponentsV2
                });
            });

            collector.on('end', async () => {
                const finalContainer = createContainer(member.displayAvatarURL({ forceStatic: false, size: 2048 }), 'User');
                await msg.edit({ 
                    components: [finalContainer],
                    flags: MessageFlags.IsComponentsV2
                });
            });

        } else {
            const avatarUrl = member.displayAvatarURL({ forceStatic: false, size: 2048 });
            const container = createContainer(avatarUrl, 'User');
            return message.channel.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }
    }
};

async function getUserFromMention(message, mention) {
    if (!mention) return null;

    const matches = mention.match(/^<@!?(\d+)>$/);
    if (!matches) return null;

    const id = matches[1];
    return await message.client.users.fetch(id).catch(() => null) || message.member;
}
