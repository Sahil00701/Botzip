const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    StringSelectMenuBuilder, 
    ActionRowBuilder, 
    MessageFlags, 
    ComponentType 
} = require('discord.js');
const db = require('../../models/afk.js');

module.exports = {
    name: 'afk',
    description: "Set's You Away From Keyboard",
    category: 'info',
    premium: false,

    run: async (client, message, args) => {
        const data = await db.findOne({
            Guild: message.guildId,
            Member: message.author.id
        });

        const reason = args.join(' ') ? args.join(' ') : "I'm AFK :)";

        const urlRegex = /\b(?:https?:\/\/|www\.)\S+/gi;
        const regex = /(https?:\/\/)?(www\.)?(discord\.(gg|io|me|li|club)|discordapp\.com\/invite|discord\.com\/invite)\/.+[a-z]/gi;
        const checkmessage = reason;
        if (regex.test(checkmessage) || urlRegex.test(checkmessage)) { 
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent('You cannot add links in my AFK system. Do not attempt to advertise using me.')
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent('*Spyder FETCHING | LINK FOUND*')
            );
            return await message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        if (data) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## UwU, you are already AFK.`)
            );
            return message.channel.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        } else {
            const selectMenu = new StringSelectMenuBuilder()
                .setCustomId('afk_select')
                .setPlaceholder('Choose AFK type')
                .addOptions([
                    {
                        label: 'Set Global AFK',
                        description: 'Set AFK across all servers',
                        value: 'afk_global',
                    },
                    {
                        label: 'Set Server AFK',
                        description: 'Set AFK for this server only',
                        value: 'afk_server',
                    }
                ]);

            const actionRow = new ActionRowBuilder().addComponents(selectMenu);

            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`Please choose whether you want to set it globally or just for this server.`)
            );
            container.addActionRowComponents(actionRow);

            const msg = await message.channel.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });

            const collector = msg.createMessageComponentCollector({
                componentType: ComponentType.StringSelect,
                time: 10000,
            });

            collector.on('collect', async (interaction) => {
                if (interaction.user.id !== message.author.id) {
                    return interaction.reply({ content: `${client.emoji.cross} | This is not your interaction!`, flags: 64 });
                }

                const value = interaction.values[0];
                const memberId = interaction.user.id;
                const guildId = interaction.guildId;

                if (value === 'afk_global' || value === 'afk_server') {
                    const isGlobal = value === 'afk_global';
                    const afkReason = args.join(' ') || "I'm AFK :)";

                    await db.deleteMany({ Member: memberId });

                    const newData = new db({
                        Guild: isGlobal ? null : guildId,
                        Member: memberId,
                        Reason: afkReason,
                        Time: Date.now(),
                        IsGlobal: isGlobal
                    });

                    await newData.save();

                    const updatedContainer = new ContainerBuilder();
                    updatedContainer.setAccentColor(client.color);
                    updatedContainer.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`Your AFK is now set to: **${afkReason}**`)
                    );

                    await interaction.update({ 
                        components: [updatedContainer],
                        flags: MessageFlags.IsComponentsV2
                    });

                    collector.stop();
                }
            });

            collector.on('end', async (collected, reason) => {
                if (reason === 'time') {
                    const timeoutContainer = new ContainerBuilder();
                    timeoutContainer.setAccentColor(client.color);
                    timeoutContainer.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`AFK selection timed out.`)
                    );
                    await msg.edit({ 
                        components: [timeoutContainer],
                        flags: MessageFlags.IsComponentsV2
                    });
                }
            });
        }
    }
};
