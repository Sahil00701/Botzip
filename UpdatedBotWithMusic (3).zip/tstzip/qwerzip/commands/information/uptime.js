const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    MessageFlags 
} = require('discord.js');

module.exports = {
    name: 'uptime',
    category: 'info',
    premium: false,
    run: async (client, message, args) => {
        const duration1 = Math.round((Date.now() - message.client.uptime) / 1000);
        
        const container = new ContainerBuilder();
        container.setAccentColor(client.color);
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`I am online from <t:${duration1}:R>`)
        );
        
        message.channel.send({ 
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};
