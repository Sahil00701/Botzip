const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    MessageFlags 
} = require('discord.js');

module.exports = {
    name: 'channelcount',
    aliases: ['cc'],
    category: 'info',
    premium: false,
    run: async (client, message, args) => {
        const container = new ContainerBuilder();
        container.setAccentColor(client.color);
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`## ${message.author.displayName}`),
            new TextDisplayBuilder().setContent(`**Channel Count : ${message.guild.channels.cache.size}**`)
        );
        
        return message.channel.send({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};
