const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    MessageFlags 
} = require('discord.js');
const db = require('../../models/boost.js');

module.exports = {
    name: 'setboost',
    aliases: ['boost'],
    category: 'info',
    premium: false,

    run: async (client, message, args) => {
        const createContainer = (content, footer = null) => {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(content)
            );
            if (footer) {
                container.addSeparatorComponents(
                    new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
                );
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`*${footer}*`)
                );
            }
            return container;
        };

        if (!message.member.permissions.has('Administrator')) {
            return message.channel.send({
                components: [createContainer(`${client.emoji.cross} | You must have \`Administration\` perms to run this command.`)],
                flags: MessageFlags.IsComponentsV2
            });
        }

        let disable = args[0] ? args[0].toLowerCase() == 'off' : null;
        let channel, hasPerms = null;
        
        if (!disable) {
            channel = message.mentions.channels.first() || message.guild.channels.cache.get(args[0]);
        }
        
        if (!disable && !channel) {
            return message.channel.send({
                components: [createContainer(
                    `${client.emoji.cross} | You didn't provided a valid channel.`,
                    `If you want to enable boost message then provide channel\n${message.guild.prefix}setboost <#channel> or Channel id\nFor disable type ${message.guild.prefix}setboost off`
                )],
                flags: MessageFlags.IsComponentsV2
            });
        }
        
        if (!disable) {
            hasPerms = message.guild.members.me.permissionsIn(channel).has('SendMessages');
        }
        
        if (!disable && !hasPerms) {
            return message.channel.send({
                components: [createContainer(`${client.emoji.cross} | I didn't have permissions to send messages in <#${channel.id}>.`)],
                flags: MessageFlags.IsComponentsV2
            });
        }
        
        let data = await db.findOne({ Guild: message.guildId });
        if (!data) {
            data = new db({
                Guild: message.guild.id,
                Boost: disable ? null : channel.id
            });
        } else {
            data.Boost = disable ? null : channel.id;
        }
        await data.save();
        
        message.channel.send({
            components: [createContainer(
                disable
                    ? `${client.emoji.tick} | I'll not send messages when someone boosts the server.`
                    : `${client.emoji.tick} | I'll now send messages to <#${channel.id}> when someone boosts the server.`
            )],
            flags: MessageFlags.IsComponentsV2
        });
    }
};
