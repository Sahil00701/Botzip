const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    MessageFlags 
} = require('discord.js');

module.exports = {
    name: 'emojilist',
    aliases: ['emojis'],
    category: 'info',
    premium: false,

    run: async (client, message, args) => {
        let Emojis = '';
        let EmojisAnimated = '';
        let EmojiCount = 0;
        let Animated = 0;
        let OverallEmojis = 0;
        
        function Emoji(id) {
            return client.emojis.cache.get(id).toString();
        }
        
        message.guild.emojis.cache.forEach((emoji) => {
            OverallEmojis++;
            if (emoji.animated) {
                Animated++;
                EmojisAnimated += Emoji(emoji.id);
            } else {
                EmojiCount++;
                Emojis += Emoji(emoji.id);
            }
        });
        
        const emojis = message.guild.emojis;
        if (emojis.cache.size == 0) {
            return message.channel.send(`No Emoji Found`);
        }

        const container = new ContainerBuilder();
        container.setAccentColor(client.color);
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`## Emoji List For ${message.guild.name}`)
        );
        container.addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        );
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`**Animated Emojis \`[${Animated}]\`**\n${EmojisAnimated || 'None'}`)
        );
        container.addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        );
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`**Standard Emojis \`[${EmojiCount}]\`**\n${Emojis || 'None'}`)
        );

        message.channel.send({ 
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};
