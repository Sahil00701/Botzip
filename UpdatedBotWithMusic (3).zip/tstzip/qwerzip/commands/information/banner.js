const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    StringSelectMenuBuilder, 
    ActionRowBuilder, 
    MessageFlags, 
    ComponentType,
    MediaGalleryBuilder,
    MediaGalleryItemBuilder
} = require('discord.js');
const axios = require('axios');

module.exports = {
    name: 'banner',
    aliases: [],
    category: 'info',
    premium: false,

    run: async (client, message, args) => {
        let member;
        
        if (args[0]) {
            member = await getUserFromMention(message, args[0]);
            if (!member) {
                try {
                    member = await client.users.fetch(args[0]);
                } catch (error) {
                    member = message.member;
                }
            }
        } else {
            member = message.member;
        }

        const guildMember = message.guild.members.cache.get(member.id);

        const userData = await axios
            .get(`https://discord.com/api/users/${member.id}`, {
                headers: {
                    Authorization: `Bot ${client.token}`,
                },
            })
            .then((res) => res.data)
            .catch(() => null);

        const userBanner = userData && userData.banner
            ? `https://cdn.discordapp.com/banners/${member.id}/${userData.banner}${
                userData.banner.startsWith('a_') ? '.gif' : '.png'
            }?size=4096`
            : null;

        const serverBanner = guildMember && guildMember.banner
            ? `https://cdn.discordapp.com/guilds/${message.guild.id}/users/${member.id}/banner/${guildMember.banner}${
                guildMember.banner.startsWith('a_') ? '.gif' : '.png'
            }?size=4096`
            : null;

        const createContainer = (bannerUrl, type = 'User') => {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(bannerUrl 
                    ? `## ${type} Banner of ${member.user ? member.user.tag : member.tag}`
                    : `## ${type} Banner not found for ${member.user ? member.user.tag : member.tag}`)
            );
            if (bannerUrl) {
                container.addMediaGalleryComponents(
                    new MediaGalleryBuilder().addItems(
                        new MediaGalleryItemBuilder().setURL(bannerUrl)
                    )
                );
            }
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`*Requested by: ${message.author.tag}*`)
            );
            return container;
        };

        if (userBanner || serverBanner) {
            const options = [];
            if (userBanner) {
                options.push({
                    label: 'User Banner',
                    description: 'View user banner',
                    value: 'user_banner',
                });
            }
            if (serverBanner) {
                options.push({
                    label: 'Server Banner',
                    description: 'View server banner',
                    value: 'server_banner',
                });
            }

            if (options.length > 1) {
                const selectMenu = new StringSelectMenuBuilder()
                    .setCustomId('banner_select')
                    .setPlaceholder('Choose banner type')
                    .addOptions(options);

                const actionRow = new ActionRowBuilder().addComponents(selectMenu);
                const container = createContainer(userBanner, 'User');
                container.addActionRowComponents(actionRow);

                const msg = await message.channel.send({ 
                    components: [container],
                    flags: MessageFlags.IsComponentsV2
                });

                const collector = msg.createMessageComponentCollector({ 
                    componentType: ComponentType.StringSelect, 
                    time: 60000 
                });

                collector.on('collect', async (interaction) => {
                    if (interaction.user.id !== message.author.id) {
                        return interaction.reply({ content: 'This is not your interaction..!!', flags: 64 });
                    }

                    let newContainer;
                    if (interaction.values[0] === 'user_banner') {
                        newContainer = createContainer(userBanner, 'User');
                    } else if (interaction.values[0] === 'server_banner') {
                        newContainer = createContainer(serverBanner, 'Server');
                    }

                    const newSelectMenu = new StringSelectMenuBuilder()
                        .setCustomId('banner_select')
                        .setPlaceholder('Choose banner type')
                        .addOptions(options);

                    const newActionRow = new ActionRowBuilder().addComponents(newSelectMenu);
                    newContainer.addActionRowComponents(newActionRow);

                    await interaction.update({ 
                        components: [newContainer],
                        flags: MessageFlags.IsComponentsV2
                    });
                });

                collector.on('end', async () => {
                    const finalContainer = createContainer(userBanner || serverBanner, userBanner ? 'User' : 'Server');
                    await msg.edit({ 
                        components: [finalContainer],
                        flags: MessageFlags.IsComponentsV2
                    });
                });
            } else {
                const container = createContainer(userBanner || serverBanner, userBanner ? 'User' : 'Server');
                await message.channel.send({ 
                    components: [container],
                    flags: MessageFlags.IsComponentsV2
                });
            }
        } else {
            const container = createContainer(null, 'User');
            await message.channel.send({ 
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }
    },
};

async function getUserFromMention(message, mention) {
    if (!mention) return null;

    const matches = mention.match(/^<@!?(\d+)>$/);
    if (!matches) return null;

    const id = matches[1];
    return await message.client.users.fetch(id).catch(() => null) || message.member;
}
