const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    StringSelectMenuBuilder, 
    ActionRowBuilder, 
    MessageFlags, 
    ComponentType,
    ThumbnailBuilder,
    MediaGalleryBuilder,
    MediaGalleryItemBuilder
} = require('discord.js');

const cooldown = new Set();

module.exports = {
    name: 'embed',
    category: 'info',
    premium: false,
    run: async (client, message, args) => {
        let prefix = message.guild.prefix || '&';
        
        if (!message.member.permissions.has('Administrator')) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have \`Administrator\` permissions to use this command.`)
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }
        
        if (!message.guild.members.me.permissions.has('Administrator')) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${client.emoji.cross} | I don't have \`Administrator\` permissions to execute this command.`)
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        if (!client.util.hasHigher(message.member)) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have a higher role than me to use this command.`)
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        if (cooldown.has(message.guild.id, message.author.id)) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${client.emoji.cross} | You are currently in cooldown. Please try again later. Abort your ongoing embed creation process to invoke embed command again.`)
            );
            container.addSeparatorComponents(
                new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
            );
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent('*Note: If you delete embed message then wait till 1 hour after it your cooldown will automatically get removed from our system*')
            );
            return message.channel.send({
                components: [container],
                flags: MessageFlags.IsComponentsV2
            });
        }

        cooldown.add(message.guild.id, message.author.id);
        setTimeout(() => {
            cooldown.delete(message.guild.id, message.author.id);
        }, 3600000);

        let embedData = {
            title: '',
            description: 'Improve the Embed',
            color: client.color,
            author: { name: '', iconURL: null },
            footer: { text: '', iconURL: null },
            thumbnail: null,
            image: null
        };

        const selectMenu1 = new StringSelectMenuBuilder()
            .setCustomId('embed_options1')
            .setPlaceholder('Select embed option (Part 1)')
            .addOptions([
                { label: 'Title', description: 'Set embed title', value: 'title_embed' },
                { label: 'Description', description: 'Set embed description', value: 'description_embed' },
                { label: 'Color', description: 'Set embed color', value: 'color_embed' },
                { label: 'Author Text', description: 'Set author text', value: 'author_text_embed' },
                { label: 'Author Icon', description: 'Set author icon', value: 'author_icon_embed' }
            ]);

        const selectMenu2 = new StringSelectMenuBuilder()
            .setCustomId('embed_options2')
            .setPlaceholder('Select embed option (Part 2)')
            .addOptions([
                { label: 'Footer Text', description: 'Set footer text', value: 'footer_text_embed' },
                { label: 'Footer Icon', description: 'Set footer icon', value: 'footer_icon_embed' },
                { label: 'Image', description: 'Set embed image', value: 'image_embed' },
                { label: 'Thumbnail', description: 'Set embed thumbnail', value: 'thumbnail_embed' },
                { label: 'Reset Embed', description: 'Reset to default', value: 'default_embed' }
            ]);

        const selectMenu3 = new StringSelectMenuBuilder()
            .setCustomId('embed_actions')
            .setPlaceholder('Select action')
            .addOptions([
                { label: 'Send to Channel', description: 'Send embed to a channel', value: 'channel_send' },
                { label: 'Abort', description: 'Cancel embed creation', value: 'abort_embed' }
            ]);

        const row1 = new ActionRowBuilder().addComponents(selectMenu1);
        const row2 = new ActionRowBuilder().addComponents(selectMenu2);
        const row3 = new ActionRowBuilder().addComponents(selectMenu3);

        const buildPreviewContainer = () => {
            const container = new ContainerBuilder();
            container.setAccentColor(embedData.color);
            
            if (embedData.thumbnail) {
                container.addMediaGalleryComponents(
                    new MediaGalleryBuilder().addItems(
                        new MediaGalleryItemBuilder().setURL(embedData.thumbnail)
                    )
                );
            }
            if (embedData.author.name) {
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Author:** ${embedData.author.name}`)
                );
            }
            if (embedData.title) {
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`## ${embedData.title}`)
                );
            }
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(embedData.description || 'Improve the Embed')
            );
            if (embedData.image) {
                container.addMediaGalleryComponents(
                    new MediaGalleryBuilder().addItems(
                        new MediaGalleryItemBuilder().setURL(embedData.image)
                    )
                );
            }
            if (embedData.footer.text) {
                container.addSeparatorComponents(
                    new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
                );
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`*${embedData.footer.text}*`)
                );
            }
            container.addActionRowComponents(row1, row2, row3);
            return container;
        };

        const messageComponent = await message.channel.send({
            components: [buildPreviewContainer()],
            flags: MessageFlags.IsComponentsV2
        });

        const collector = messageComponent.createMessageComponentCollector({
            filter: (interaction) => {
                if (interaction.user.id !== message.author.id) {
                    interaction.reply({ content: `This is not your interaction. If you want to use command invoke \`embed\` command`, flags: 64 });
                    return false;
                }
                return true;
            },
            time: 1000 * 60 * 30,
            idle: 1000 * 60 * 15,
        });

        collector.on('collect', async (interaction) => {
            if (interaction.isStringSelectMenu()) {
                const value = interaction.values[0];
                
                if (value === 'title_embed') {
                    await interaction.reply({ content: `Embed Title Limit is 256 Characters. Please provide a Title below 256 characters.`, flags: 64 });
                    const msgCollector = message.channel.createMessageCollector({ filter: msg => msg.author.id === message.author.id, max: 1, time: 1000 * 60 * 30 });
                    msgCollector.on('collect', async (msg) => {
                        embedData.title = msg.content.slice(0, 250);
                        msg.delete().catch(() => {});
                        await messageComponent.edit({ components: [buildPreviewContainer()], flags: MessageFlags.IsComponentsV2 });
                    });
                } else if (value === 'description_embed') {
                    await interaction.reply({ content: `Embed Description Limit is 4096 Characters. Please provide a Description below 4096 characters.`, flags: 64 });
                    const msgCollector = message.channel.createMessageCollector({ filter: msg => msg.author.id === message.author.id, max: 1, time: 1000 * 60 * 30 });
                    msgCollector.on('collect', async (msg) => {
                        embedData.description = msg.content.slice(0, 4096);
                        msg.delete().catch(() => {});
                        await messageComponent.edit({ components: [buildPreviewContainer()], flags: MessageFlags.IsComponentsV2 });
                    });
                } else if (value === 'color_embed') {
                    await interaction.reply({ content: `Please provide a Color for Embed in hex code #000000`, flags: 64 });
                    const msgCollector = message.channel.createMessageCollector({ filter: msg => msg.author.id === message.author.id, max: 1, time: 1000 * 60 * 30 });
                    msgCollector.on('collect', async (msg) => {
                        const colorRegex = /^#([0-9A-Fa-f]{6})$/;
                        if (colorRegex.test(msg.content)) {
                            embedData.color = msg.content.toUpperCase();
                            msg.delete().catch(() => {});
                            await messageComponent.edit({ components: [buildPreviewContainer()], flags: MessageFlags.IsComponentsV2 });
                        } else {
                            message.channel.send("Please use this format '#000000'.");
                        }
                    });
                } else if (value === 'author_text_embed') {
                    await interaction.reply({ content: `Embed Author Limit is 256 Characters. Please provide an Author below 256 characters.`, flags: 64 });
                    const msgCollector = message.channel.createMessageCollector({ filter: msg => msg.author.id === message.author.id, max: 1, time: 1000 * 60 * 30 });
                    msgCollector.on('collect', async (msg) => {
                        embedData.author.name = msg.content.slice(0, 250);
                        msg.delete().catch(() => {});
                        await messageComponent.edit({ components: [buildPreviewContainer()], flags: MessageFlags.IsComponentsV2 });
                    });
                } else if (value === 'author_icon_embed') {
                    await interaction.reply({ content: `Please provide a valid image URL for the author icon, ending with .jpg, .jpeg, .png, or .gif. Type 'reset' to remove.`, flags: 64 });
                    const msgCollector = message.channel.createMessageCollector({ filter: msg => msg.author.id === message.author.id, max: 1, time: 1000 * 60 * 30 });
                    msgCollector.on('collect', async (msg) => {
                        if (msg.content.toLowerCase() === 'reset') {
                            embedData.author.iconURL = null;
                        } else {
                            const imageRegex = /(http(s?):)([/|.|\w|\s|-])*\.(?:jpg|gif|png|jpeg)/;
                            if (imageRegex.test(msg.content)) {
                                embedData.author.iconURL = msg.content;
                            }
                        }
                        msg.delete().catch(() => {});
                        await messageComponent.edit({ components: [buildPreviewContainer()], flags: MessageFlags.IsComponentsV2 });
                    });
                } else if (value === 'footer_text_embed') {
                    await interaction.reply({ content: `Embed Footer Limit is 256 Characters. Please provide a Footer below 256 characters.`, flags: 64 });
                    const msgCollector = message.channel.createMessageCollector({ filter: msg => msg.author.id === message.author.id, max: 1, time: 1000 * 60 * 30 });
                    msgCollector.on('collect', async (msg) => {
                        embedData.footer.text = msg.content.slice(0, 250);
                        msg.delete().catch(() => {});
                        await messageComponent.edit({ components: [buildPreviewContainer()], flags: MessageFlags.IsComponentsV2 });
                    });
                } else if (value === 'footer_icon_embed') {
                    await interaction.reply({ content: `Please provide a valid image URL for the footer icon, or type 'reset' to remove.`, flags: 64 });
                    const msgCollector = message.channel.createMessageCollector({ filter: msg => msg.author.id === message.author.id, max: 1, time: 1000 * 60 * 30 });
                    msgCollector.on('collect', async (msg) => {
                        if (msg.content.toLowerCase() === 'reset') {
                            embedData.footer.iconURL = null;
                        } else {
                            const imageRegex = /(http(s?):)([/|.|\w|\s|-])*\.(?:jpg|gif|png|jpeg)/;
                            if (imageRegex.test(msg.content)) {
                                embedData.footer.iconURL = msg.content;
                            }
                        }
                        msg.delete().catch(() => {});
                        await messageComponent.edit({ components: [buildPreviewContainer()], flags: MessageFlags.IsComponentsV2 });
                    });
                } else if (value === 'image_embed') {
                    await interaction.reply({ content: `Please provide a valid image URL, or type 'reset' to remove.`, flags: 64 });
                    const msgCollector = message.channel.createMessageCollector({ filter: msg => msg.author.id === message.author.id, max: 1, time: 1000 * 60 * 30 });
                    msgCollector.on('collect', async (msg) => {
                        if (msg.content.toLowerCase() === 'reset') {
                            embedData.image = null;
                        } else {
                            const imageRegex = /(http(s?):)([/|.|\w|\s|-])*\.(?:jpg|gif|png|jpeg)/;
                            if (imageRegex.test(msg.content)) {
                                embedData.image = msg.content;
                            }
                        }
                        msg.delete().catch(() => {});
                        await messageComponent.edit({ components: [buildPreviewContainer()], flags: MessageFlags.IsComponentsV2 });
                    });
                } else if (value === 'thumbnail_embed') {
                    await interaction.reply({ content: `Please provide a valid thumbnail image URL, or type 'reset' to remove.`, flags: 64 });
                    const msgCollector = message.channel.createMessageCollector({ filter: msg => msg.author.id === message.author.id, max: 1, time: 1000 * 60 * 30 });
                    msgCollector.on('collect', async (msg) => {
                        if (msg.content.toLowerCase() === 'reset') {
                            embedData.thumbnail = null;
                        } else {
                            const imageRegex = /(http(s?):)([/|.|\w|\s|-])*\.(?:jpg|gif|png|jpeg)/;
                            if (imageRegex.test(msg.content)) {
                                embedData.thumbnail = msg.content;
                            }
                        }
                        msg.delete().catch(() => {});
                        await messageComponent.edit({ components: [buildPreviewContainer()], flags: MessageFlags.IsComponentsV2 });
                    });
                } else if (value === 'default_embed') {
                    embedData = {
                        title: '',
                        description: 'Improve the Embed',
                        color: client.color,
                        author: { name: '', iconURL: null },
                        footer: { text: '', iconURL: null },
                        thumbnail: null,
                        image: null
                    };
                    await interaction.reply({ content: 'The embed has been successfully reset to its default state.', flags: 64 });
                    await messageComponent.edit({ components: [buildPreviewContainer()], flags: MessageFlags.IsComponentsV2 });
                } else if (value === 'channel_send') {
                    await interaction.reply({ content: 'Please provide the ID or mention of the channel where you like to submit this embed.', flags: 64 });
                    const channelCollector = message.channel.createMessageCollector({
                        filter: (msg) => msg.author.id === message.author.id && (msg.mentions.channels.size > 0 || /^[0-9]+$/.test(msg.content)),
                        max: 1,
                        time: 1000 * 60 * 30
                    });
                    channelCollector.on('collect', async (msg) => {
                        let channelId = msg.mentions.channels.first()?.id || msg.content.trim().match(/[0-9]+/)?.[0];
                        if (!channelId || !message.guild.channels.cache.has(channelId)) {
                            await interaction.followUp({ content: 'Invalid channel ID or mention.', flags: 64 });
                        } else {
                            await msg.delete().catch(() => {});
                            const channelToSend = await message.guild.channels.fetch(channelId);
                            
                            const finalContainer = new ContainerBuilder();
                            finalContainer.setAccentColor(embedData.color);
                            if (embedData.thumbnail) {
                                finalContainer.addMediaGalleryComponents(
                                    new MediaGalleryBuilder().addItems(
                                        new MediaGalleryItemBuilder().setURL(embedData.thumbnail)
                                    )
                                );
                            }
                            if (embedData.author.name) {
                                finalContainer.addTextDisplayComponents(new TextDisplayBuilder().setContent(`**${embedData.author.name}**`));
                            }
                            if (embedData.title) {
                                finalContainer.addTextDisplayComponents(new TextDisplayBuilder().setContent(`## ${embedData.title}`));
                            }
                            finalContainer.addTextDisplayComponents(new TextDisplayBuilder().setContent(embedData.description));
                            if (embedData.image) {
                                finalContainer.addMediaGalleryComponents(
                                    new MediaGalleryBuilder().addItems(
                                        new MediaGalleryItemBuilder().setURL(embedData.image)
                                    )
                                );
                            }
                            if (embedData.footer.text) {
                                finalContainer.addSeparatorComponents(new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small));
                                finalContainer.addTextDisplayComponents(new TextDisplayBuilder().setContent(`*${embedData.footer.text}*`));
                            }
                            
                            await channelToSend.send({ components: [finalContainer], flags: MessageFlags.IsComponentsV2 });
                            
                            const sentContainer = new ContainerBuilder();
                            sentContainer.setAccentColor(client.color);
                            sentContainer.addTextDisplayComponents(new TextDisplayBuilder().setContent(`Embed Sent to <#${channelToSend.id}>`));
                            await messageComponent.edit({ components: [sentContainer], flags: MessageFlags.IsComponentsV2 });
                            cooldown.delete(message.guild.id, message.author.id);
                        }
                    });
                } else if (value === 'abort_embed') {
                    const abortContainer = new ContainerBuilder();
                    abortContainer.setAccentColor(client.color);
                    abortContainer.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`## Embed Creation Aborted`),
                        new TextDisplayBuilder().setContent('The embed creation process has been aborted. If you need assistance or have any questions, feel free to ask.')
                    );
                    await interaction.update({ components: [abortContainer], flags: MessageFlags.IsComponentsV2 });
                    cooldown.delete(message.guild.id, message.author.id);
                }
            }
        });
    }
};
