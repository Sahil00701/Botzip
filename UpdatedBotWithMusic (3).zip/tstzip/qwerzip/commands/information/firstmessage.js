const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder, 
    SeparatorSpacingSize, 
    MessageFlags 
} = require('discord.js');

module.exports = {
    name: 'firstmsg',
    aliases: ['firstmessage'],
    category: 'info',
    premium: false,

    run: async (client, message, args) => {
        const fetchMessages = await message.channel.messages.fetch({
            after: 1,
            limit: 1
        });
        const msg = fetchMessages.first();

        const container = new ContainerBuilder();
        container.setAccentColor(client.color);
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`## First Message in ${message.guild.name}`),
            new TextDisplayBuilder().setContent(`[Jump to Message](${msg.url})`)
        );
        container.addSeparatorComponents(
            new SeparatorBuilder().setDivider(true).setSpacing(SeparatorSpacingSize.Small)
        );
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`**Content:** ${msg.content || 'No content'}`),
            new TextDisplayBuilder().setContent(`**Author:** ${msg.author}`),
            new TextDisplayBuilder().setContent(`**Message ID:** ${msg.id}`),
            new TextDisplayBuilder().setContent(`**Created At:** ${message.createdAt.toLocaleDateString()}`)
        );

        message.channel.send({ 
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};
