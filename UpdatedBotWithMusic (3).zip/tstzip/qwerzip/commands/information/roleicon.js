const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    MessageFlags, 
    PermissionsBitField 
} = require('discord.js');
const axios = require("axios");

module.exports = {
    name: 'roleicon',
    category: 'info',
    premium: false,
    run: async (client, message, args) => {
        const createContainer = (content) => {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(content)
            );
            return container;
        };

        if (!message.member.permissions.has('ManageRoles')) {
            return message.channel.send({
                components: [createContainer(`${client.emoji.cross} | You must have \`Manage Roles\` permissions to use this command.`)],
                flags: MessageFlags.IsComponentsV2
            });
        }

        if (!message.guild.members.me.permissions.has('ManageRoles')) {
            return message.channel.send({
                components: [createContainer(`${client.emoji.cross} | I don't have \`Manage Roles\` permissions to execute this command.`)],
                flags: MessageFlags.IsComponentsV2
            });
        }

        if (message.author.id !== message.guild.ownerId && message.member.roles.highest.position <= message.guild.members.me.roles.highest.position) {
            return message.channel.send({
                components: [createContainer(`${client.emoji.cross} | You must have a higher role than me to use this command.`)],
                flags: MessageFlags.IsComponentsV2
            });
        }

        const premiumTier = parseInt(message.guild.premiumTier || "0");
        if (premiumTier < 2) {
            return message.channel.send({
                components: [createContainer(`${client.emoji.cross} | Your server doesn't meet the **Roleicon** requirements. Servers with level **2** boosts are allowed to set role icons.`)],
                flags: MessageFlags.IsComponentsV2
            });
        }

        if (!args[0]) {
            return message.channel.send({
                components: [createContainer(`${client.emoji.cross} | Usage: ${message.guild.prefix}roleicon <role> <emoji>`)],
                flags: MessageFlags.IsComponentsV2
            });
        }

        const role = message.mentions.roles.first() || message.guild.roles.cache.get(args[0]);
        if (!role) {
            return message.channel.send({
                components: [createContainer(`${client.emoji.cross} | Provide a valid role.`)],
                flags: MessageFlags.IsComponentsV2
            });
        }

        if (role.position >= message.guild.members.me.roles.highest.position) {
            return message.channel.send({
                components: [createContainer(`${client.emoji.cross} | ${role} is higher or equal in the role hierarchy than my highest role.`)],
                flags: MessageFlags.IsComponentsV2
            });
        }

        if (role.iconURL() && !args[1]) {
            try {
                await role.setIcon(null);
                return message.channel.send({
                    components: [createContainer(`${client.emoji.tick} | Successfully removed icon from ${role}.`)],
                    flags: MessageFlags.IsComponentsV2
                });
            } catch (err) {
                return message.channel.send({
                    components: [createContainer(`${client.emoji.cross} | An error occurred while removing the icon.`)],
                    flags: MessageFlags.IsComponentsV2
                });
            }
        }

        if (!args[1]) {
            return message.channel.send({
                components: [createContainer(`${client.emoji.cross} | Provide an emoji.`)],
                flags: MessageFlags.IsComponentsV2
            });
        }

        const emojiRegex = /<a?:\w{2,}:\d{17,20}>/g;
        const getEmojiUrl = async (emoji) => {
            if (emoji.match(emojiRegex)) {
                const emojiID = emoji.match(/:\d{17,20}>$/)[0].slice(1, -1);
                return `https://cdn.discordapp.com/emojis/${emojiID}.png`;
            } else {
                const codePoint = emoji.codePointAt(0).toString(16);
                return `https://twemoji.maxcdn.com/v/latest/72x72/${codePoint}.png`;
            }
        };

        try {
            const emojiUrl = await getEmojiUrl(args[1]);
            const response = await axios.get(emojiUrl, { responseType: 'arraybuffer' });
            await role.setIcon(response.data);
            return message.channel.send({
                components: [createContainer(`${client.emoji.tick} | Successfully set the icon for ${role}.`)],
                flags: MessageFlags.IsComponentsV2
            });
        } catch (err) {
            return message.channel.send({
                components: [createContainer(`${client.emoji.cross} | An error occurred while setting the icon.`)],
                flags: MessageFlags.IsComponentsV2
            });
        }
    }
};
