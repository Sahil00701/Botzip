const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    MessageFlags 
} = require('discord.js');

module.exports = {
    name: 'membercount',
    aliases: ['mc'],
    category: 'info',
    premium: false,

    run: async (client, message, args) => {
        const container = new ContainerBuilder();
        container.setAccentColor(client.color);
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`## Members`),
            new TextDisplayBuilder().setContent(`${message.guild.memberCount}`)
        );

        message.channel.send({ 
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};
