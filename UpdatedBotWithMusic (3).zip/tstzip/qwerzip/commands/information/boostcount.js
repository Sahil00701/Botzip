const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    MessageFlags 
} = require('discord.js');

module.exports = {
    name: 'boostcount',
    aliases: ['bc'],
    category: 'info',
    premium: false,
    run: async (client, message, args) => {
        let count = message.guild.premiumSubscriptionCount;
        
        const container = new ContainerBuilder();
        container.setAccentColor(client.color);
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`## ${message.author.displayName}`),
            new TextDisplayBuilder().setContent(`**Boost Count : ${count}**`)
        );
        
        return message.channel.send({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};
