const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    MessageFlags 
} = require('discord.js');

module.exports = {
    name: 'invite',
    aliases: ['in'],
    category: 'info',
    premium: false,

    run: async (client, message, args) => {
        const inviteUrl = `https://discord.com/api/oauth2/authorize?client_id=${client.user.id}&permissions=8&scope=bot`;
        
        const container = new ContainerBuilder();
        container.setAccentColor(client.color);
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`[Click here to invite me](${inviteUrl})`)
        );

        message.channel.send({
            components: [container],
            flags: MessageFlags.IsComponentsV2
        });
    }
};
