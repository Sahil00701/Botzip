const {
    ContainerBuilder,
    TextDisplayBuilder,
    MessageFlags
} = require('discord.js')
const { getSettingsar } = require('../../models/autorole')

module.exports = {
    name: 'welcomereset',
    category: 'welcomer',
    premium: false,

    run: async (client, message, args) => {

        const settings = await getSettingsar(message.guild)
        let response
        if (!message.member.permissions.has('Administrator')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`You must have \`Administration\` perms to run this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        let isown = message.author.id == message.guild.ownerId
        if (!isown && !client.util.hasHigher(message.member)) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have a higher role than me to use this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        let status = settings.welcome.enabled
        if (status !== true) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`The welcomer module for this server is already disabled.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        await reset(client, settings)
        const container = new ContainerBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`${client.emoji.tick} | Successfully reset the welcomer module.`)
            );
        message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }
}

async function reset(client, settings) {
    ;(settings.welcome.enabled = false),
        (settings.welcome.channel = null),
        (settings.welcome.content = null),
        (settings.welcome.autodel = 0),
        (settings.welcome.embed = {
            image: null,
            description: null,
            color: null,
            title: null,
            thumbnail: false,
            footer: null
        })
    settings.save()
}
