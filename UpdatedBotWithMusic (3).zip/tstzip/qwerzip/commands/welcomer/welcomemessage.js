const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags
} = require('discord.js')
const { getSettingsar } = require('../../models/autorole')

module.exports = {
    name: 'welcomemessage',
    aliases: ['welcomemsg'],
    category: 'welcomer',
    premium: false,

    run: async (client, message, args) => {

        const settings = await getSettingsar(message.guild)
        let response
        if (!message.member.permissions.has('Administrator')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`You must have \`Administration\` perms to run this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        let isown = message.author.id == message.guild.ownerId
        if (!isown && !client.util.hasHigher(message.member)) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have a higher role than me to use this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        if (!args[0]) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`You have to provide the required arguments.\nOptions: \`autodel\`, \`color\`, \`description\`, \`thumbnail\`, \`title\``)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        let option = args[0].toLowerCase()
        if (option == 'autodel') {
            let time = Math.round(args[1])
            if (!args[0] || isNaN(time)) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`You didn't provided valid seconds of autodelete.\nFor disabling autodel: \`0\`.\nFor autodel: \`<1 - 30>\``)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }
            if (time > 30 || time < 0) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`You didn't provided valid seconds of autodelete.\nFor disabling autodel: \`0\`.\nFor autodel: \`<1 - 30>\``)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }
            settings.welcome.autodel = time
            settings.save()
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`Updated the welcome message's auto-delete time to \`${time}s\`.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        if (option == 'color') {
            let color = args[1]
            if (!color || !client.util.isHex(color)) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`You must provide a valid hex code for welcome embed.`)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }
            settings.welcome.embed.color = color
            settings.save()
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`Updated the embed's color configuration to \`${color}\`.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        if (option == 'description') {
            if (!args[1]) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**Embed Description Variables**`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent("`{server}` - Server Name\n`{count}` - Server Members\n`{member:name}` - Member's Username\n`{member:mention}` - Member's Mention\n`{member:id}` - Member's Id\n`{member:created_at}` - Member's Account Creation Timestamp")
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }
            let desc = args.slice(1).join(' ')
            response = await client.util.setDescription(settings, desc)
        }
        if (option == 'thumbnail') {
            if (!args[1]) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`You didn't provide the status of thumnail.\nStatus: \`on\`, \`off\``)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }
            let status = args[1].toUpperCase()
            if (!['ON', 'OFF'].includes(status)) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`You didn't provide a valid status of thumbnail.\nStatus: \`on\`, \`off\``)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }
            response = await client.util.setThumbnail(settings, status)
        }
        if (option == 'title') {
            if (!args[1]) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**Embed Title Variables**`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent("`{server}` - Server Name\n`{count}` - Server Members\n`{member:name}` - Member's Username")
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }
            let title = args.slice(1).join(' ')
            response = await client.util.setTitle(settings, title)
        }
        if (option == 'image') {
            if (!args[1]) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**Embed Image**\n\nPlease Provied Valid Link`)
                    );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }
            let image = args.slice(1).join(' ')
            response = await client.util.setImage(settings, image)
        }
        const container = new ContainerBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(
                    response
                        ? response
                        : `You have to provide the required arguments.\nOptions: \`color\`, \`description\`, \`thumbnail\`, \`title\`, \`image\`, \`autodel\``
                )
            );
        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }
}
