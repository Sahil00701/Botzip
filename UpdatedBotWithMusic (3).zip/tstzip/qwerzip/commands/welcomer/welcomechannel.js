const {
    ContainerBuilder,
    TextDisplayBuilder,
    MessageFlags
} = require('discord.js')
const { getSettingsar } = require('../../models/autorole')

module.exports = {
    name: 'welcomechannel',
    category: 'welcomer',
    premium: false,

    run: async (client, message, args) => {

        const settings = await getSettingsar(message.guild)
        if (!message.member.permissions.has('Administrator')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`You must have \`Administration\` perms to run this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        let isown = message.author.id == message.guild.ownerId
        if (!isown && !client.util.hasHigher(message.member)) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have a higher role than me to use this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        let channel =
            message.mentions.channels.first() ||
            message.guild.channels.cache.get(args[0])
        if (!channel) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`You didn't mentioned the channel to set as welcome channel.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        let response = await client.util.setChannel(settings, channel)
        const container = new ContainerBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(response)
            );
        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }
}
