const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags
} = require('discord.js')
const { getSettingsar } = require('../../models/autorole')

module.exports = {
    name: 'welcome',
    aliases: ['setwelcome'],
    category: 'welcomer',
    premium: false,

    run: async (client, message, args) => {

        const settings = await getSettingsar(message.guild)
        if (!message.member.permissions.has('Administrator')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`You must have \`Administration\` perms to run this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        let isown = message.author.id == message.guild.ownerId
        if (!isown && !client.util.hasHigher(message.member)) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have a higher role than me to use this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        let status = args[0]?.toUpperCase()
        if (!status) {
            let helpContent = `**Welcome Commands**\n\n`;
            helpContent += `**\`welcome <on | off>\`** - Toggles the welcomer system for this server.\n`;
            helpContent += `**\`welcomechannel <#welcome>\`** - Toggles the channel where welcome message will be send.\n`;
            helpContent += `**\`welcomemessage <autodel | color | description | thumbnail | title>\`** - Sets the embed values according to your choice\n`;
            helpContent += `**\`welcometest\`** - Test the welcome message how it will look like.\n`;
            helpContent += `**\`welcomereset\`** - reset the welcomer module configuration.`;

            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(helpContent)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        if (!['ON', 'OFF'].includes(status)) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`You didn't provide a valid status of welcome.\nStatus: \`on\`, \`off\``)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        let response = await client.util.setStatus(settings, status)
        const container = new ContainerBuilder()
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(response)
            );
        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
    }
}
