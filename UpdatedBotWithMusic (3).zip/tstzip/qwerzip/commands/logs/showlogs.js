const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags
} = require('discord.js')

module.exports = {
    name: 'showlogs',
    aliases: ["logconfig","viewlogs"],
    category: 'logging',
    premium: false,

    run: async (client, message, args) => {
        if (!message.member.permissions.has('ManageGuild')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have \`MANAGE SERVER\` permissions to use this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        if (!message.guild.members.me.permissions.has('Administrator')) { 
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | I don't have \`Administrator\` permissions to execute this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        let data = await client.db.get(`logs_${message.guild.id}`) 

        if(!data) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Logging System Not Configured**\n\nYour server does not have a configured logging system.`)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**How to configure logging?**\nUse appropriate commands to set up logging`)
                );
            return await message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        } else if(data) {
            let logsContent = `**Server Logs Configuration**\n\n`;
            logsContent += `**Channel logs:** ${data.channel ? `<#${data.channel}>` : `\`NOT SET\``}\n`;
            logsContent += `**Role logs:** ${data.rolelog ? `<#${data.rolelog}>` : `\`NOT SET\``}\n`;
            logsContent += `**Member logs:** ${data.memberlog ? `<#${data.memberlog}>` : `\`NOT SET\``}\n`;
            logsContent += `**Mod logs:** ${data.modlog ? `<#${data.modlog}>` : `\`NOT SET\``}\n`;
            logsContent += `**Message logs:** ${data.message ? `<#${data.message}>` : `\`NOT SET\``}\n`;
            logsContent += `**Voice logs:** ${data.voice ? `<#${data.voice}>` : `\`NOT SET\``}`;

            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${message.author.tag}`)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(logsContent)
                );
            await message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
    }
}
