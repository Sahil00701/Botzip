const {
    ChannelType,
    PermissionsBitField,
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags
} = require('discord.js');
module.exports = {
    name: 'autologs',
    aliases: ['autolog'],
    cooldown: 5,
    category: 'logging',
    premium: true,

    run: async (client, message, args) => {
        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageGuild)) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have \`MANAGE SERVER\` permissions to use this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.Administrator)) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | I don't have \`Administrator\` permissions to execute this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        if (!client.util.hasHigher(message.member)) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have a higher role than me to use this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        let data = await client.db.get(`logs_${message.guild.id}`) || {
            voice: null,
            channel: null,
            rolelog: null,
            modlog: null,
            message: null,
            memberlog: null
        };

        if (data.voice || data.channel || data.rolelog || data.modlog || data.message || data.memberlog) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Logging System is Already Set Up**\n\nYour server already has a configured logging system.`)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**How to Reset Logging?**\nYou can manage logging settings using the appropriate commands.\n\n**Note**\nIf you want to set up logging again, use ${message.guild.prefix}logsreset & delete all existing log channels of Spyder`)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`Requested by ${message.author.tag}`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        try {
            let category = message.guild.channels.cache.find(c => c.type === ChannelType.GuildCategory && c.name === 'Spyder-LOGS');

            if (!category) {
                category = await message.guild.channels.create({
                    name: 'Spyder-LOGS',
                    type: ChannelType.GuildCategory,
                    permissionOverwrites: [
                        {
                            id: message.guild.id,
                            deny: [PermissionsBitField.Flags.ViewChannel]
                        }
                    ]
                });
            }

            const channels = [
                { name: 'Spyder-voicelog', topic: 'This channel logs voice-related events.' },
                { name: 'Spyder-channellog', topic: 'This channel logs channel-related events.' },
                { name: 'Spyder-rolelog', topic: 'This channel logs role-related events.' },
                { name: 'Spyder-modlog', topic: 'This channel logs moderation events.' },
                { name: 'Spyder-msglog', topic: 'This channel logs message events.' },
                { name: 'Spyder-memberlog', topic: 'This channel logs member-related events.' },
            ];

            for (const channelData of channels) {
                let check = message.guild.channels.cache.find(ch => ch.name === channelData.name && ch.parentId === category.id);

                if (check) continue;

                await message.guild.channels.create({
                    name: channelData.name,
                    type: ChannelType.GuildText,
                    topic: channelData.topic,
                    parent: category.id,
                    permissionOverwrites: [
                        {
                            id: message.guild.id,
                            deny: [PermissionsBitField.Flags.ViewChannel]
                        }
                    ],
                    reason: 'Creating logging channels as part of autologs setup.'
                });

                await client.util.sleep(1000);
            }

            // Re-fetch channels from cache or fetch if needed to ensure we have IDs
            const fetchedChannels = await message.guild.channels.fetch();
            let voicelog = fetchedChannels.find(channel => channel.name === 'Spyder-voicelog' && channel.parentId === category.id);
            let channellog = fetchedChannels.find(channel => channel.name === 'Spyder-channellog' && channel.parentId === category.id);
            let rolelog = fetchedChannels.find(channel => channel.name === 'Spyder-rolelog' && channel.parentId === category.id);
            let modlog = fetchedChannels.find(channel => channel.name === 'Spyder-modlog' && channel.parentId === category.id);
            let msglog = fetchedChannels.find(channel => channel.name === 'Spyder-msglog' && channel.parentId === category.id);
            let memberlog = fetchedChannels.find(channel => channel.name === 'Spyder-memberlog' && channel.parentId === category.id);

            await client.db.set(`logs_${message.guild.id}`, {
                voice: voicelog.id,
                channel: channellog.id,
                rolelog: rolelog.id,
                modlog: modlog.id,
                message: msglog.id,
                memberlog: memberlog.id
            });

            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Logging Channels Setup Complete**\n\nAll necessary logging channels have been successfully created under the "Spyder LOGS" category.`)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Channels Created**\n- **Spyder-modlog:** Logs moderation-related events.\n- **Spyder-memberlog:** Logs member-related events.\n- **Spyder-msglog:** Logs message-related events.\n- **Spyder-channellog:** Logs channel-related events.\n- **Spyder-voicelog:** Logs voice-related events\n- **Spyder-rolelog:** Logs role-related events.`)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Additional Configuration**\nYou can further customize logging settings and manage permissions as needed.`)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`Requested by ${message.author.tag}`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });

        } catch (error) {
            console.error('Autologs Error:', error);
            if (error.code === 429) {
                await client.util.handleRateLimit();
            }
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`An error occurred while creating logging channels: \`${error.message}\``)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
    }
};
