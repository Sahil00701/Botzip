const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags
} = require('discord.js')
module.exports = {
    name: 'logall',
    aliases: [],
    category: 'logging',
    premium: false,

    run: async (client, message, args) => {
        if (!message.member.permissions.has('ManageGuild')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have \`MANAGE SERVER\` permissions to use this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        if (!message.guild.members.me.permissions.has('Administrator')) { 
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | I don't have \`Administrator\` permissions to execute this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        if (!client.util.hasHigher(message.member)) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have a higher role than me to use this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        let channel = getChannelFromMention(message, args[0]) || message.guild.channels.cache.get(args[0])
        if(!channel){
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Invalid Channel**\n\nPlease provide a valid channel for channel logs.`)
                );
            await message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        if(channel) {
            let data = await client.db.get(`logs_${message.guild.id}`)
            if(!data){
                await client.db.set(`logs_${message.guild.id}`,{ 
                    voice : null,
                    channel : null,
                    rolelog : null,
                    modlog : null,   
                    message : null,
                    memberlog : null
                })
                const initialContainer = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent('Configuring your server...')
                    );
                const initialMessage = await message.channel.send({ components: [initialContainer], flags: MessageFlags.IsComponentsV2 });
                await client.util.sleep(2000);
                const successContainer = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**Server Configuration Successful**\n\nYour server has been successfully configured for logging.`)
                    );
                initialMessage.edit({ components: [successContainer], flags: MessageFlags.IsComponentsV2 });
            }

            if(data){
                await client.db.set(`logs_${message.guild.id}`,{ 
                    voice : channel.id,
                    channel : channel.id,
                    rolelog : channel.id,
                    modlog : channel.id,   
                    message : channel.id,
                    memberlog : channel.id
                })
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**Logging All Events Configured**\n\nThe channel ${channel} has been successfully configured for logging all types of events.`)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**Types of Logging Enabled**\n\`Message (Update, Delete)\`\n\`Member (Join, Leave, Role Update)\`\n\`Role (Create, Update, Delete)\`\n\`Channel (Create, Update, Delete)\`\n\`Modlog (Ban, Unban, Kick)\`\n\`Voice Logs (Member join,leave,move)\``)
                    )
                    .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**What happens now?**\nThe bot will log various events in the configured channel, including messages, member actions, role changes, server updates, and channel modifications.`)
                    );
                await message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }
        }
    }
}
function getChannelFromMention(message, mention) {
    if (!mention) return null;

    const matches = mention.match(/^<#(\d+)>$/); 
    if (!matches) return null;

    const channelId = matches[1];
    return message.guild.channels.cache.get(channelId);
}
