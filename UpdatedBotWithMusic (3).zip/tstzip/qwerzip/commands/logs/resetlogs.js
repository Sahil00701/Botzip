const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    StringSelectMenuBuilder,
    ActionRowBuilder,
    MessageFlags,
    ComponentType
} = require('discord.js')

module.exports = {
    name: 'logreset',
    aliases: ['resetlog','resetlogs'],
    category: 'logging',
    premium: false,

    run: async (client, message, args) => {
        if (!message.member.permissions.has('ManageGuild')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have \`MANAGE SERVER\` permissions to use this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
        if (!message.guild.members.me.permissions.has('Administrator')) { 
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | I don't have \`Administrator\` permissions to execute this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        if (!client.util.hasHigher(message.member)) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have a higher role than me to use this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
 
        let data = await client.db.get(`logs_${message.guild.id}`)
        if(data.modlog === null && data.memberlog === null && data.message === null && data.channel === null && data.rolelog === null && data.voice === null){
            await client.db.set(`logs_${message.guild.id}`,{ 
                voice : null,
                channel : null,
                rolelog : null,
                modlog : null,   
                message : null,
                memberlog : null
            })
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Logging System Not Configured**\n\nYour server does not have a configured logging system.`)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**How to configure logging?**\nUse appropriate commands to set up logging`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        } else if(data) {
            const selectMenu = new StringSelectMenuBuilder()
                .setCustomId('log_reset_confirm')
                .setPlaceholder('Select an option')
                .addOptions([
                    { label: 'Yes', value: 'confirm', description: 'Confirm reset' },
                    { label: 'No', value: 'cancel', description: 'Cancel reset' }
                ]);

            const row = new ActionRowBuilder().addComponents(selectMenu);

            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`Are you sure you want to reset the server logging module? This action will disable all logging features, and you will lose all existing log settings.`)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Note**\nThis operation is irreversible. Make sure you want to proceed before confirming.`)
                )
                .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`Select Yes or No from the dropdown below.`)
                );
            
            const confirmationMessage = await message.channel.send({
                components: [container, row],
                flags: MessageFlags.IsComponentsV2
            });

            const filter = i => i.customId === 'log_reset_confirm' && i.user.id === message.author.id;

            const collector = confirmationMessage.createMessageComponentCollector({ filter, componentType: ComponentType.StringSelect, time: 15000 });

            collector.on('collect', async i => {
                if (i.values[0] === 'confirm') {
                    await client.db.set(`logs_${message.guild.id}`, {
                        voice : null,
                        channel: null,
                        rolelog: null,
                        modlog: null,
                        message: null,
                        memberlog: null,
                    });

                    const successContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Log Reset Successful**\n\nLogging system has been successfully disabled for ${message.guild.name}.`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`You can configure logging again using the appropriate commands.`)
                        );

                    await i.update({
                        components: [successContainer],
                        flags: MessageFlags.IsComponentsV2
                    });
                } else {
                    const cancelContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Log Reset Cancelled**\n\nThe operation to reset the logging system has been cancelled.`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Why was it cancelled?**\nEither you decided not to proceed, or the interaction timed out.`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`Feel free to run the command again if needed.`)
                        );

                    await i.update({
                        components: [cancelContainer],
                        flags: MessageFlags.IsComponentsV2
                    });
                }

                collector.stop();
            });

            collector.on('end', collected => {
                if (collected.size === 0) {
                    const timeoutContainer = new ContainerBuilder()
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Log Reset Timed Out**\n\nYou took too long to respond, and the operation to reset the logging system has been cancelled.`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`**Why did it time out?**\nThe interaction timed out after 15 seconds.`)
                        )
                        .addSeparatorComponents(new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small))
                        .addTextDisplayComponents(
                            new TextDisplayBuilder().setContent(`Feel free to run the command again if needed.`)
                        );

                    confirmationMessage.edit({
                        components: [timeoutContainer],
                        flags: MessageFlags.IsComponentsV2
                    });
                }
            });
        }
    }
}
