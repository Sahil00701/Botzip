const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder,
    SeparatorSpacingSize,
    ActionRowBuilder, 
    StringSelectMenuBuilder,
    MessageFlags,
    ComponentType
} = require('discord.js');

const { default: wait } = require('wait')
module.exports = {
    name: 'lockall',
    aliases: [],
    category: 'mod',
    premium: false,
    cooldown: 60,

    run: async (client, message, args) => {
        const createMessage = (description) => {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(description)
            );
            return { components: [container], flags: MessageFlags.IsComponentsV2 };
        };

        if (!message.member.permissions.has('ManageChannles')) {
            return message.channel.send(
                createMessage(`You must have \`Manage Channels\` permission to use this command.`)
            );
        }
        if (client.util.hasHigher(message.member) == false) {
            return message.channel.send(
                createMessage(`Your highest role must be higher than my highest role to use this command.`)
            );
        }

        if(!message.guild.lockall) {
            const row = new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('lockall_select')
                    .setPlaceholder('Select an option')
                    .addOptions([
                        { label: 'Yes', description: 'Confirm locking all channels', value: 'yes_button' },
                        { label: 'No', description: 'Cancel the operation', value: 'no_button' }
                    ])
            );
            const interactionMessage = await message.channel.send(
                createMessage(`**${client.emoji.process} | Processing Command Please Wait**`)
            );
            await client.util.sleep(4000)
            await interactionMessage.edit({
                ...createMessage(`**Are you sure you want to lock all channels to in this server?**`),
                components: [row]
            });
            const filter = interaction => interaction.user.id === message.author.id;

            const collector = interactionMessage.createMessageComponentCollector({ filter, componentType: ComponentType.StringSelect, time: 10000 });

            collector.on('collect', async interaction => {
                const value = interaction.values[0];
                if (value === 'yes_button') {
                    await interactionMessage.edit({
                        ...createMessage(`${client.emoji.tick} | Successfully started locking all channnels.`),
                        components: []
                    });

                    collector.stop();
                    try {
                        message.guild.lockall = true;
                        let hided = 0
                        const channels = await message.guild.channels.fetch();
                        for (const c of channels) {
                            const channel = c[1];
                            try {
                                await client.util.sleep(2000)
                                if (channel.manageable) {
                                    await channel.permissionOverwrites.edit(message.guild.id, {
                                        SendMessages : false
                                    },{
                                        reason: `LOCKALL BY ${message.author.tag} (${message.author.id})`
                                    })
                                    hided++;
                                }
                            } catch (err) {
                                if (err.code === 429) {
                                    await client.util.handleRateLimit();
                                    return;
                                }
                            }
                        }

                        await message.channel.send(
                            createMessage(`${client.emoji.tick} | Successfully locked ${hided} channels`)
                        );
                        if (message.guild.lockall) message.guild.lockall = false;

                    } catch (err) { 
                        return;
                    }
                } else if (value === 'no_button') {
                    await interactionMessage.edit({
                        ...createMessage(`Process canceled.`),
                        components: []
                    });
                    collector.stop();
                }
            });
            collector.on('end', collected => {
                if (collected.size === 0) {
                    const container = new ContainerBuilder();
                    container.setAccentColor(client.color);
                    container.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`## Lock all Timed Out`),
                        new TextDisplayBuilder().setContent('The operation of Locking channels has been cancelled due to inactivity.'),
                        new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small),
                        new TextDisplayBuilder().setContent('**Reason for Timeout:** Your response took longer than expected, exceeding the 10-second time limit.')
                    );
                    interactionMessage.edit({
                        components: [container],
                        flags: MessageFlags.IsComponentsV2
                    });
                }
            });
        } else { 
            return message.channel.send(
                createMessage(`${client.emoji.cross} | There is already a Lock all process is going on in the server.`)
            );
        }
    }
}
