const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags 
} = require('discord.js');

module.exports = {
    name: 'media',
    aliases: ['mediachannel'],
    category: 'mod',
    premium: false,
    cooldown: 6,
    subcommands: ['channel', 'whitelist', 'channel add', 'channel remove','channel list','channel reset','whitelist role add', 'whitelist role remove', 'whitelist role reset', 'whitelist role list', 'whitelist user add', 'whitelist user remove', 'whitelist user reset', 'whitelist user list'],
    run: async (client, message, args) => {
        const createMessage = (description) => {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(description)
            );
            return { components: [container], flags: MessageFlags.IsComponentsV2 };
        };

        const createTitledMessage = (title, description) => {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## ${title}`),
                new TextDisplayBuilder().setContent(description)
            );
            return { components: [container], flags: MessageFlags.IsComponentsV2 };
        };

        try {
            if (!message.member.permissions.has('ManageGuild')) {
                return message.channel.send(
                    createMessage(`${client.emoji.cross} | You need \`MANAGE SERVER\` permissions to use this command.`)
                );
            }

            if (!message.guild.members.me.permissions.has('Administrator')) {
                return message.channel.send(
                    createMessage(`${client.emoji.cross} | I require \`ADMINISTRATOR\` permissions to execute this command.`)
                );
            }

            const category = args[0]?.toLowerCase();
            const subCategory = args[1]?.toLowerCase();
            const action = category === 'whitelist' ? args[2]?.toLowerCase() : subCategory;
            const target = args.slice(category === 'whitelist' ? 3 : 2).join(' ');

            const data = await client.db.get(`mediachannel_${message.guild.id}`) || { channel: [], role: [], user: [] };

            if (!category || !['channel', 'whitelist'].includes(category)) {
                const container = new ContainerBuilder();
                container.setAccentColor(client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`## Media Command Overview`),
                    new TextDisplayBuilder().setContent(`The \`media\` command allows you to configure media-only channels and manage whitelisted roles or users.\n\nUse the following subcommands to set up and manage media configurations.`),
                    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small),
                    new TextDisplayBuilder().setContent(`**Media Channel Commands**\nCommands for managing media-only channels.`),
                    new TextDisplayBuilder().setContent(`\`media channel add\` - Adds a media-only channel\n\`media channel remove\` - Removes a media-only channel\n\`media channel list\` - Lists all configured media-only channels\n\`media channel reset\` - Resets all media-only channels`),
                    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small),
                    new TextDisplayBuilder().setContent(`**Whitelist User Commands**\nCommands for managing whitelisted users.`),
                    new TextDisplayBuilder().setContent(`\`media whitelist user add\` - Adds a user to the whitelist\n\`media whitelist user remove\` - Removes a user from the whitelist\n\`media whitelist user list\` - Lists all whitelisted users\n\`media whitelist user reset\` - Resets all whitelisted users`),
                    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small),
                    new TextDisplayBuilder().setContent(`**Whitelist Role Commands**\nCommands for managing whitelisted roles.`),
                    new TextDisplayBuilder().setContent(`\`media whitelist role add\` - Adds a role to the whitelist\n\`media whitelist role remove\` - Removes a role from the whitelist\n\`media whitelist role list\` - Lists all whitelisted roles\n\`media whitelist role reset\` - Resets all whitelisted roles`),
                    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small),
                    new TextDisplayBuilder().setContent(`Use 'channel' or 'whitelist' as the first argument.`)
                );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            if (category === 'channel') {
                if (!action || !['add', 'remove', 'reset', 'list'].includes(action)) {
                    return message.channel.send(
                        createMessage(`${client.emoji.cross} | Invalid action! Use \`add\`, \`remove\`, \`reset\`, or \`list\`.`)
                    );
                }
                if (action === 'add') return handleAdd('channel');
                if (action === 'remove') return handleRemove('channel');
                if (action === 'reset') return handleReset('channel');
                if (action === 'list') return handleList('channel');
            }

            if (category === 'whitelist') {
                if (!subCategory || !['user', 'role'].includes(subCategory)) {
                    return message.channel.send(
                        createMessage(`${client.emoji.cross} | Specify \`role\` or \`user\` for the whitelist command.`)
                    );
                }
                
                if (subCategory === 'user') {
                    if (!action || !['add', 'remove', 'reset', 'list'].includes(action)) {
                        return message.channel.send(
                            createMessage(`${client.emoji.cross} | Invalid action! Use \`add\`, \`remove\`, \`reset\`, or \`list\`.`)
                        );
                    }
                    if (action === 'add') return handleAdd('user');
                    if (action === 'remove') return handleRemove('user');
                    if (action === 'reset') return handleReset('user');
                    if (action === 'list') return handleList('user');
                }
                if (subCategory === 'role') {
                    if (!action || !['add', 'remove', 'reset', 'list'].includes(action)) {
                        return message.channel.send(
                            createMessage(`${client.emoji.cross} | Invalid action! Use \`add\`, \`remove\`, \`reset\`, or \`list\`.`)
                        );
                    }
                    if (action === 'add') return handleAdd('role');
                    if (action === 'remove') return handleRemove('role');
                    if (action === 'reset') return handleReset('role');
                    if (action === 'list') return handleList('role');
                }
            }
                        

            async function handleAdd(type) {
                if (!target) {
                    return message.channel.send(
                        createMessage(`${client.emoji.cross} | Please specify a valid ${type === 'role' ? 'role' : type === 'user' ? 'user' : 'channel'} to add.`)
                    );
                }
            
                let targetObj;
                if (type === 'role') {
                    targetObj = getRoleFromMention(message, target) || message.guild.roles.cache.get(target);
                } else if (type === 'user') {
                    targetObj = getUserFromMention(message, target) || message.guild.members.cache.get(target);
                } else if (type === 'channel') {
                    targetObj = getChannelFromMention(message, target) || message.guild.channels.cache.get(target);
                }
            
                if (!targetObj) {
                    return message.channel.send(
                        createMessage(`${client.emoji.cross} | Please provide a valid ${type === 'role' ? 'role' : type === 'user' ? 'user' : 'channel'}.`)
                    );
                }
            
                const id = targetObj.id;
                if (data[type].includes(id)) {
                    return message.channel.send(
                        createMessage(`${client.emoji.cross} | This ${type === 'role' ? 'role' : type === 'user' ? 'user' : 'channel'} is already added.`)
                    );
                }
            
                if (type === 'channel' && data['channel'].length >= 1) {
                    const container = new ContainerBuilder();
                    container.setAccentColor(client.color);
                    container.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`${client.emoji.cross} | You can only add 1 channel.`),
                        new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small),
                        new TextDisplayBuilder().setContent(`Buy premium so you can add more channels`)
                    );
                    return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
                }
            
                if (type !== 'channel' && data[type].length >= 10) {
                    return message.channel.send(
                        createMessage(`${client.emoji.cross} | You can only add up to 10 ${type === 'role' ? 'roles' : type === 'user' ? 'users' : 'channels'}.`)
                    );
                }
            
                data[type].push(id);
                await client.db.set(`mediachannel_${message.guild.id}`, data);
            
                return message.channel.send(
                    createMessage(`${client.emoji.tick} | Successfully added the ${type === 'role' ? `role: ${targetObj.name}` : type === 'user' ? `user: ${targetObj.tag || targetObj.user.tag}` : `channel: ${targetObj.name}`}.`)
                );
            }
            
            async function handleRemove(type) {
                if (!target) {
                    return message.channel.send(
                        createMessage(`${client.emoji.cross} | Please specify a valid ${type === 'role' ? 'role' : type === 'user' ? 'user' : 'channel'} to remove.`)
                    );
                }

                let targetObj;
                if (type === 'role') {
                    targetObj = getRoleFromMention(message, target) || message.guild.roles.cache.get(target);
                } else if (type === 'user') {
                    targetObj = getUserFromMention(message, target) || message.guild.members.cache.get(target);
                } else if (type === 'channel') {
                    targetObj = getChannelFromMention(message, target) || message.guild.channels.cache.get(target);
                }

                if (!targetObj) {
                    return message.channel.send(
                        createMessage(`${client.emoji.cross} | Please provide a valid ${type === 'role' ? 'role' : type === 'user' ? 'user' : 'channel'}.`)
                    );
                }

                const id = targetObj.id;
                if (!data[type].includes(id)) {
                    return message.channel.send(
                        createMessage(`${client.emoji.cross} | This ${type === 'role' ? 'role' : type === 'user' ? 'user' : 'channel'} is not in the list.`)
                    );
                }

                data[type] = data[type].filter(item => item !== id);
                await client.db.set(`mediachannel_${message.guild.id}.${type}`, data[type]);

                return message.channel.send(
                    createMessage(`${client.emoji.tick} | Successfully removed the ${type === 'role' ? `role: ${targetObj.name}` : type === 'user' ? `user: ${targetObj.tag || targetObj.user.tag}` : `channel: ${targetObj.name}`}.`)
                );
            }

            async function handleReset(type) {
                if (!data[type].length) {
                    return message.channel.send(
                        createMessage(`${client.emoji.cross} | The ${type} list is empty.`)
                    );
                }
                data[type] = [];
                await client.db.set(`mediachannel_${message.guild.id}.${type}`, []);
                return message.channel.send(
                    createMessage(`${client.emoji.tick} | Successfully reset the ${type} list.`)
                );
            }

            async function handleList(type) {
                if (!data[type].length) {
                    return message.channel.send(
                        createMessage(`${client.emoji.cross} | The ${type} list is empty.`)
                    );
                }
            
                const list = data[type]
                    .map((id, index) => {
                        let mention;
                        if (type === 'user') {
                            mention = `<@${id}>`;
                        } else if (type === 'role') {
                            mention = `<@&${id}>`;
                        } else if (type === 'channel') {
                            mention = `<#${id}>`;
                        }
                        return `${index + 1}. ${mention} (${id})`;
                    })
                    .join('\n');
            
                let customTitle;
                if (category === 'channel') {
                    customTitle = 'Media Channel List';
                } else if (category === 'whitelist') {
                    customTitle = `Media Whitelist ${type.charAt(0).toUpperCase() + type.slice(1)} List`;
                } else {
                    customTitle = `List of ${type.charAt(0).toUpperCase() + type.slice(1)}s`;
                }
            
                return message.channel.send(
                    createTitledMessage(customTitle, list)
                );
            }
            
        } catch(err) {

        }
    }
}

function getRoleFromMention(message, mention) {
    if (!mention) return null;
    const matches = mention.match(/^<@&(\d+)>$/);
    return matches ? message.guild.roles.cache.get(matches[1]) : message.guild.roles.cache.get(mention);
}

function getUserFromMention(message, mention) {
    if (!mention) return null;
    const matches = mention.match(/^<@!?(\d+)>$/);
    return matches ? message.guild.members.cache.get(matches[1]) : message.guild.members.cache.get(mention);
}

function getChannelFromMention(message, mention) {
    if (!mention) return null;
    const matches = mention.match(/^<#(\d+)>$/);
    return matches ? message.guild.channels.cache.get(matches[1]) : message.guild.channels.cache.get(mention);
}
