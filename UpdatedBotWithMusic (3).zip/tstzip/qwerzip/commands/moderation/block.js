const {
    ContainerBuilder,
    TextDisplayBuilder,
    MessageFlags
} = require('discord.js')

module.exports = {
    name: 'block',
    aliases: [],
    category: 'mod',
    cooldown: 5,
    premium: false,

    run: async (client, message, args) => {
        const createMessage = (description) => {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(description)
            );
            return { components: [container], flags: MessageFlags.IsComponentsV2 };
        };

        if (!message.member.permissions.has('Administrator')) {
            return message.channel.send(
                createMessage(`You must have \`Administrator\` permission to use this command.`)
            );
        }
        if (!message.guild.members.me.permissions.has('Administrator')) {
            return message.channel.send(
                createMessage(`I must have \`Administrator\` permission to use this command.`)
            );
        }
        if (!args[0]) {
            return message.channel.send(
                createMessage(`${client.emoji.cross} | Please Provide Valid user ID or Mention Member To Block.`)
            );
        }
        let user = await getUserFromMention(message, args[0])
        if (!user) {
            try {
                user = await message.guild.members.cache.get(args[0])
            } catch (error) {
                return message.channel.send(
                    createMessage(`${client.emoji.cross} | Please Provide Valid user ID or Mention Member To Block.`)
                );
            }
        }
        const channel =
            message.mentions.channels.first() ||
            message.guild.channels.cache.get(args[2]) ||
            message.channel

        let isown = message.author.id == message.guild.ownerId

        if (user.id === client.user.id) {
            return message.channel.send(
                createMessage(`${client.emoji.cross} | You can't Block Me.`)
            );
        }
        if (user.id === message.guild.ownerId) {
            return message.channel.send(
                createMessage(`${client.emoji.cross} | I can't block the owner of this server.`)
            );
        }
        if (!client.util.hasHigher(message.member) && !isown) {
            return message.channel.send(
                createMessage(`${client.emoji.cross} | You must have a higher role than me to use this command.`)
            );
        }
        if(user.permissions.has("Administrator")) {
            return message.channel.send(
                createMessage(`${client.emoji.cross} | You Cannot Block The Administrator Of This Server`)
            );
        }

        channel.permissionOverwrites.edit(user.id, {
            ViewChannel : false,
            SendMessages : false,
            reason: `${message.author.tag} (${message.author.id})`
        })
        return message.channel.send(
            createMessage(`${user} has been blocked for ${channel}`)
        );
    }
}

function getUserFromMention(message, mention) {
    if (!mention) return null

    const matches = mention.match(/^<@!?(\d+)>$/)
    if (!matches) return null

    const id = matches[1]
    return message.guild.members.fetch(id)
}
