const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags 
} = require('discord.js')

module.exports = {
    name: 'modrole',
    aliases: ['moderatorrole'],
    category: 'mod',
    subcommand : ['set','view','reset'],
    premium: false,
    run: async (client, message, args) => {
        const createMessage = (description) => {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(description)
            );
            return { components: [container], flags: MessageFlags.IsComponentsV2 };
        };

        const createTitledMessage = (title, description) => {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## ${title}`),
                new TextDisplayBuilder().setContent(description)
            );
            return { components: [container], flags: MessageFlags.IsComponentsV2 };
        };

        let own = message.author.id == message.guild.ownerId
        const check = await client.util.isExtraOwner(
            message.author,
            message.guild
        )
        if (!own && !check) {
            return message.channel.send(
                createMessage(`${client.emoji.cross} | Only Server Owner Or Extra Owner Can Run This Command.!`)
            );
        }
        if (
            !own &&
            !(
                message.guild.members.cache.get(client.user.id).roles.highest
                    .position <= message.member.roles.highest.position
            )
        ) {
            return message.channel.send(
                createMessage(`${client.emoji.cross} | Only Server Owner Or Extra Owner Having Higher Role Than Me Can Run This Command`)
            );
        }

        const option = args[0]?.toLowerCase()

        const modroleInfo = `Assigning this role as the moderator role, members will gain access to a suite of powerful moderation commands:

• **Mute**: Temporarily or permanently mute disruptive members.
• **Unmute**: Restore voice permissions to previously muted members.
• **Purge**: Quickly delete a specified number of messages to keep the chat clean.
• **Nick**: Change the nicknames of server members for better organization.

**Important**: Only assign this role to members you trust completely, as they will have significant control over the server's moderation capabilities. Use these permissions responsibly to maintain a safe and friendly community.`;

        if (!option) {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## Modrole`),
                new TextDisplayBuilder().setContent(modroleInfo),
                new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small),
                new TextDisplayBuilder().setContent(`**__Modrole Set__**\nTo Set Modrole, Use - \`${message.guild.prefix}modrole set @role\``),
                new TextDisplayBuilder().setContent(`**__Modrole Reset__**\nTo Reset Modrole, Use - \`${message.guild.prefix}modrole reset\``),
                new TextDisplayBuilder().setContent(`**__Modrole View__**\nTo View Modrole, Use - \`${message.guild.prefix}modrole view\``)
            );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        } else if (option === 'set') {
            let role =
                getRoleFromMention(message, args[1]) ||
                message.guild.roles.cache.get(args[1])
            if (!role) {
                const container = new ContainerBuilder();
                container.setAccentColor(client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`## Invalid Role`),
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | Please provide a valid role to set up the mod role.`),
                    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small),
                    new TextDisplayBuilder().setContent(`Moderation Setup`)
                );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            } else if (role.managed) {
                const container = new ContainerBuilder();
                container.setAccentColor(client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`## Invalid Role`),
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | ${role} is managed by integration.`),
                    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small),
                    new TextDisplayBuilder().setContent(`Moderation Setup`)
                );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            } else {
                await client.db.set(`modrole_${message.guild.id}`, role.id)
                const container = new ContainerBuilder();
                container.setAccentColor(client.color);
                container.addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`## Role Set Successfully`),
                    new TextDisplayBuilder().setContent(`${client.emoji.tick} | The moderator role has been set up successfully.`),
                    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small),
                    new TextDisplayBuilder().setContent(`**Command Permissions**\n${modroleInfo}`),
                    new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small),
                    new TextDisplayBuilder().setContent(`Moderation Setup`)
                );
                return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }
        } else if (option === 'reset') {
            const data = await client.db.get(`modrole_${message.guild.id}`)
            if (!data) {
                return message.channel.send(
                    createMessage(`${client.emoji.cross} | There is no modrole configuration in this server.`)
                );
            } else {
                await client.db.delete(`modrole_${message.guild.id}`)
                return message.channel.send(
                    createMessage(`${client.emoji.tick} | Successfully disabled modrole configuration.`)
                );
            }
        } else if (option === 'view') {
            const data = await client.db.get(`modrole_${message.guild.id}`)
            if (!data) {
                return message.channel.send(
                    createMessage(`${client.emoji.cross} | No Modrole is set.`)
                );
            } else {
                return message.channel.send(
                    createMessage(`Current Modrole is <@&${data}>`)
                );
            }
        } else {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(`## Modrole`),
                new TextDisplayBuilder().setContent(modroleInfo),
                new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small),
                new TextDisplayBuilder().setContent(`**__Modrole Set__**\nTo Set Modrole, Use - \`${message.guild.prefix}modrole set @role\``),
                new TextDisplayBuilder().setContent(`**__Modrole Reset__**\nTo Reset Modrole, Use - \`${message.guild.prefix}modrole reset\``),
                new TextDisplayBuilder().setContent(`**__Modrole View__**\nTo View Modrole, Use - \`${message.guild.prefix}modrole view\``)
            );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
    }
}

function getRoleFromMention(message, mention) {
    if (!mention) return null

    const matches = mention.match(/^<@&(\d+)>$/)
    if (!matches) return null

    const roleId = matches[1]
    return message.guild.roles.cache.get(roleId)
}
