const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder,
    SeparatorSpacingSize,
    ActionRowBuilder, 
    StringSelectMenuBuilder,
    MessageFlags,
    ComponentType
} = require('discord.js');

const { default: wait } = require('wait')
module.exports = {
    name: 'unmuteall',
    aliases: [],
    category: 'mod',
    premium: false,
    cooldown: 60,
    run: async (client, message, args) => {
        const createMessage = (description) => {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(description)
            );
            return { components: [container], flags: MessageFlags.IsComponentsV2 };
        };

        if (!message.member.permissions.has('ModerateMembers')) {
            return message.channel.send(
                createMessage(`You must have \`Moderate Members\` permission to use this command.`)
            );
        }
        if (!message.guild.members.me.permissions.has('ModerateMembers')) {
            return message.channel.send(
                createMessage(`I must have \`Moderate Members\` permission to use this command.`)
            );
        }
        if (client.util.hasHigher(message.member) == false) {
            return message.channel.send(
                createMessage(`Your highest role must be higher than my highest role to use this command.`)
            );
        }

        let members = await message.guild.members.fetch().then(members => members.filter(member => member.isCommunicationDisabled()))
        if(members.size === 0) {
            return message.channel.send(
                createMessage(`There is No One Muted Member In Ths Server`)
            );
        }
        if(!message.guild.Unmuteall) {
            const row = new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('unmuteall_select')
                    .setPlaceholder('Select an option')
                    .addOptions([
                        { label: 'Yes', description: 'Confirm unmuting all members', value: 'yes_button' },
                        { label: 'No', description: 'Cancel the operation', value: 'no_button' }
                    ])
            );
            const interactionMessage = await message.channel.send(
                createMessage(`**${client.emoji.process} | Processing Command Please Wait**`)
            );
            await client.util.sleep(4000)
            await interactionMessage.edit({
                ...createMessage(`**Are you sure you want to unmuteall all muted members in this server?**`),
                components: [row]
            });
            const filter = interaction => interaction.user.id === message.author.id;

            const collector = interactionMessage.createMessageComponentCollector({ filter, componentType: ComponentType.StringSelect, time: 10000 });

            collector.on('collect', async interaction => {
                const value = interaction.values[0];
                if (value === 'yes_button') {
                    await interactionMessage.edit({
                        ...createMessage(`${client.emoji.tick} | Successfully started unmuting to all muted members.`),
                        components: []
                    });

                    collector.stop();
                    try {
                        message.guild.Unmuteall = true;
                        let unmuted = 0
                        const muteds = await message.guild.members.fetch().then(members => members.filter(member => member.isCommunicationDisabled()))
                        for (const m of muteds) {
                            const muted = m[1];
                            try {
                                await client.util.sleep(2000)
                                if (muted) {
                                    muted.disableCommunicationUntil(null,`Unmuteall Command Runned By ${message.author.tag} | ${message.author.id}`);
                                    unmuted++;
                                }
                            } catch (err) {
                                if (err.code === 429) {
                                    await client.util.handleRateLimit();
                                    return;
                                }
                            }
                        }
                        await message.channel.send(
                            createMessage(`${client.emoji.tick} | Successfully Unmuted ${unmuted} User's`)
                        );
                        if (message.guild.Unmuteall) message.guild.Unmuteall = false;
                    } catch (err) { 
                        return;
                    }
                } else if (value === 'no_button') {
                    await interactionMessage.edit({
                        ...createMessage(`Process canceled.`),
                        components: []
                    });
                    collector.stop();
                }
            });
            collector.on('end', collected => {
                if (collected.size === 0) {
                    const container = new ContainerBuilder();
                    container.setAccentColor(client.color);
                    container.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`## untimeout all Timed Out`),
                        new TextDisplayBuilder().setContent('The operation of removing timeout has been cancelled due to inactivity.'),
                        new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small),
                        new TextDisplayBuilder().setContent('**Reason for Timeout:** Your response took longer than expected, exceeding the 10-second time limit.')
                    );
                    interactionMessage.edit({
                        components: [container],
                        flags: MessageFlags.IsComponentsV2
                    });
                }
            });
        } else { 
            return message.channel.send(
                createMessage(`${client.emoji.cross} | There is already a Unmute all process is going on in the server.`)
            );
        }
    }
}
