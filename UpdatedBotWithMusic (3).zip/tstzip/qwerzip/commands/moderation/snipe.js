const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags,
    MediaGalleryBuilder,
    MediaGalleryItemBuilder
} = require('discord.js');

module.exports = {
    name: 'snipe',
    aliases: [],
    category: 'info',
    premium: false,

    run: async (client, message, args) => {
        const createMessage = (description) => {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(description)
            );
            return { components: [container], flags: MessageFlags.IsComponentsV2 };
        };

        if (!message.member.permissions.has('ManageMessages')) {
            return message.channel.send(
                createMessage(`You must have \`Manage Messages\` permissions to run this command.`)
            );
        }

        client.on('messageDelete', async (deletedMessage) => {
            if (deletedMessage?.author?.bot) return;

            const snipeData = {
                content: deletedMessage.content || 'No content available',
                author: deletedMessage.author.tag || 'Unknown Author',
                timestamp: deletedMessage.createdTimestamp,
                imageUrl: deletedMessage.attachments.size > 0
                    ? deletedMessage.attachments.first().url
                    : null
            };
            const insertSnipe = client.snipe.prepare('INSERT INTO snipes (guildId, channelId, content, author, timestamp, imageUrl) VALUES (?, ?, ?, ?, ?, ?)');
            insertSnipe.run(deletedMessage.guild.id, deletedMessage.channel.id, snipeData.content, snipeData.author, snipeData.timestamp, snipeData.imageUrl);
        });

        const getLastSnipe = client.snipe.prepare('SELECT * FROM snipes WHERE guildId = ? AND channelId = ? ORDER BY timestamp DESC LIMIT 1');
        const snipe = getLastSnipe.get(message.guild.id, message.channel.id);

        if (!snipe) {
            return message.channel.send(
                createMessage(`There are no deleted messages.`)
            );
        }

        const container = new ContainerBuilder();
        container.setAccentColor(client.color);
        container.addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`## Sniped Message`),
            new TextDisplayBuilder().setContent(`**Author:** ${snipe.author}`),
            new TextDisplayBuilder().setContent(`**Timestamp:** ${new Date(snipe.timestamp).toLocaleString()}`)
        );
        
        if (snipe.content) {
            container.addTextDisplayComponents(
                new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small),
                new TextDisplayBuilder().setContent(`**Content:**\n${snipe.content}`)
            );
        }
        
        if (snipe.imageUrl) {
            container.addSeparatorComponents(
                new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small)
            );
            container.addMediaGalleryComponents(
                new MediaGalleryBuilder().addItems(
                    new MediaGalleryItemBuilder().setURL(snipe.imageUrl)
                )
            );
        }

        return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
    },
};
