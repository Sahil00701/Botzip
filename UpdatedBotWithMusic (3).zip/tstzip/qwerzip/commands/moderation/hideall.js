const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    SeparatorBuilder,
    SeparatorSpacingSize,
    ActionRowBuilder, 
    StringSelectMenuBuilder,
    MessageFlags,
    ComponentType
} = require('discord.js');

const { default: wait } = require('wait')
module.exports = {
    name: 'hideall',
    aliases: [],
    category: 'mod',
    premium: false,
    cooldown: 60,

    run: async (client, message, args) => {
        const createMessage = (description) => {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(description)
            );
            return { components: [container], flags: MessageFlags.IsComponentsV2 };
        };

        if (!message.member.permissions.has('ManageChannels')) {
            return message.channel.send(
                createMessage(`You must have \`Manage Channels\` permission to use this command.`)
            );
        }
        if (client.util.hasHigher(message.member) == false) {
            return message.channel.send(
                createMessage(`Your highest role must be higher than my highest role to use this command.`)
            );
        }
        let role = findMatchingRoles(message.guild, args.slice(1).join(' ')) || message.guild.roles.everyone
        if(!message.guild.Hideall) {
            const row = new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('hideall_select')
                    .setPlaceholder('Select an option')
                    .addOptions([
                        { label: 'Yes', description: 'Confirm hiding all channels', value: 'yes_button' },
                        { label: 'No', description: 'Cancel the operation', value: 'no_button' }
                    ])
            );
            const interactionMessage = await message.channel.send(
                createMessage(`**${client.emoji.process} | Processing Command Please Wait**`)
            );
            await client.util.sleep(4000)
            await interactionMessage.edit({
                ...createMessage(`**Are you sure you want to hide all channels to in this server?**`),
                components: [row]
            });
            const filter = interaction => interaction.user.id === message.author.id;

            const collector = interactionMessage.createMessageComponentCollector({ filter, componentType: ComponentType.StringSelect, time: 10000 });

            collector.on('collect', async interaction => {
                const value = interaction.values[0];
                if (value === 'yes_button') {
                    await interactionMessage.edit({
                        ...createMessage(`${client.emoji.tick} | Successfully started hiding to all channnels.`),
                        components: []
                    });

                    collector.stop();
                    try {
                        message.guild.Hideall = true;
                        let hided = 0
                        const channels = await message.guild.channels.fetch();
                        for (const c of channels) {
                            const channel = c[1];
                            try {
                                await client.util.sleep(1000)
                                if (channel.manageable) {
                                    await channel.permissionOverwrites.edit(message.guild.id, {
                                        ViewChannel : false },{
                                        reason: `HIDEALL BY ${message.author.tag} (${message.author.id})`
                                    })
                                    hided++;
                                }
                            } catch (err) {
                                if (err.code === 429) {
                                    await client.util.handleRateLimit();
                                    return;
                                }
                            }
                        }

                        await message.channel.send(
                            createMessage(`${client.emoji.tick} | Successfully hidden ${hided} channels`)
                        );
                        if (message.guild.Hideall) message.guild.Hideall = false;

                    } catch (err) { 
                        return;
                    }
                } else if (value === 'no_button') {
                    await interactionMessage.edit({
                        ...createMessage(`Process canceled.`),
                        components: []
                    });
                    collector.stop();
                }
            });
            collector.on('end', collected => {
                if (collected.size === 0) {
                    const container = new ContainerBuilder();
                    container.setAccentColor(client.color);
                    container.addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`## Hide all Timed Out`),
                        new TextDisplayBuilder().setContent('The operation of Hidding channels has been cancelled due to inactivity.'),
                        new SeparatorBuilder().setSpacing(SeparatorSpacingSize.Small),
                        new TextDisplayBuilder().setContent('**Reason for Timeout:** Your response took longer than expected, exceeding the 10-second time limit.')
                    );
                    interactionMessage.edit({
                        components: [container],
                        flags: MessageFlags.IsComponentsV2
                    });
                }
            });
        } else { 
            return message.channel.send(
                createMessage(`${client.emoji.cross} | There is already a Hide all process is going on in the server.`)
            );
        }
    }
}

function findMatchingRoles(guild, query) {
    const ROLE_MENTION = /<?@?&?(\d{17,20})>?/
    if (!guild || !query || typeof query !== 'string') return []

    const patternMatch = query.match(ROLE_MENTION)
    if (patternMatch) {
        const id = patternMatch[1]
        const role = guild.roles.cache.find((r) => r.id === id)
        if (role) return [role]
    }

    const exact = []
    const startsWith = []
    const includes = []
    guild.roles.cache.forEach((role) => {
        const lowerName = role.name.toLowerCase()
        if (role.name === query) exact.push(role)
        if (lowerName.startsWith(query.toLowerCase())) startsWith.push(role)
        if (lowerName.includes(query.toLowerCase())) includes.push(role)
    })
    if (exact.length > 0) return exact
    if (startsWith.length > 0) return startsWith
    if (includes.length > 0) return includes
    return []
}
