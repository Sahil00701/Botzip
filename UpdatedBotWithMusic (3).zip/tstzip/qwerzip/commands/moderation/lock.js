const {
    ContainerBuilder,
    TextDisplayBuilder,
    MessageFlags,
    PermissionsBitField
} = require('discord.js');

module.exports = {
    name: 'lock',
    category: 'mod',
    premium: false,

    run: async (client, message, args) => {
        const createMessage = (description) => {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(description)
            );
            return { components: [container], flags: MessageFlags.IsComponentsV2 };
        };

        if (!message.member.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
            return message.channel.send(
                createMessage('You must have `Manage Channels` permission to use this command.')
            );
        }

        if (!message.guild.members.me.permissions.has(PermissionsBitField.Flags.ManageChannels)) {
            return message.channel.send(
                createMessage('I must have `Manage Channels` permission to use this command.')
            );
        }

        const channel =
            message.mentions.channels.first() ||
            message.guild.channels.cache.get(args[0]) ||
            message.channel;

        if (channel.manageable) {
            try {
                await channel.permissionOverwrites.edit(message.guild.id, {
                    SendMessages : false },{
                    reason: `${message.author.tag} (${message.author.id})`
                });
                return message.channel.send(
                    createMessage(`${channel} has been locked for @everyone role`)
                );
            } catch (error) {
                return message.channel.send(
                    createMessage('An error occurred while trying to lock the channel.')
                );
            }
        } else {
            return message.channel.send(
                createMessage('I don\'t have adequate permissions to lock this channel.')
            );
        }
    }
};
