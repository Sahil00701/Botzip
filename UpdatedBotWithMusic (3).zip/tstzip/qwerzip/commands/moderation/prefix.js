const { 
    ContainerBuilder, 
    TextDisplayBuilder, 
    MessageFlags 
} = require('discord.js')

module.exports = {
    name: 'prefix',
    aliases: ['setprefix'],
    category: 'mod',
    premium: false,

    run: async (client, message, args) => {
        const createMessage = (description) => {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(description)
            );
            return { components: [container], flags: MessageFlags.IsComponentsV2 };
        };

        if (!message.member.permissions.has('Administrator')) {
            return message.channel.send(
                createMessage('You must have `Administrator` perms to change the prefix of this server.')
            );
        }
        if (!args[0]) {
            return message.channel.send(
                createMessage(`You didn't provided the new prefix.`)
            );
        }
        if (args[1]) {
            return message.channel.send(
                createMessage('You can not set prefix a double argument')
            );
        }
        if (args[0].length > 3) {
            return message.channel.send(
                createMessage('You can not send prefix more than 3 characters')
            );
        }
        if (args.join('') === '&') {
            client.db.delete(`prefix_${message.guild.id}`)
            return await message.channel.send(
                createMessage('Reseted Prefix')
            );
        }

        await client.db.set(`prefix_${message.guild.id}`, args[0])
        client.util.setPrefix(message, client)
        await message.channel.send(
            createMessage(`New Prefix For This Server Is ${args[0]}`)
        );
    }
}
