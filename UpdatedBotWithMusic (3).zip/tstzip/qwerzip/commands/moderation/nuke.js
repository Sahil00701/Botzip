const {
    ContainerBuilder,
    TextDisplayBuilder,
    ActionRowBuilder,
    StringSelectMenuBuilder,
    MessageFlags,
    ComponentType
} = require('discord.js')

module.exports = {
    name: 'nuke',
    category: 'mod',
    premium: false,

    run: async (client, message, args) => {
        const createMessage = (description) => {
            const container = new ContainerBuilder();
            container.setAccentColor(client.color);
            container.addTextDisplayComponents(
                new TextDisplayBuilder().setContent(description)
            );
            return { components: [container], flags: MessageFlags.IsComponentsV2 };
        };

        if (!message.member.permissions.has('ManageChannels')) {
            return message.channel.send(
                createMessage(`You must have \`Manage Channels\` permission to use this command.`)
            );
        }
        if (!client.util.hasHigher(message.member)) {
            return message.channel.send(
                createMessage(`Your highest role must be higher than my highest role to use this command.`)
            );
        }
        try {
            const row = new ActionRowBuilder().addComponents(
                new StringSelectMenuBuilder()
                    .setCustomId('nuke_select')
                    .setPlaceholder('Select an option')
                    .addOptions([
                        {
                            label: 'Yes',
                            description: 'Confirm nuking this channel',
                            value: 'YES',
                        },
                        {
                            label: 'No',
                            description: 'Cancel the nuke operation',
                            value: 'NO',
                        },
                    ])
            );
            
            let msg = await message.channel.send({
                ...createMessage(`Are you sure that you want to nuke this channel?`),
                components: [row]
            });
            
            const filter = (interaction) => {
                if (interaction.user.id === message.author.id) return true
                return interaction.reply({
                    content: `Only ${message.author.username} can use this menu`,
                    flags: 64
                })
            }
            const collector = message.channel.createMessageComponentCollector({
                filter,
                componentType: ComponentType.StringSelect,
                max: 1,
                time: 30000
            })

            collector.on('collect', async (selectInteraction) => {
                await selectInteraction.deferUpdate();
                const value = selectInteraction.values[0];
                if (value === 'YES') {
                    message.channel.clone().then((ch) => {
                        let reason = args.join(' ') || 'No Reason'
                        ch.setParent(message.channel.parent)
                        ch.setPosition(message.channel.position)
                        message.channel.delete().then(() => {
                            ch.send(
                                createMessage('**Channel Successfully Nuked**\nhttps://tenor.com/view/explosion-boom-iron-man-gif-14282225')
                            ).then((msg) => {
                                setTimeout(() => msg.delete(), 10000)
                            })
                        })
                    })
                }
                if (value === 'NO') {
                    msg.delete().catch((e) => {})
                }
            })
        } catch (err) {
            return message.channel.send(
                createMessage(`I was unable to nuke this channel.`)
            );
        }
    }
}
