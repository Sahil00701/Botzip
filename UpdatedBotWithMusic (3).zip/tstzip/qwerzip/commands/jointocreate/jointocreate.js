const { 
    ChannelType,
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    StringSelectMenuBuilder,
    ActionRowBuilder,
    MessageFlags,
    ComponentType
} = require('discord.js');
const GuildConfig = require('../../models/guildconfig');

module.exports = {
    name: 'jointocreate',
    aliases: ['jtc', 'vcgen'],
    category: 'jointocreate',
    subcommand : ['setup','view','reset'],
    premium: false,
    run: async (client, message, args) => {
        if (!message.member.permissions.has('Administrator')) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have \`Administrator\` permissions to use this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        if (!message.guild.members.me.permissions.has('Administrator')) { 
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | I don't have \`Administrator\` permissions to execute this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        if (!client.util.hasHigher(message.member)) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`${client.emoji.cross} | You must have a higher role than me to use this command.`)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        const prefix = '&' || message.guild.prefix;
        const option = args[0];

        let infoContent = `**__Join To Create (4)__**\n\n`;
        infoContent += `**Join To Create** - Configures the voice channel generation system.\n`;
        infoContent += `**__jointocreate setup__** - Sets up the voice channel generator in the server.\n`;
        infoContent += `**__jointocreate reset__** - Disables the voice channel generator in the server.\n`;
        infoContent += `**__jointocreate view__** - Displays the current voice channel generator configuration.`;

        if (!option) {
            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(infoContent)
                );
            return message.channel.send({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        if (option.toLowerCase() === 'setup') {
            const existingConfig = await GuildConfig.findOne({ guildId: message.guild.id });
            if (existingConfig) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**Setup Already Completed**\n\nThe setup process has already been completed for this server.`)
                    );
                return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            const category = await message.guild.channels.create({
                name : "Spyder Temporary Voice Channels",
                type: ChannelType.GuildCategory
            });

            const hubChannel = await message.guild.channels.create({
                name : "Join To Create",
                type: ChannelType.GuildVoice,
                parent: category.id
            });

            const interfaceChannel = await message.guild.channels.create({
                name : "Spyder Voice InterFace",
                type: ChannelType.GuildText,
                parent: category.id
            });

            await GuildConfig.findOneAndUpdate(
                { guildId: message.guild.id },
                { guildId: message.guild.id, hubChannelId: hubChannel.id, categoryId: category.id, interfaceChannelId: interfaceChannel.id },
                { upsert: true }
            );

            const selectMenu1 = new StringSelectMenuBuilder()
                .setCustomId('jtc_controls_1')
                .setPlaceholder('Select an action')
                .addOptions([
                    { label: 'Transfer Ownership', value: 'transferownership', description: 'Transfer channel ownership' },
                    { label: 'Change Region', value: 'changeregion', description: 'Change voice region' },
                    { label: 'Change Bitrate', value: 'changebitrate', description: 'Change channel bitrate' },
                    { label: 'User Limit', value: 'userlimit', description: 'Set user limit' },
                    { label: 'Channel Name', value: 'channelname', description: 'Change channel name' }
                ]);

            const selectMenu2 = new StringSelectMenuBuilder()
                .setCustomId('jtc_controls_2')
                .setPlaceholder('Select visibility action')
                .addOptions([
                    { label: 'Lock', value: 'lock', description: 'Lock the channel' },
                    { label: 'Unlock', value: 'unlock', description: 'Unlock the channel' },
                    { label: 'Hide', value: 'hide', description: 'Hide the channel' },
                    { label: 'Unhide', value: 'unhide', description: 'Unhide the channel' }
                ]);

            const selectMenu3 = new StringSelectMenuBuilder()
                .setCustomId('jtc_controls_3')
                .setPlaceholder('Select moderation action')
                .addOptions([
                    { label: 'VC Mute', value: 'vcmute', description: 'Mute a user' },
                    { label: 'VC Unmute', value: 'vcunmute', description: 'Unmute a user' },
                    { label: 'VC Deafen', value: 'vcdeaf', description: 'Deafen a user' },
                    { label: 'VC Undeafen', value: 'vcundeaf', description: 'Undeafen a user' },
                    { label: 'VC Ban', value: 'vcban', description: 'Ban a user from VC' },
                    { label: 'VC Kick', value: 'vckick', description: 'Kick a user from VC' }
                ]);

            const row1 = new ActionRowBuilder().addComponents(selectMenu1);
            const row2 = new ActionRowBuilder().addComponents(selectMenu2);
            const row3 = new ActionRowBuilder().addComponents(selectMenu3);

            const controlsContainer = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent('**Voice Channel Controls**\n\nUse the dropdown menus below to control your voice channel.')
                );

            await interfaceChannel.send({
                components: [controlsContainer, row1, row2, row3],
                flags: MessageFlags.IsComponentsV2
            });

            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Setup Complete**\n\nThe setup is complete. Created category: **${category.name}**, hub channel: **${hubChannel.name}**, and interface channel: **${interfaceChannel.name}**.`)
                );
            return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }

        if (option.toLowerCase() === 'reset') {
            const config = await GuildConfig.findOne({ guildId: message.guild.id });
            if (!config) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**No Configuration Found**\n\nNo configuration was found for this server.`)
                    );
                return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            try {
                const category = message.guild.channels.cache.get(config.categoryId);
                if (category) await category.delete();

                const hubChannel = message.guild.channels.cache.get(config.hubChannelId);
                if (hubChannel) await hubChannel.delete();

                const interfaceChannel = message.guild.channels.cache.get(config.interfaceChannelId);
                if (interfaceChannel) await interfaceChannel.delete();

                await GuildConfig.deleteOne({ guildId: message.guild.id });

                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**Reset Complete**\n\nThe configuration has been reset and the channels have been deleted.`)
                    );
                return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
            } catch (error) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**Error**\n\nAn error occurred while resetting the configuration.`)
                    );
                return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }
        }

        if (option.toLowerCase() === 'view') {
            const config = await GuildConfig.findOne({ guildId: message.guild.id });
            if (!config) {
                const container = new ContainerBuilder()
                    .addTextDisplayComponents(
                        new TextDisplayBuilder().setContent(`**No Configuration Found**\n\nNo configuration was found for this server.`)
                    );
                return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
            }

            const container = new ContainerBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(`**Current Configuration**\n\nCategory ID: <#${config.categoryId}> (${config.categoryId})\nHub Channel ID: <#${config.hubChannelId}> (${config.hubChannelId})\nInterface Channel ID: <#${config.interfaceChannelId}> (${config.interfaceChannelId})`)
                );
            return message.reply({ components: [container], flags: MessageFlags.IsComponentsV2 });
        }
    }
};
