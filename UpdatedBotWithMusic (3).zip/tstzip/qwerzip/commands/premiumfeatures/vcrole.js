const {
    ContainerBuilder,
    TextDisplayBuilder,
    MessageFlags
} = require('discord.js');
const { VCRole } = require('../../models/premiumFeatures');

module.exports = {
    name: 'vcrole',
    aliases: ['voicerole', 'vcr'],
    category: 'premiumfeatures',
    premium: true, // Premium-only command
    run: async (client, message, args) => {
        // Permission check
        if (!message.member.permissions.has('Administrator')) {
            return message.channel.send(client.util.createMessage(
                `${client.emoji.cross} | You must have \`Administrator\` permissions to use this command.`
            ));
        }

        // PREMIUM GATE
        const isPremium = await client.util.CheckPremium(message.guild);
        if (!isPremium) {
            return message.channel.send(client.util.createMessage(
                `${client.emoji.cross} | This is a **premium-only** feature. Upgrade your server to access VC roles!`,
                0xff0000
            ));
        }

        const subcommand = args[0]?.toLowerCase();

        // Show help if no subcommand
        if (!subcommand) {
            const helpContent = `**VC Role System** ${client.emoji.tick}\n\n` +
                `Automatically assign a role to members when they join voice channels.\n\n` +
                `**Commands:**\n` +
                `\`vcrole setup <role>\` - Enable and set the VC role\n` +
                `\`vcrole config\` - View current configuration\n` +
                `\`vcrole disable\` - Disable the system`;
            
            return message.channel.send(client.util.createMessage(helpContent, client.color));
        }

        // Setup command
        if (subcommand === 'setup') {
            const role = message.mentions.roles.first() || 
                         message.guild.roles.cache.get(args[1]) || 
                         message.guild.roles.cache.find(r => r.name.toLowerCase() === args.slice(1).join(' ').toLowerCase());

            if (!role) {
                return message.channel.send(client.util.createMessage(
                    `${client.emoji.cross} | Please provide a valid role.\n\n**Usage:** \`vcrole setup @RoleName\``
                ));
            }

            // Check if bot can manage this role
            if (role.position >= message.guild.members.me.roles.highest.position) {
                return message.channel.send(client.util.createMessage(
                    `${client.emoji.cross} | I cannot manage this role. Please move my role above **${role.name}**.`
                ));
            }

            let config = await VCRole.findOne({ guildId: message.guild.id });
            if (!config) {
                config = await VCRole.create({
                    guildId: message.guild.id,
                    enabled: true,
                    vcRole: role.id
                });
            } else {
                config.enabled = true;
                config.vcRole = role.id;
                await config.save();
            }

            return message.channel.send(client.util.createMessage(
                `${client.emoji.tick} | VC Role system has been **enabled**!\n\n` +
                `**Role:** ${role}\n\n` +
                `Members will now receive this role when they join a voice channel.`,
                0x00ff00
            ));
        }

        // Config command
        if (subcommand === 'config') {
            const config = await VCRole.findOne({ guildId: message.guild.id });
            if (!config) {
                return message.channel.send(client.util.createMessage(
                    `${client.emoji.cross} | VC Role system is not set up. Use \`vcrole setup <role>\` first.`
                ));
            }

            const vcRole = config.vcRole ? `<@&${config.vcRole}>` : '*Not set*';

            const configContent = `**VC Role Configuration**\n\n` +
                `**Status:** ${config.enabled ? '✅ Enabled' : '❌ Disabled'}\n` +
                `**VC Role:** ${vcRole}`;

            return message.channel.send(client.util.createMessage(configContent, client.color));
        }

        // Disable command
        if (subcommand === 'disable') {
            const config = await VCRole.findOne({ guildId: message.guild.id });
            if (!config || !config.enabled) {
                return message.channel.send(client.util.createMessage(
                    `${client.emoji.cross} | VC Role system is not enabled.`
                ));
            }

            config.enabled = false;
            await config.save();

            return message.channel.send(client.util.createMessage(
                `${client.emoji.tick} | VC Role system has been **disabled**.`,
                0xff0000
            ));
        }

        // Invalid subcommand
        return message.channel.send(client.util.createMessage(
            `${client.emoji.cross} | Invalid subcommand. Use \`vcrole\` to see available commands.`
        ));
    }
};
