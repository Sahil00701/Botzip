const {
    ContainerBuilder,
    TextDisplayBuilder,
    MessageFlags
} = require('discord.js');
const { VanityStatus } = require('../../models/premiumFeatures');

module.exports = {
    name: 'vanitystatus',
    aliases: ['vanity', 'vanitycheck'],
    category: 'premiumfeatures',
    premium: true, // Premium-only command
    run: async (client, message, args) => {
        // Permission check
        if (!message.member.permissions.has('Administrator')) {
            return message.channel.send(client.util.createMessage(
                `${client.emoji.cross} | You must have \`Administrator\` permissions to use this command.`
            ));
        }

        // PREMIUM GATE
        const isPremium = await client.util.CheckPremium(message.guild);
        if (!isPremium) {
            return message.channel.send(client.util.createMessage(
                `${client.emoji.cross} | This is a **premium-only** feature. Upgrade your server to access vanity status roles!`,
                0xff0000
            ));
        }

        const subcommand = args[0]?.toLowerCase();

        // Show help if no subcommand
        if (!subcommand) {
            const helpContent = `**Vanity Status Role System** ${client.emoji.tick}\n\n` +
                `Automatically assign a role when members add your vanity code to their custom status.\n\n` +
                `**Commands:**\n` +
                `\`vanitystatus setup <vanity> <role>\` - Enable and configure the system\n` +
                `\`vanitystatus logchannel <#channel>\` - Set logging channel\n` +
                `\`vanitystatus config\` - View current configuration\n` +
                `\`vanitystatus disable\` - Disable the system\n\n` +
                `**Example:**\n` +
                `\`vanitystatus setup .gg/myserver @Official\``;
            
            return message.channel.send(client.util.createMessage(helpContent, client.color));
        }

        // Setup command
        if (subcommand === 'setup') {
            // Format: vanitystatus setup <vanityCode> <role>
            if (args.length < 3) {
                return message.channel.send(client.util.createMessage(
                    `${client.emoji.cross} | Invalid usage.\n\n**Usage:** \`vanitystatus setup <vanity> @RoleName\`\n` +
                    `**Example:** \`vanitystatus setup .gg/myserver @Official\``
                ));
            }

            const vanityCode = args[1];
            const role = message.mentions.roles.first() || 
                         message.guild.roles.cache.get(args[2]) || 
                         message.guild.roles.cache.find(r => r.name.toLowerCase() === args.slice(2).join(' ').toLowerCase());

            if (!role) {
                return message.channel.send(client.util.createMessage(
                    `${client.emoji.cross} | Please provide a valid role.`
                ));
            }

            // Check if bot can manage this role
            if (role.position >= message.guild.members.me.roles.highest.position) {
                return message.channel.send(client.util.createMessage(
                    `${client.emoji.cross} | I cannot manage this role. Please move my role above **${role.name}**.`
                ));
            }

            let config = await VanityStatus.findOne({ guildId: message.guild.id });
            if (!config) {
                config = await VanityStatus.create({
                    guildId: message.guild.id,
                    enabled: true,
                    vanityCode: vanityCode,
                    officialRole: role.id
                });
            } else {
                config.enabled = true;
                config.vanityCode = vanityCode;
                config.officialRole = role.id;
                await config.save();
            }

            return message.channel.send(client.util.createMessage(
                `${client.emoji.tick} | Vanity Status system has been **enabled**!\n\n` +
                `**Vanity Code:** \`${vanityCode}\`\n` +
                `**Official Role:** ${role}\n\n` +
                `Members with this code in their status will automatically receive the role.`,
                0x00ff00
            ));
        }

        // Set log channel
        if (subcommand === 'logchannel') {
            const channel = message.mentions.channels.first() || 
                           message.guild.channels.cache.get(args[1]);

            if (!channel || channel.type !== 0) { // Type 0 = Text channel
                return message.channel.send(client.util.createMessage(
                    `${client.emoji.cross} | Please provide a valid text channel.\n\n**Usage:** \`vanitystatus logchannel #channel\``
                ));
            }

            const config = await VanityStatus.findOne({ guildId: message.guild.id });
            if (!config) {
                return message.channel.send(client.util.createMessage(
                    `${client.emoji.cross} | Vanity Status system is not set up. Use \`vanitystatus setup\` first.`
                ));
            }

            config.logChannel = channel.id;
            await config.save();

            return message.channel.send(client.util.createMessage(
                `${client.emoji.tick} | Log channel set to ${channel}\n\nVanity additions/removals will be logged there.`,
                0x00ff00
            ));
        }

        // Config command
        if (subcommand === 'config') {
            const config = await VanityStatus.findOne({ guildId: message.guild.id });
            if (!config) {
                return message.channel.send(client.util.createMessage(
                    `${client.emoji.cross} | Vanity Status system is not set up. Use \`vanitystatus setup\` first.`
                ));
            }

            const officialRole = config.officialRole ? `<@&${config.officialRole}>` : '*Not set*';
            const logChannel = config.logChannel ? `<#${config.logChannel}>` : '*Not set*';

            const configContent = `**Vanity Status Configuration**\n\n` +
                `**Status:** ${config.enabled ? '✅ Enabled' : '❌ Disabled'}\n` +
                `**Vanity Code:** \`${config.vanityCode}\`\n` +
                `**Official Role:** ${officialRole}\n` +
                `**Log Channel:** ${logChannel}`;

            return message.channel.send(client.util.createMessage(configContent, client.color));
        }

        // Disable command
        if (subcommand === 'disable') {
            const config = await VanityStatus.findOne({ guildId: message.guild.id });
            if (!config || !config.enabled) {
                return message.channel.send(client.util.createMessage(
                    `${client.emoji.cross} | Vanity Status system is not enabled.`
                ));
            }

            config.enabled = false;
            await config.save();

            return message.channel.send(client.util.createMessage(
                `${client.emoji.tick} | Vanity Status system has been **disabled**.`,
                0xff0000
            ));
        }

        // Invalid subcommand
        return message.channel.send(client.util.createMessage(
            `${client.emoji.cross} | Invalid subcommand. Use \`vanitystatus\` to see available commands.`
        ));
    }
};
