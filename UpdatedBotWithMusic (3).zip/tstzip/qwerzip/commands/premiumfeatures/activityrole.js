const {
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SeparatorSpacingSize,
    MessageFlags
} = require('discord.js');
const { ActivityRole } = require('../../models/premiumFeatures');

module.exports = {
    name: 'activityrole',
    aliases: ['actrole', 'activerole'],
    category: 'premiumfeatures',
    premium: true, // Premium-only command
    run: async (client, message, args) => {
        // Permission check
        if (!message.member.permissions.has('Administrator')) {
            return message.channel.send(client.util.createMessage(
                `${client.emoji.cross} | You must have \`Administrator\` permissions to use this command.`
            ));
        }

        // PREMIUM GATE
        const isPremium = await client.util.CheckPremium(message.guild);
        if (!isPremium) {
            return message.channel.send(client.util.createMessage(
                `${client.emoji.cross} | This is a **premium-only** feature. Upgrade your server to access activity roles!`,
                0xff0000
            ));
        }

        const subcommand = args[0]?.toLowerCase();

        // Show help if no subcommand
        if (!subcommand) {
            const helpContent = `**Activity Role System** ${client.emoji.tick}\n\n` +
                `Automatically assign roles based on member activities.\n\n` +
                `**Commands:**\n` +
                `\`activityrole setup\` - Enable the system\n` +
                `\`activityrole spotify <role>\` - Set role for Spotify listeners\n` +
                `\`activityrole gaming <role>\` - Set role for gamers\n` +
                `\`activityrole streaming <role>\` - Set role for streamers\n` +
                `\`activityrole config\` - View current configuration\n` +
                `\`activityrole disable\` - Disable the system`;
            
            return message.channel.send(client.util.createMessage(helpContent, client.color));
        }

        // Setup command
        if (subcommand === 'setup') {
            let config = await ActivityRole.findOne({ guildId: message.guild.id });
            if (!config) {
                config = await ActivityRole.create({
                    guildId: message.guild.id,
                    enabled: true
                });
            } else {
                config.enabled = true;
                await config.save();
            }

            return message.channel.send(client.util.createMessage(
                `${client.emoji.tick} | Activity Role system has been **enabled**!\n\nNow configure roles using:\n` +
                `• \`activityrole spotify <role>\`\n` +
                `• \`activityrole gaming <role>\`\n` +
                `• \`activityrole streaming <role>\``,
                0x00ff00
            ));
        }

        // Disable command
        if (subcommand === 'disable') {
            const config = await ActivityRole.findOne({ guildId: message.guild.id });
            if (!config || !config.enabled) {
                return message.channel.send(client.util.createMessage(
                    `${client.emoji.cross} | Activity Role system is not enabled.`
                ));
            }

            config.enabled = false;
            await config.save();

            return message.channel.send(client.util.createMessage(
                `${client.emoji.tick} | Activity Role system has been **disabled**.`,
                0xff0000
            ));
        }

        // Config command
        if (subcommand === 'config') {
            const config = await ActivityRole.findOne({ guildId: message.guild.id });
            if (!config) {
                return message.channel.send(client.util.createMessage(
                    `${client.emoji.cross} | Activity Role system is not set up. Use \`activityrole setup\` first.`
                ));
            }

            const spotifyRole = config.spotifyRole ? `<@&${config.spotifyRole}>` : '*Not set*';
            const gamingRole = config.gamingRole ? `<@&${config.gamingRole}>` : '*Not set*';
            const streamingRole = config.streamingRole ? `<@&${config.streamingRole}>` : '*Not set*';

            const configContent = `**Activity Role Configuration**\n\n` +
                `**Status:** ${config.enabled ? '✅ Enabled' : '❌ Disabled'}\n\n` +
                `**Spotify Role:** ${spotifyRole}\n` +
                `**Gaming Role:** ${gamingRole}\n` +
                `**Streaming Role:** ${streamingRole}`;

            return message.channel.send(client.util.createMessage(configContent, client.color));
        }

        // Set Spotify role
        if (subcommand === 'spotify') {
            const role = message.mentions.roles.first() || 
                         message.guild.roles.cache.get(args[1]) || 
                         message.guild.roles.cache.find(r => r.name.toLowerCase() === args.slice(1).join(' ').toLowerCase());

            if (!role) {
                return message.channel.send(client.util.createMessage(
                    `${client.emoji.cross} | Please provide a valid role.`
                ));
            }

            let config = await ActivityRole.findOne({ guildId: message.guild.id });
            if (!config) {
                config = await ActivityRole.create({
                    guildId: message.guild.id,
                    enabled: true,
                    spotifyRole: role.id
                });
            } else {
                config.spotifyRole = role.id;
                await config.save();
            }

            return message.channel.send(client.util.createMessage(
                `${client.emoji.tick} | Spotify activity role set to ${role}`,
                0x1DB954 // Spotify green
            ));
        }

        // Set Gaming role
        if (subcommand === 'gaming') {
            const role = message.mentions.roles.first() || 
                         message.guild.roles.cache.get(args[1]) || 
                         message.guild.roles.cache.find(r => r.name.toLowerCase() === args.slice(1).join(' ').toLowerCase());

            if (!role) {
                return message.channel.send(client.util.createMessage(
                    `${client.emoji.cross} | Please provide a valid role.`
                ));
            }

            let config = await ActivityRole.findOne({ guildId: message.guild.id });
            if (!config) {
                config = await ActivityRole.create({
                    guildId: message.guild.id,
                    enabled: true,
                    gamingRole: role.id
                });
            } else {
                config.gamingRole = role.id;
                await config.save();
            }

            return message.channel.send(client.util.createMessage(
                `${client.emoji.tick} | Gaming activity role set to ${role}`,
                0x5865F2 // Discord blurple
            ));
        }

        // Set Streaming role
        if (subcommand === 'streaming') {
            const role = message.mentions.roles.first() || 
                         message.guild.roles.cache.get(args[1]) || 
                         message.guild.roles.cache.find(r => r.name.toLowerCase() === args.slice(1).join(' ').toLowerCase());

            if (!role) {
                return message.channel.send(client.util.createMessage(
                    `${client.emoji.cross} | Please provide a valid role.`
                ));
            }

            let config = await ActivityRole.findOne({ guildId: message.guild.id });
            if (!config) {
                config = await ActivityRole.create({
                    guildId: message.guild.id,
                    enabled: true,
                    streamingRole: role.id
                });
            } else {
                config.streamingRole = role.id;
                await config.save();
            }

            return message.channel.send(client.util.createMessage(
                `${client.emoji.tick} | Streaming activity role set to ${role}`,
                0x9146FF // Twitch purple
            ));
        }

        // Invalid subcommand
        return message.channel.send(client.util.createMessage(
            `${client.emoji.cross} | Invalid subcommand. Use \`activityrole\` to see available commands.`
        ));
    }
};
