const mongoose = require('mongoose');

// Activity Role System Schema
const ActivityRoleSchema = new mongoose.Schema({
  guildId: { type: String, required: true, unique: true },
  enabled: { type: Boolean, default: false },
  spotifyRole: { type: String, default: null }, // Role ID for Spotify activity
  gamingRole: { type: String, default: null },  // Role ID for Gaming activity
  streamingRole: { type: String, default: null } // Role ID for Streaming activity
});

// VC Role System Schema
const VCRoleSchema = new mongoose.Schema({
  guildId: { type: String, required: true, unique: true },
  enabled: { type: Boolean, default: false },
  vcRole: { type: String, required: true } // Role ID to assign when in VC
});

// Vanity Status Role System Schema
const VanityStatusSchema = new mongoose.Schema({
  guildId: { type: String, required: true, unique: true },
  enabled: { type: Boolean, default: false },
  vanityCode: { type: String, required: true }, // The vanity code to detect (e.g., ".gg/yourserver")
  officialRole: { type: String, required: true }, // Role ID to assign when vanity is in status
  logChannel: { type: String, default: null } // Channel ID for logging vanity additions/removals
});

module.exports = {
  ActivityRole: mongoose.model('ActivityRole', ActivityRoleSchema),
  VCRole: mongoose.model('VCRole', VCRoleSchema),
  VanityStatus: mongoose.model('VanityStatus', VanityStatusSchema)
};
