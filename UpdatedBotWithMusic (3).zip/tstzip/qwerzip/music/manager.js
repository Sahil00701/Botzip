const { Shoukaku, Connectors } = require("shoukaku");
const { MessageFlags } = require("discord.js");

const COMPONENTS_V2_FLAG = MessageFlags?.IsComponentsV2 ?? (1 << 15);
const IDLE_DISCONNECT_MS = 60000;

class MusicManager {
    constructor(client, options = {}) {
        this.client = client;
        this.states = new Map();

        // Lavalink configuration
        this.lavalinkConfig = {
            host: options.host || process.env.LAVALINK_HOST || "localhost",
            port: options.port || parseInt(process.env.LAVALINK_PORT) || 2333,
            password: options.password || process.env.LAVALINK_PASSWORD || "youshallnotpass",
            secure: options.secure || process.env.LAVALINK_SECURE === "true",
            identifier: options.identifier || process.env.LAVALINK_IDENTIFIER || "default"
        };

        // Create shoukaku instance
        this.connector = new Connectors.DiscordJS(client);
        this.shoukaku = new Shoukaku(this.connector, [
            {
                name: this.lavalinkConfig.identifier,
                url: `${this.lavalinkConfig.host}:${this.lavalinkConfig.port}`,
                auth: this.lavalinkConfig.password,
                secure: this.lavalinkConfig.secure
            }
        ], {
            moveOnDisconnect: false,
            resume: false,
            voiceConnectionTimeout: 30000
        });

        this.registerEvents();
    }

    registerEvents() {
        this.shoukaku.on("ready", (name, resumed) => {
            console.log(`[Lavalink] Node connected: ${name} (resumed: ${resumed})`);
        });

        this.shoukaku.on("error", (name, error) => {
            console.error(`[Lavalink] Node error: ${name}`, error);
        });

        this.shoukaku.on("close", (name, code, reason) => {
            console.warn(`[Lavalink] Node closed: ${name}`, code, reason);
        });

        this.shoukaku.on("disconnected", (name, reason) => {
            console.warn(`[Lavalink] Node disconnected: ${name}`, reason);
        });
    }

    async search(query, guildId) {
        const node = this.shoukaku.getNode();
        if (!node) {
            throw new Error("No Lavalink node available");
        }

        const isUrl = /^https?:\/\//i.test(query);
        const searchQuery = isUrl ? query : `ytsearch:${query}`;

        try {
            const result = await node.rest.resolve(searchQuery);
            return result;
        } catch (error) {
            console.error("[Music Search Error]", error);
            throw error;
        }
    }

    async create(guildId, voiceChannelId, textChannelId, shardId, userId) {
        let state = this.states.get(guildId);

        if (state && state.player) {
            await this.disconnect(guildId);
        }

        const node = this.shoukaku.getNode();
        if (!node) {
            throw new Error("No Lavalink node available");
        }

        const player = await node.joinVoiceChannel({
            guildId: guildId,
            channelId: voiceChannelId,
            shardId: shardId,
            deaf: true
        });

        state = {
            player: player,
            voiceChannelId: voiceChannelId,
            textChannelId: textChannelId,
            queue: [],
            current: null,
            repeat: "off",
            volume: 100,
            userId: userId
        };

        player.on("start", () => {
            this.sendNowPlaying(guildId);
        });

        player.on("end", (data) => {
            this.handleTrackEnd(guildId, data);
        });

        player.on("error", (error) => {
            console.error(`[Player Error] Guild: ${guildId}`, error);
        });

        player.on("closed", (code, reason) => {
            console.warn(`[Player Closed] Guild: ${guildId}`, code, reason);
        });

        this.states.set(guildId, state);
        return state;
    }

    async handleTrackEnd(guildId, data) {
        const state = this.states.get(guildId);
        if (!state) return;

        // Handle auto-play or next track
        if (data.reason === "FINISHED" || data.reason === "STOPPED") {
            if (state.repeat === "track" && state.current) {
                state.queue.unshift(state.current);
            } else if (state.repeat === "queue" && state.current) {
                state.queue.push(state.current);
            }

            if (state.queue.length > 0) {
                const nextTrack = state.queue.shift();
                state.current = nextTrack;
                await state.player.playTrack(nextTrack);
            } else {
                // Queue empty - set timeout to disconnect
                setTimeout(() => {
                    const currentState = this.states.get(guildId);
                    if (currentState && currentState.queue.length === 0 && !currentState.current) {
                        this.disconnect(guildId);
                    }
                }, IDLE_DISCONNECT_MS);
            }
        }
    }

    async enqueue(guildId, tracks) {
        const state = this.states.get(guildId);
        if (!state) return 0;

        if (!Array.isArray(tracks)) {
            tracks = [tracks];
        }

        state.queue.push(...tracks);
        return tracks.length;
    }

    async playIfIdle(guildId) {
        const state = this.states.get(guildId);
        if (!state) return;

        if (!state.player || state.player.paused) return;

        const current = state.player?.track;
        if (!current && state.queue.length > 0) {
            const nextTrack = state.queue.shift();
            state.current = nextTrack;
            await state.player.playTrack(nextTrack);
        }
    }

    async play(guildId) {
        const state = this.states.get(guildId);
        if (!state || !state.player) return;

        if (state.queue.length > 0) {
            const nextTrack = state.queue.shift();
            state.current = nextTrack;
            await state.player.playTrack(nextTrack);
        }
    }

    async pause(guildId) {
        const state = this.states.get(guildId);
        if (!state || !state.player) return false;

        await state.player.setPause(true);
        return true;
    }

    async resume(guildId) {
        const state = this.states.get(guildId);
        if (!state || !state.player) return false;

        await state.player.setPause(false);
        return true;
    }

    async skip(guildId) {
        const state = this.states.get(guildId);
        if (!state || !state.player) return false;

        await state.player.stopTrack();
        return true;
    }

    async stop(guildId) {
        const state = this.states.get(guildId);
        if (!state) return false;

        state.queue = [];
        state.current = null;

        if (state.player) {
            await state.player.stopTrack();
        }

        return true;
    }

    async setVolume(guildId, volume) {
        const state = this.states.get(guildId);
        if (!state || !state.player) return false;

        await state.player.setVolume(volume);
        state.volume = volume;
        return true;
    }

    async disconnect(guildId) {
        const state = this.states.get(guildId);
        if (!state) return;

        if (state.player) {
            state.player.disconnect();
        }

        this.states.delete(guildId);
    }

    get(guildId) {
        return this.states.get(guildId);
    }

    async sendNowPlaying(guildId) {
        const state = this.states.get(guildId);
        if (!state || !state.current || !state.textChannelId) return;

        try {
            const channel = await this.client.channels.fetch(state.textChannelId);
            if (!channel) return;

            const track = state.current;
            const embed = {
                title: "Now Playing",
                description: `[${track.info.title}](${track.info.uri})`,
                fields: [
                    { name: "Author", value: track.info.author || "Unknown" },
                    { name: "Duration", value: this.formatDuration(track.info.length) },
                    { name: "Requested by", value: `<@${track.requesterId}>` }
                ],
                color: this.client.color || 0x2b2d31
            };

            await channel.send({ embeds: [embed] });
        } catch (error) {
            console.error("[Now Playing Error]", error);
        }
    }

    formatDuration(ms) {
        const seconds = Math.floor(ms / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);

        if (hours > 0) {
            return `${hours}:${String(minutes % 60).padStart(2, '0')}:${String(seconds % 60).padStart(2, '0')}`;
        }
        return `${minutes}:${String(seconds % 60).padStart(2, '0')}`;
    }
}

module.exports = { MusicManager };
