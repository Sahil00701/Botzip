const { ClusterManager, HeartbeatManager } = require('discord-hybrid-sharding');
const axios = require('axios');
const config = require(`${process.cwd()}/config.json`);

// Auto Webhook Logger (Disabled)
async function logToWebhook(message) {
    console.log(`[MANAGER] ${message}`);
}

// Utility function to get memory usage for clusters
function getMemoryUsage(cluster) {
    const usage = process.memoryUsage();
    return {
        heapUsed: Math.round(usage.heapUsed / 1024 / 1024),
        heapTotal: Math.round(usage.heapTotal / 1024 / 1024),
        external: Math.round(usage.external / 1024 / 1024),
        rss: Math.round(usage.rss / 1024 / 1024)
    };
}

// Auto Scales Shards
const manager = new ClusterManager(`${__dirname}/index.js`, {
    totalShards: "auto",         
    shardsPerClusters: 1,         
    totalClusters: "auto",       
    mode: "process",
    token: config.TOKEN,
    respawn: true,               
});

manager.on("clusterCreate", (cluster) => {
    console.log(`🚀 Cluster ${cluster.id} launched`);
    logToWebhook(`🚀 Cluster **${cluster.id}** launched`);
});

manager.on("clusterReady", (cluster) => {
    console.log(`✅ Cluster ${cluster.id} is ready`);
    // OPTIMIZATION: Log memory usage for each cluster upon initialization
    const memUsage = getMemoryUsage(cluster);
    logToWebhook(
        `✅ Cluster **${cluster.id}** is ready\n` +
        `📊 Memory - Heap: ${memUsage.heapUsed}/${memUsage.heapTotal}MB | RSS: ${memUsage.rss}MB`
    );
});

console.log('[MANAGER] Starting Cluster Manager...');
manager.spawn({ timeout: -1, delay: 5000 }).then(() => {
    console.log('✨ All clusters have been launched');
    logToWebhook("✨ All clusters have been launched automatically with optimized spawn intervals.");
});

// OPTIMIZATION: Increased heartbeat interval from 3000ms to 10000ms
// This reduces overhead from continuous heartbeat checks while maintaining cluster health monitoring
// Clusters are still respawned if they miss 5 consecutive heartbeats (50 seconds total timeout)
manager.extend(
    new HeartbeatManager({
        interval: 10000,           
        maxMissedHeartbeats: 5,
    })
);

process.on("uncaughtException", (err) => {
    logToWebhook(`🔥 **Uncaught Exception**\n\`\`\`${err.stack || err}\`\`\``);
});

process.on("unhandledRejection", (reason) => {
    logToWebhook(`⚡ **Unhandled Rejection**\n\`\`\`${reason}\`\`\``);
});

// OPTIMIZATION: Graceful shutdown handling
// Ensures all clusters are properly destroyed and resources are cleaned up before process exit
// Prevents orphaned processes and resource leaks
process.on("SIGINT", async () => {
    console.log("[ClusterManager] Received SIGINT, initiating graceful shutdown...");
    logToWebhook("🛑 **Graceful Shutdown Initiated** - Destroying all clusters...");
    
    try {
        // Broadcast destroy command to all clusters to clean up resources
        await manager.broadcastEval(c => c.destroy());
        logToWebhook("✅ All clusters destroyed successfully. Exiting process.");
        console.log("[ClusterManager] All clusters destroyed. Exiting cleanly.");
    } catch (err) {
        console.error("[ClusterManager] Error during graceful shutdown:", err);
        logToWebhook(`❌ **Shutdown Error**: ${err.message}`);
    }
    
    process.exit(0);
});
